#!/usr/bin/env python
# coding: utf-8

#Citation Request:

#Please cite the article: Shima Azizi, Cem Deniz Caglar Bozkir, Andrew C. Trapp, O. Erhun Kundakcioglu, Ali Kaan Kurbanzade, "Aid Allocation for Camp-Based and Urban Refugees with Uncertain Demand and Replenishments", 2020.

#Email: sazizi@wpi.edu, cem.bozkir@ozu.edu.tr, atrapp@wpi.edu, erhun.kundakcioglu@ozyegin.edu.tr, kaan.kurbanzade@ozu.edu.tr
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
import matplotlib.ticker as mticker

# =====================Find Invalid Scenarios==================================
#Various parameter values:
N = 7
mu = [1, 4/3, 2]
delta_D = [20, 30, 40, 50]
alpha = [0.25, 0.5, 0.75]
delta_R =  [1, 2, 3]   
#create all possible combinations of above parameters:
Scenarios = np.array(np.meshgrid(mu,delta_D,alpha,delta_R)).T.reshape(-1,4)  # Scenarios includes all possible combinations of various parameters    
#Create camp names
Camp_Index=[]
for i in range(N):
    Camp_Index.append("Camp "+str(i+1))

#Create a data frame that includes all possible scenarios
Data = pd.DataFrame(Scenarios,
                   columns=['Mu','delta_D', 'alpha' ,'delta_R'])    
    
#insert scenario number into created dataframe
Data.insert(0, 'ScenarioID', 'Scenario '+(Data.index+1).astype(str))
    
#Ratio Checks
Invalid_Scenarios_List=[]
for i in range(Data.shape[0]):
    if Data["alpha"][i]>Data["Mu"][i]:
        Invalid_Scenarios_List.append(Data["ScenarioID"][i]) #"Deprivation Rate cannot exceed yearly cycle rate."        
    elif Data["delta_R"][i]>(Data["delta_D"][i]*(Data["alpha"][i]/(Data["Mu"][i]-Data["alpha"][i]))): 
        Invalid_Scenarios_List.append(Data["ScenarioID"][i])     #"The ratio between Referral Cost Per External Demand and Deprivation Cost Per Time Unit Per Internal Demand does not hold." 
# =============================================================================        
#Import_Optimization_Results
df_Sim = pd.read_csv('inputData.csv', encoding='utf-8',delimiter=',')  # I am reading this file to import optimization results for each scenario
df_Sim = df_Sim.drop_duplicates(subset=['ScenarioID'])  # I just need the unique characteristic of each scenario from df_Sim, so I will delete repetitive rows.
df_Sim = df_Sim.drop(columns=['Camps Name','lambda_C', 'lambda_S', 'omega', 'Supply', 'Optimal Allocated Aid'])   # I also delete columns that I don't need
df_Sim = df_Sim.reset_index(drop=True)
df_Sim=df_Sim[~df_Sim['ScenarioID'].isin(Invalid_Scenarios_List)]    #    Remove invalid Scenarios
df_Sim['ScenarioID'] = df_Sim['ScenarioID'].map(lambda x: x.replace('cenario ',''))    
# =============================================================================
#Read each csv output file & Calculoate mean cost for each scenario
#Output: 
df_output = pd.read_csv('output.csv', encoding='utf-8',delimiter=',') 
df_output = df_output[~df_output['ScenarioID'].isin(Invalid_Scenarios_List)]  #    Remove invalid Scenarios

df_output['ScenarioID'] = df_output['ScenarioID'].map(lambda x: str(x).replace('cenario ',''))
#I am creating a new dataframe that includes mean and std for all replications of a scenario
Grouped_df_output = df_output.groupby(['ScenarioID','distribution']).agg({'deprivationCost': ['mean', 'std'], 'referralCost':['mean', 'std'], 'holdingCost':['mean', 'std']})    
#Add total cost column
Grouped_df_output['TotalCost','mean'] = Grouped_df_output[[['deprivationCost','mean'],['referralCost','mean'],['holdingCost','mean']]].sum(axis=1)       
 
#01RANDOMoutput:    
df_01RANDOMoutput= pd.read_csv('perturbed0.1RANDOMoutput.csv', encoding='utf-8',delimiter=',')  
df_01RANDOMoutput = df_01RANDOMoutput[~df_01RANDOMoutput['ScenarioID'].isin(Invalid_Scenarios_List)]  #    Remove invalid Scenarios

df_01RANDOMoutput['ScenarioID'] = df_01RANDOMoutput['ScenarioID'].map(lambda x: str(x).replace('cenario ',''))
#I am creating a new dataframe that includes mean and std for all replications of a scenario
Grouped_df_01RANDOMoutput = df_01RANDOMoutput.groupby(['ScenarioID','distribution']).agg({'deprivationCost': ['mean', 'std'], 'referralCost':['mean', 'std'], 'holdingCost':['mean', 'std']})    
#Add total cost column
Grouped_df_01RANDOMoutput['TotalCost','mean'] = Grouped_df_01RANDOMoutput[[['deprivationCost','mean'],['referralCost','mean'],['holdingCost','mean']]].sum(axis=1)       
#Add Difference with Optimal Coulmn
Grouped_df_01RANDOMoutput["Difference_Total_With_Optimal"] = Grouped_df_01RANDOMoutput[[('TotalCost','mean')]].subtract(Grouped_df_output[[('TotalCost','mean')]])    
#Add % Difference with Optimal Coulmn
Grouped_df_01RANDOMoutput["Percent_Difference_Total_With_Optimal"] =  Grouped_df_01RANDOMoutput[[('Difference_Total_With_Optimal', '')]].values /Grouped_df_output[[('TotalCost','mean')]].values

#01SYSTEMATICoutput:    
df_01SYSTEMATICoutput = pd.read_csv('perturbed0.1SYSTEMATICoutput.csv', encoding='utf-8',delimiter=',')  
df_01SYSTEMATICoutput = df_01SYSTEMATICoutput[~df_01SYSTEMATICoutput['ScenarioID'].isin(Invalid_Scenarios_List)]  #    Remove invalid Scenarios    

df_01SYSTEMATICoutput['ScenarioID'] = df_01SYSTEMATICoutput['ScenarioID'].map(lambda x: str(x).replace('cenario ',''))
#I am creating a new dataframe that includes mean and std for all replications of a scenario
Grouped_df_01SYSTEMATICoutput = df_01SYSTEMATICoutput.groupby(['ScenarioID','distribution']).agg({'deprivationCost': ['mean', 'std'], 'referralCost':['mean', 'std'], 'holdingCost':['mean', 'std']})    
#Add total cost column
Grouped_df_01SYSTEMATICoutput['TotalCost','mean'] = Grouped_df_01SYSTEMATICoutput[[['deprivationCost','mean'],['referralCost','mean'],['holdingCost','mean']]].sum(axis=1)       
#Add Difference with Optimal Coulmn
Grouped_df_01SYSTEMATICoutput["Difference_Total_With_Optimal"] = Grouped_df_01SYSTEMATICoutput[[('TotalCost','mean')]].subtract(Grouped_df_output[[('TotalCost','mean')]])      
#Add % Difference with Optimal Coulmn
Grouped_df_01SYSTEMATICoutput["Percent_Difference_Total_With_Optimal"] = Grouped_df_01SYSTEMATICoutput[[('Difference_Total_With_Optimal', '')]].values / Grouped_df_output[[('TotalCost','mean')]].values

#005RANDOMoutput:
df_005RANDOMoutput = pd.read_csv('perturbed0.05RANDOMoutput.csv', encoding='utf-8',delimiter=',')  
df_005RANDOMoutput = df_005RANDOMoutput[~df_005RANDOMoutput['ScenarioID'].isin(Invalid_Scenarios_List)]  #    Remove invalid Scenarios
    
df_005RANDOMoutput['ScenarioID'] = df_005RANDOMoutput['ScenarioID'].map(lambda x: str(x).replace('cenario ',''))
#I am creating a new dataframe that includes mean and std for all replications of a scenario
Grouped_df_005RANDOMoutput = df_005RANDOMoutput.groupby(['ScenarioID','distribution']).agg({'deprivationCost': ['mean', 'std'], 'referralCost':['mean', 'std'], 'holdingCost':['mean', 'std']})    
#Add total cost column
Grouped_df_005RANDOMoutput['TotalCost','mean'] = Grouped_df_005RANDOMoutput[[['deprivationCost','mean'],['referralCost','mean'],['holdingCost','mean']]].sum(axis=1)       
#Add Difference with Optimal Coulmn
Grouped_df_005RANDOMoutput["Difference_Total_With_Optimal"] = Grouped_df_005RANDOMoutput[[('TotalCost','mean')]].subtract(Grouped_df_output[[('TotalCost','mean')]])  
#Add % Difference with Optimal Coulmn
Grouped_df_005RANDOMoutput["Percent_Difference_Total_With_Optimal"] = Grouped_df_005RANDOMoutput[[('Difference_Total_With_Optimal', '')]].values /Grouped_df_output[[('TotalCost','mean')]].values

#005SYSTEMATICoutput:
df_005SYSTEMATICoutput = pd.read_csv('perturbed0.05SYSTEMATICoutput.csv', encoding='utf-8',delimiter=',')  
df_005SYSTEMATICoutput = df_005SYSTEMATICoutput[~df_005SYSTEMATICoutput['ScenarioID'].isin(Invalid_Scenarios_List)]  #    Remove invalid Scenarios    

df_005SYSTEMATICoutput['ScenarioID'] = df_005SYSTEMATICoutput['ScenarioID'].map(lambda x: str(x).replace('cenario ',''))
#I am creating a new dataframe that includes mean and std for all replications of a scenario
Grouped_df_005SYSTEMATICoutput= df_005SYSTEMATICoutput.groupby(['ScenarioID','distribution']).agg({'deprivationCost': ['mean', 'std'], 'referralCost':['mean', 'std'], 'holdingCost':['mean', 'std']})    
#Add total cost column
Grouped_df_005SYSTEMATICoutput['TotalCost','mean'] = Grouped_df_005SYSTEMATICoutput[[['deprivationCost','mean'],['referralCost','mean'],['holdingCost','mean']]].sum(axis=1) 
#Add Difference with Optimal Coulmn
Grouped_df_005SYSTEMATICoutput["Difference_Total_With_Optimal"] = Grouped_df_005SYSTEMATICoutput[[('TotalCost','mean')]].subtract(Grouped_df_output[[('TotalCost','mean')]])      
#Add % Difference with Optimal Coulmn
Grouped_df_005SYSTEMATICoutput["Percent_Difference_Total_With_Optimal"] = Grouped_df_005SYSTEMATICoutput[[('Difference_Total_With_Optimal', '')]].values /Grouped_df_output[[('TotalCost','mean')]].values

#015RANDOMoutput:
df_015RANDOMoutput = pd.read_csv('perturbed0.15RANDOMoutput.csv', encoding='utf-8',delimiter=',')  
df_015RANDOMoutput = df_015RANDOMoutput[~df_015RANDOMoutput['ScenarioID'].isin(Invalid_Scenarios_List)]  #    Remove invalid Scenarios
    
df_015RANDOMoutput['ScenarioID'] = df_015RANDOMoutput['ScenarioID'].map(lambda x: str(x).replace('cenario ',''))
#I am creating a new dataframe that includes mean and std for all replications of a scenario
Grouped_df_015RANDOMoutput= df_015RANDOMoutput.groupby(['ScenarioID','distribution']).agg({'deprivationCost': ['mean', 'std'], 'referralCost':['mean', 'std'], 'holdingCost':['mean', 'std']})    
#Add total cost column
Grouped_df_015RANDOMoutput['TotalCost','mean'] = Grouped_df_015RANDOMoutput[[['deprivationCost','mean'],['referralCost','mean'],['holdingCost','mean']]].sum(axis=1) 
#Add Difference with Optimal Coulmn
Grouped_df_015RANDOMoutput["Difference_Total_With_Optimal"] = Grouped_df_015RANDOMoutput[[('TotalCost','mean')]].subtract(Grouped_df_output[[('TotalCost','mean')]]) 
#Add % Difference with Optimal Coulmn
Grouped_df_015RANDOMoutput["Percent_Difference_Total_With_Optimal"] = Grouped_df_015RANDOMoutput[[('Difference_Total_With_Optimal', '')]].values /Grouped_df_output[[('TotalCost','mean')]].values

#015SYSTEMATICoutput:
df_015SYSTEMATICoutput = pd.read_csv('perturbed0.15SYSTEMATICoutput.csv', encoding='utf-8',delimiter=',')  
df_015SYSTEMATICoutput = df_015SYSTEMATICoutput[~df_015SYSTEMATICoutput['ScenarioID'].isin(Invalid_Scenarios_List)]  #    Remove invalid Scenarios    

df_015SYSTEMATICoutput['ScenarioID'] = df_015SYSTEMATICoutput['ScenarioID'].map(lambda x: str(x).replace('cenario ',''))
#I am creating a new dataframe that includes mean and std for all replications of a scenario
Grouped_df_015SYSTEMATICoutput= df_015SYSTEMATICoutput.groupby(['ScenarioID','distribution']).agg({'deprivationCost': ['mean', 'std'], 'referralCost':['mean', 'std'], 'holdingCost':['mean', 'std']})    
#Add total cost column
Grouped_df_015SYSTEMATICoutput['TotalCost','mean'] = Grouped_df_015SYSTEMATICoutput[[['deprivationCost','mean'],['referralCost','mean'],['holdingCost','mean']]].sum(axis=1)    
#Add Difference with Optimal Coulmn
Grouped_df_015SYSTEMATICoutput["Difference_Total_With_Optimal"] = Grouped_df_015SYSTEMATICoutput[[('TotalCost','mean')]].subtract(Grouped_df_output[[('TotalCost','mean')]]) 
#Add % Difference with Optimal Coulmn
Grouped_df_015SYSTEMATICoutput["Percent_Difference_Total_With_Optimal"] = Grouped_df_015SYSTEMATICoutput[[('Difference_Total_With_Optimal', '')]].values /Grouped_df_output[[('TotalCost','mean')]].values

#02RANDOMoutput:
df_02RANDOMoutput = pd.read_csv('perturbed0.2RANDOMoutput.csv', encoding='utf-8',delimiter=',')  
df_02RANDOMoutput = df_02RANDOMoutput[~df_02RANDOMoutput['ScenarioID'].isin(Invalid_Scenarios_List)]  #    Remove invalid Scenarios
   
df_02RANDOMoutput['ScenarioID'] = df_02RANDOMoutput['ScenarioID'].map(lambda x: str(x).replace('cenario ',''))
#I am creating a new dataframe that includes mean and std for all replications of a scenario
Grouped_df_02RANDOMoutput= df_02RANDOMoutput.groupby(['ScenarioID','distribution']).agg({'deprivationCost': ['mean', 'std'], 'referralCost':['mean', 'std'], 'holdingCost':['mean', 'std']})    
#Add total cost column
Grouped_df_02RANDOMoutput['TotalCost','mean'] = Grouped_df_02RANDOMoutput[[['deprivationCost','mean'],['referralCost','mean'],['holdingCost','mean']]].sum(axis=1)   
#Add Difference with Optimal Coulmn
Grouped_df_02RANDOMoutput["Difference_Total_With_Optimal"] = Grouped_df_02RANDOMoutput[[('TotalCost','mean')]].subtract(Grouped_df_output[[('TotalCost','mean')]]) 
#Add % Difference with Optimal Coulmn
Grouped_df_02RANDOMoutput["Percent_Difference_Total_With_Optimal"] = Grouped_df_02RANDOMoutput[[('Difference_Total_With_Optimal', '')]].values /Grouped_df_output[[('TotalCost','mean')]].values
 
#02SYSTEMATICoutput:
df_02SYSTEMATICoutput = pd.read_csv('perturbed0.2SYSTEMATICoutput.csv', encoding='utf-8',delimiter=',')  
df_02SYSTEMATICoutput = df_02SYSTEMATICoutput[~df_02SYSTEMATICoutput['ScenarioID'].isin(Invalid_Scenarios_List)]  #    Remove invalid Scenarios    

df_02SYSTEMATICoutput['ScenarioID'] = df_02SYSTEMATICoutput['ScenarioID'].map(lambda x: str(x).replace('cenario ',''))
#I am creating a new dataframe that includes mean and std for all replications of a scenario
Grouped_df_02SYSTEMATICoutput= df_02SYSTEMATICoutput.groupby(['ScenarioID','distribution']).agg({'deprivationCost': ['mean', 'std'], 'referralCost':['mean', 'std'], 'holdingCost':['mean', 'std']})    
#Add total cost column
Grouped_df_02SYSTEMATICoutput['TotalCost','mean'] = Grouped_df_02SYSTEMATICoutput[[['deprivationCost','mean'],['referralCost','mean'],['holdingCost','mean']]].sum(axis=1)  
#Add Difference with Optimal Coulmn
Grouped_df_02SYSTEMATICoutput["Difference_Total_With_Optimal"] = Grouped_df_02SYSTEMATICoutput[[('TotalCost','mean')]].subtract(Grouped_df_output[[('TotalCost','mean')]]) 
#Add % Difference with Optimal Coulmn
Grouped_df_02SYSTEMATICoutput["Percent_Difference_Total_With_Optimal"] = Grouped_df_02SYSTEMATICoutput[[('Difference_Total_With_Optimal', '')]].values /Grouped_df_output[[('TotalCost','mean')]].values         

# ========Create a Dataframe for each Distribution=============================
#Output: 
df_EXP_output = Grouped_df_output.loc[pd.IndexSlice[:,["EXPONENTIAL"]],:]
df_LOG_output = Grouped_df_output.loc[pd.IndexSlice[:,["LOGNORMAL"]],:]
df_UNI_from_Exp_output = Grouped_df_output.loc[pd.IndexSlice[:,["UNIFORMFROMEXPO"]],:] 
#Merge:
df_EXP_output = pd.merge(df_Sim, df_EXP_output, on=['ScenarioID'], how='right')
df_LOG_output = pd.merge(df_Sim, df_LOG_output, on=['ScenarioID'], how='right')
df_UNI_from_Exp_output = pd.merge(df_Sim, df_UNI_from_Exp_output, on=['ScenarioID'], how='right')
 
#01RANDOMoutput:
df_EXP_01RANDOMoutput = Grouped_df_01RANDOMoutput.loc[pd.IndexSlice[:,["EXPONENTIAL"]],:]
df_LOG_01RANDOMoutput = Grouped_df_01RANDOMoutput.loc[pd.IndexSlice[:,["LOGNORMAL"]],:]
df_UNI_from_Exp_01RANDOMoutput = Grouped_df_01RANDOMoutput.loc[pd.IndexSlice[:,["UNIFORMFROMEXPO"]],:]       
#Merge:
df_EXP_01RANDOMoutput = pd.merge(df_Sim, df_EXP_01RANDOMoutput, on=['ScenarioID'], how='right')
df_LOG_01RANDOMoutput = pd.merge(df_Sim, df_LOG_01RANDOMoutput, on=['ScenarioID'], how='right') 
df_UNI_from_Exp_01RANDOMoutput = pd.merge(df_Sim, df_UNI_from_Exp_01RANDOMoutput, on=['ScenarioID'], how='right')

#01SYSTEMATICoutput
df_EXP_01SYSTEMATICoutput = Grouped_df_01SYSTEMATICoutput.loc[pd.IndexSlice[:,["EXPONENTIAL"]],:]
df_LOG_01SYSTEMATICoutput = Grouped_df_01SYSTEMATICoutput.loc[pd.IndexSlice[:,["LOGNORMAL"]],:]
df_UNI_from_Exp_01SYSTEMATICoutput = Grouped_df_01SYSTEMATICoutput.loc[pd.IndexSlice[:,["UNIFORMFROMEXPO"]],:]
#Merge:
df_EXP_01SYSTEMATICoutput = pd.merge(df_Sim, df_EXP_01SYSTEMATICoutput, on=['ScenarioID'], how='right')
df_LOG_01SYSTEMATICoutput = pd.merge(df_Sim, df_LOG_01SYSTEMATICoutput, on=['ScenarioID'], how='right')
df_UNI_from_Exp_01SYSTEMATICoutput = pd.merge(df_Sim, df_UNI_from_Exp_01SYSTEMATICoutput, on=['ScenarioID'], how='right')
  
#005RANDOMoutput
df_EXP_005RANDOMoutput = Grouped_df_005RANDOMoutput.loc[pd.IndexSlice[:,["EXPONENTIAL"]],:]
df_LOG_005RANDOMoutput = Grouped_df_005RANDOMoutput.loc[pd.IndexSlice[:,["LOGNORMAL"]],:]
df_UNI_from_Exp_005RANDOMoutput = Grouped_df_005RANDOMoutput.loc[pd.IndexSlice[:,["UNIFORMFROMEXPO"]],:]
#Merge:
df_EXP_005RANDOMoutput = pd.merge(df_Sim, df_EXP_005RANDOMoutput, on=['ScenarioID'], how='right')
df_LOG_005RANDOMoutput = pd.merge(df_Sim, df_LOG_005RANDOMoutput, on=['ScenarioID'], how='right')
df_UNI_from_Exp_005RANDOMoutput = pd.merge(df_Sim, df_UNI_from_Exp_005RANDOMoutput, on=['ScenarioID'], how='right')

#005SYSTEMATICoutput    
df_EXP_005SYSTEMATICoutput = Grouped_df_005SYSTEMATICoutput.loc[pd.IndexSlice[:,["EXPONENTIAL"]],:]
df_LOG_005SYSTEMATICoutput = Grouped_df_005SYSTEMATICoutput.loc[pd.IndexSlice[:,["LOGNORMAL"]],:]
df_UNI_from_Exp_005SYSTEMATICoutput = Grouped_df_005SYSTEMATICoutput.loc[pd.IndexSlice[:,["UNIFORMFROMEXPO"]],:]
#Merge:
df_EXP_005SYSTEMATICoutput = pd.merge(df_Sim, df_EXP_005SYSTEMATICoutput, on=['ScenarioID'], how='right')
df_LOG_005SYSTEMATICoutput = pd.merge(df_Sim, df_LOG_005SYSTEMATICoutput, on=['ScenarioID'], how='right')
df_UNI_from_Exp_005SYSTEMATICoutput = pd.merge(df_Sim, df_UNI_from_Exp_005SYSTEMATICoutput, on=['ScenarioID'], how='right')

#015RANDOMoutput
df_EXP_015RANDOMoutput = Grouped_df_015RANDOMoutput.loc[pd.IndexSlice[:,["EXPONENTIAL"]],:]
df_LOG_015RANDOMoutput = Grouped_df_015RANDOMoutput.loc[pd.IndexSlice[:,["LOGNORMAL"]],:]
df_UNI_from_Exp_015RANDOMoutput = Grouped_df_015RANDOMoutput.loc[pd.IndexSlice[:,["UNIFORMFROMEXPO"]],:]   
#Merge:
df_EXP_015RANDOMoutput = pd.merge(df_Sim, df_EXP_015RANDOMoutput, on=['ScenarioID'], how='right')
df_LOG_015RANDOMoutput = pd.merge(df_Sim, df_LOG_015RANDOMoutput, on=['ScenarioID'], how='right')   
df_UNI_from_Exp_015RANDOMoutput = pd.merge(df_Sim, df_UNI_from_Exp_015RANDOMoutput, on=['ScenarioID'], how='right')
   
#015SYSTEMATICoutput
df_EXP_015SYSTEMATICoutput = Grouped_df_015SYSTEMATICoutput.loc[pd.IndexSlice[:,["EXPONENTIAL"]],:]
df_LOG_015SYSTEMATICoutput = Grouped_df_015SYSTEMATICoutput.loc[pd.IndexSlice[:,["LOGNORMAL"]],:]
df_UNI_from_Exp_015SYSTEMATICoutput = Grouped_df_015SYSTEMATICoutput.loc[pd.IndexSlice[:,["UNIFORMFROMEXPO"]],:]
#Merge:
df_EXP_015SYSTEMATICoutput = pd.merge(df_Sim, df_EXP_015SYSTEMATICoutput, on=['ScenarioID'], how='right')
df_LOG_015SYSTEMATICoutput = pd.merge(df_Sim, df_LOG_015SYSTEMATICoutput, on=['ScenarioID'], how='right')    
df_UNI_from_Exp_015SYSTEMATICoutput = pd.merge(df_Sim, df_UNI_from_Exp_015SYSTEMATICoutput, on=['ScenarioID'], how='right')  

#02RANDOMoutput    
df_EXP_02RANDOMoutput = Grouped_df_02RANDOMoutput.loc[pd.IndexSlice[:,["EXPONENTIAL"]],:]
df_LOG_02RANDOMoutput = Grouped_df_02RANDOMoutput.loc[pd.IndexSlice[:,["LOGNORMAL"]],:]
df_UNI_from_Exp_02RANDOMoutput = Grouped_df_02RANDOMoutput.loc[pd.IndexSlice[:,["UNIFORMFROMEXPO"]],:]
#Merge:
df_EXP_02RANDOMoutput = pd.merge(df_Sim, df_EXP_02RANDOMoutput, on=['ScenarioID'], how='right')
df_LOG_02RANDOMoutput = pd.merge(df_Sim, df_LOG_02RANDOMoutput, on=['ScenarioID'], how='right')    
df_UNI_from_Exp_02RANDOMoutput = pd.merge(df_Sim, df_UNI_from_Exp_02RANDOMoutput, on=['ScenarioID'], how='right')
   
#02SYSTEMATICoutput    
df_EXP_02SYSTEMATICoutput = Grouped_df_02SYSTEMATICoutput.loc[pd.IndexSlice[:,["EXPONENTIAL"]],:]
df_LOG_02SYSTEMATICoutput = Grouped_df_02SYSTEMATICoutput.loc[pd.IndexSlice[:,["LOGNORMAL"]],:]
df_UNI_from_Exp_02SYSTEMATICoutput = Grouped_df_02SYSTEMATICoutput.loc[pd.IndexSlice[:,["UNIFORMFROMEXPO"]],:]
#Merge:
df_EXP_02SYSTEMATICoutput = pd.merge(df_Sim, df_EXP_02SYSTEMATICoutput, on=['ScenarioID'], how='right')
df_LOG_02SYSTEMATICoutput = pd.merge(df_Sim, df_LOG_02SYSTEMATICoutput, on=['ScenarioID'], how='right')    
df_UNI_from_Exp_02SYSTEMATICoutput = pd.merge(df_Sim, df_UNI_from_Exp_02SYSTEMATICoutput, on=['ScenarioID'], how='right')    


# Sort based on Mu and Percent_Difference_Total_With_Optimal of df_EXP_02RANDOMoutput & sort others based on it=============================
#Sort EXP Rand:
df_EXP_02RANDOMoutput = df_EXP_02RANDOMoutput.set_index('ScenarioID')
df_EXP_02RANDOMoutput = df_EXP_02RANDOMoutput.sort_values(['Mu',('Percent_Difference_Total_With_Optimal', '')],ascending=[False,True])    
df_EXP_02RANDOMoutput = df_EXP_02RANDOMoutput.reset_index()

df_EXP_005RANDOMoutput = df_EXP_005RANDOMoutput.set_index('ScenarioID')
df_EXP_005RANDOMoutput = df_EXP_005RANDOMoutput.reindex(index=df_EXP_02RANDOMoutput['ScenarioID'])
df_EXP_005RANDOMoutput = df_EXP_005RANDOMoutput.reset_index()

df_EXP_01RANDOMoutput = df_EXP_01RANDOMoutput.set_index('ScenarioID')
df_EXP_01RANDOMoutput = df_EXP_01RANDOMoutput.reindex(index=df_EXP_02RANDOMoutput['ScenarioID'])
df_EXP_01RANDOMoutput = df_EXP_01RANDOMoutput.reset_index()
              
df_EXP_015RANDOMoutput = df_EXP_015RANDOMoutput.set_index('ScenarioID')
df_EXP_015RANDOMoutput = df_EXP_015RANDOMoutput.reindex(index=df_EXP_02RANDOMoutput['ScenarioID'])
df_EXP_015RANDOMoutput = df_EXP_015RANDOMoutput.reset_index()

#Sort EXP Sys:       
df_EXP_02SYSTEMATICoutput = df_EXP_02SYSTEMATICoutput.set_index('ScenarioID')
df_EXP_02SYSTEMATICoutput = df_EXP_02SYSTEMATICoutput.sort_values(['Mu',('Percent_Difference_Total_With_Optimal', '')],ascending=[False,True])
df_EXP_02SYSTEMATICoutput = df_EXP_02SYSTEMATICoutput.reset_index()

df_EXP_005SYSTEMATICoutput = df_EXP_005SYSTEMATICoutput.set_index('ScenarioID')
df_EXP_005SYSTEMATICoutput = df_EXP_005SYSTEMATICoutput.reindex(index=df_EXP_02SYSTEMATICoutput['ScenarioID'])
df_EXP_005SYSTEMATICoutput = df_EXP_005SYSTEMATICoutput.reset_index()    

df_EXP_01SYSTEMATICoutput = df_EXP_01SYSTEMATICoutput.set_index('ScenarioID')
df_EXP_01SYSTEMATICoutput = df_EXP_01SYSTEMATICoutput.reindex(index=df_EXP_02SYSTEMATICoutput['ScenarioID'])
df_EXP_01SYSTEMATICoutput = df_EXP_01SYSTEMATICoutput.reset_index()    

df_EXP_015SYSTEMATICoutput = df_EXP_015SYSTEMATICoutput.set_index('ScenarioID')
df_EXP_015SYSTEMATICoutput = df_EXP_015SYSTEMATICoutput.reindex(index=df_EXP_02SYSTEMATICoutput['ScenarioID'])
df_EXP_015SYSTEMATICoutput = df_EXP_015SYSTEMATICoutput.reset_index() 
# ==========================Sort based on % of change in TotalCost of df_EXP_02RANDOMoutput & sort others based on it=============================
#Sort LOG Rand:
df_LOG_02RANDOMoutput = df_LOG_02RANDOMoutput.set_index('ScenarioID')
df_LOG_02RANDOMoutput = df_LOG_02RANDOMoutput.sort_values(['Mu',('Percent_Difference_Total_With_Optimal', '')],ascending=[False,True])
df_LOG_02RANDOMoutput = df_LOG_02RANDOMoutput.reset_index()

df_LOG_01RANDOMoutput = df_LOG_01RANDOMoutput.set_index('ScenarioID')
df_LOG_01RANDOMoutput = df_LOG_01RANDOMoutput.reindex(index=df_LOG_02RANDOMoutput['ScenarioID'])
df_LOG_01RANDOMoutput = df_LOG_01RANDOMoutput.reset_index()

df_LOG_005RANDOMoutput = df_LOG_005RANDOMoutput.set_index('ScenarioID')
df_LOG_005RANDOMoutput = df_LOG_005RANDOMoutput.reindex(index=df_LOG_02RANDOMoutput['ScenarioID'])
df_LOG_005RANDOMoutput = df_LOG_005RANDOMoutput.reset_index()
   

df_LOG_015RANDOMoutput = df_LOG_015RANDOMoutput.set_index('ScenarioID')
df_LOG_015RANDOMoutput = df_LOG_015RANDOMoutput.reindex(index=df_LOG_02RANDOMoutput['ScenarioID'])
df_LOG_015RANDOMoutput = df_LOG_015RANDOMoutput.reset_index()

#Sort LOG Sys:    
df_LOG_02SYSTEMATICoutput = df_LOG_02SYSTEMATICoutput.set_index('ScenarioID')
df_LOG_02SYSTEMATICoutput = df_LOG_02SYSTEMATICoutput.sort_values(['Mu',('Percent_Difference_Total_With_Optimal', '')],ascending=[False,True])
df_LOG_02SYSTEMATICoutput = df_LOG_02SYSTEMATICoutput.reset_index()

df_LOG_005SYSTEMATICoutput = df_LOG_005SYSTEMATICoutput.set_index('ScenarioID')
df_LOG_005SYSTEMATICoutput = df_LOG_005SYSTEMATICoutput.reindex(index=df_LOG_02SYSTEMATICoutput['ScenarioID'])
df_LOG_005SYSTEMATICoutput = df_LOG_005SYSTEMATICoutput.reset_index()

df_LOG_01SYSTEMATICoutput = df_LOG_01SYSTEMATICoutput.set_index('ScenarioID')
df_LOG_01SYSTEMATICoutput = df_LOG_01SYSTEMATICoutput.reindex(index=df_LOG_02SYSTEMATICoutput['ScenarioID'])
df_LOG_01SYSTEMATICoutput = df_LOG_01SYSTEMATICoutput.reset_index()

df_LOG_015SYSTEMATICoutput = df_LOG_015SYSTEMATICoutput.set_index('ScenarioID')
df_LOG_015SYSTEMATICoutput = df_LOG_015SYSTEMATICoutput.reindex(index=df_LOG_02SYSTEMATICoutput['ScenarioID'])
df_LOG_015SYSTEMATICoutput = df_LOG_015SYSTEMATICoutput.reset_index() 


# ==========================Sort based on TotalCost of df_UNI_02RANDOMoutput & sort others based on it=============================
#Sort UNI Rand:  
df_UNI_from_Exp_02RANDOMoutput = df_UNI_from_Exp_02RANDOMoutput.set_index('ScenarioID')
df_UNI_from_Exp_02RANDOMoutput = df_UNI_from_Exp_02RANDOMoutput.sort_values(['Mu',('Percent_Difference_Total_With_Optimal', '')],ascending=[False,True])
df_UNI_from_Exp_02RANDOMoutput = df_UNI_from_Exp_02RANDOMoutput.reset_index()

df_UNI_from_Exp_01RANDOMoutput = df_UNI_from_Exp_01RANDOMoutput.set_index('ScenarioID')
df_UNI_from_Exp_01RANDOMoutput = df_UNI_from_Exp_01RANDOMoutput.reindex(index=df_UNI_from_Exp_02RANDOMoutput['ScenarioID'])
df_UNI_from_Exp_01RANDOMoutput = df_UNI_from_Exp_01RANDOMoutput.reset_index()


df_UNI_from_Exp_005RANDOMoutput = df_UNI_from_Exp_005RANDOMoutput.set_index('ScenarioID')
df_UNI_from_Exp_005RANDOMoutput = df_UNI_from_Exp_005RANDOMoutput.reindex(index=df_UNI_from_Exp_02RANDOMoutput['ScenarioID'])
df_UNI_from_Exp_005RANDOMoutput = df_UNI_from_Exp_005RANDOMoutput.reset_index()
  

df_UNI_from_Exp_015RANDOMoutput = df_UNI_from_Exp_015RANDOMoutput.set_index('ScenarioID')
df_UNI_from_Exp_015RANDOMoutput = df_UNI_from_Exp_015RANDOMoutput.reindex(index=df_UNI_from_Exp_02RANDOMoutput['ScenarioID'])
df_UNI_from_Exp_015RANDOMoutput = df_UNI_from_Exp_015RANDOMoutput.reset_index()

#Sort UNI Sys: 
df_UNI_from_Exp_02SYSTEMATICoutput = df_UNI_from_Exp_02SYSTEMATICoutput.set_index('ScenarioID')
df_UNI_from_Exp_02SYSTEMATICoutput = df_UNI_from_Exp_02SYSTEMATICoutput.sort_values(['Mu',('Percent_Difference_Total_With_Optimal', '')],ascending=[False,True])
df_UNI_from_Exp_02SYSTEMATICoutput = df_UNI_from_Exp_02SYSTEMATICoutput.reset_index()

df_UNI_from_Exp_005SYSTEMATICoutput = df_UNI_from_Exp_005SYSTEMATICoutput.set_index('ScenarioID')
df_UNI_from_Exp_005SYSTEMATICoutput = df_UNI_from_Exp_005SYSTEMATICoutput.reindex(index=df_UNI_from_Exp_02SYSTEMATICoutput['ScenarioID'])
df_UNI_from_Exp_005SYSTEMATICoutput = df_UNI_from_Exp_005SYSTEMATICoutput.reset_index()

df_UNI_from_Exp_01SYSTEMATICoutput = df_UNI_from_Exp_01SYSTEMATICoutput.set_index('ScenarioID')
df_UNI_from_Exp_01SYSTEMATICoutput = df_UNI_from_Exp_01SYSTEMATICoutput.reindex(index=df_UNI_from_Exp_02SYSTEMATICoutput['ScenarioID'])
df_UNI_from_Exp_01SYSTEMATICoutput = df_UNI_from_Exp_01SYSTEMATICoutput.reset_index()

df_UNI_from_Exp_015SYSTEMATICoutput = df_UNI_from_Exp_015SYSTEMATICoutput.set_index('ScenarioID')
df_UNI_from_Exp_015SYSTEMATICoutput = df_UNI_from_Exp_015SYSTEMATICoutput.reindex(index=df_UNI_from_Exp_02SYSTEMATICoutput['ScenarioID'])
df_UNI_from_Exp_015SYSTEMATICoutput = df_UNI_from_Exp_015SYSTEMATICoutput.reset_index() 
             
#Create Plots: Optimal_vs_Alterations      
## =========================EXP_Optimal_vs_NonOptimal_Rand========================================              
fig,axes=plt.subplots()      

axes.plot(df_EXP_005RANDOMoutput.loc[:34,'ScenarioID'].values, df_EXP_005RANDOMoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='v',markersize=5,color="darkorange", linewidth=1, alpha=0.8,linestyle='--',label="5% Alteration")
axes.plot(df_EXP_005RANDOMoutput.loc[35:70,'ScenarioID'].values, df_EXP_005RANDOMoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='v',markersize=5,color="darkorange", linewidth=1, alpha=0.8,linestyle='--')
axes.plot(df_EXP_005RANDOMoutput.loc[71:,'ScenarioID'].values, df_EXP_005RANDOMoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='v',markersize=5,color="darkorange", linewidth=1, alpha=0.8,linestyle='--')

axes.plot(df_EXP_01RANDOMoutput.loc[:34,'ScenarioID'].values, df_EXP_01RANDOMoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='*',markersize=5,color="steelblue", linewidth=1, alpha=0.8,linestyle='--',label="10% Alteration")             
axes.plot(df_EXP_01RANDOMoutput.loc[35:70,'ScenarioID'].values, df_EXP_01RANDOMoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='*',markersize=5,color="steelblue", linewidth=1, alpha=0.8,linestyle='--')             
axes.plot(df_EXP_01RANDOMoutput.loc[71:,'ScenarioID'].values, df_EXP_01RANDOMoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='*',markersize=5,color="steelblue", linewidth=1, alpha=0.8,linestyle='--')             

axes.plot(df_EXP_015RANDOMoutput.loc[:34,'ScenarioID'].values, df_EXP_015RANDOMoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=0.8,linestyle='--',label="15% Alteration")
axes.plot(df_EXP_015RANDOMoutput.loc[35:70,'ScenarioID'].values, df_EXP_015RANDOMoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=0.8,linestyle='--')
axes.plot(df_EXP_015RANDOMoutput.loc[71:,'ScenarioID'].values, df_EXP_015RANDOMoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=0.8,linestyle='--')

axes.plot(df_EXP_02RANDOMoutput.loc[:34,'ScenarioID'].values, df_EXP_02RANDOMoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='+',markersize=5,color="green", linewidth=1, alpha=0.8,linestyle='--',label="20% Alteration")     
axes.plot(df_EXP_02RANDOMoutput.loc[35:70,'ScenarioID'].values, df_EXP_02RANDOMoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='+',markersize=5,color="green", linewidth=1, alpha=0.8,linestyle='--')     
axes.plot(df_EXP_02RANDOMoutput.loc[71:,'ScenarioID'].values, df_EXP_02RANDOMoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='+',markersize=5,color="green", linewidth=1, alpha=0.8,linestyle='--')     
  
L=[] # Finding changing Mu points on x-axis
for Mu, df in df_EXP_02RANDOMoutput.groupby('Mu'):  
    L.append(df.shape[0])
plt.axvline(x=L[2]-0.5,linewidth=1, color='dimgrey', alpha=0.5,ls ="--")     
plt.axvline(x=L[2]+L[1]-0.5,linewidth=1, color='dimgrey', alpha=0.5,ls ="--")     

plt.axhline(y = 0,linewidth=1, color='dimgrey', alpha=0.5,ls ="--")

plt.legend(fontsize=24)
axes.yaxis.set_major_formatter(FuncFormatter(lambda y, _: '{:.0%}'.format(y))) 
axes.tick_params(axis='x', which='both', length=0)
plt.xticks([18, 54, 90],fontsize=24) 
plt.yticks(fontsize=24) 
axes.set_xticklabels(["6 Months","9 Months", "12 Months"])
plt.xlabel("Expected Replenishment Duration",fontsize=24)
plt.ylabel("Gap in Average Cost",fontsize=24)
plt.setp(axes.spines.values(), linewidth=0.1) 
fig.set_size_inches(22, 11)
fig.savefig("EXP_Rand_Mu_dif", dpi=300,bbox_inches = 'tight')    
## =========================EXP_Optimal_vs_NonOptimal_Sys========================================              
fig,axes=plt.subplots()         
axes.plot(df_EXP_005SYSTEMATICoutput.loc[:34,'ScenarioID'].values, df_EXP_005SYSTEMATICoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='v',markersize=5,color="darkorange", linewidth=1, alpha=0.8,linestyle='--',label="5% Alteration")
axes.plot(df_EXP_005SYSTEMATICoutput.loc[35:70,'ScenarioID'].values, df_EXP_005SYSTEMATICoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='v',markersize=5,color="darkorange", linewidth=1, alpha=0.8,linestyle='--')
axes.plot(df_EXP_005SYSTEMATICoutput.loc[71:,'ScenarioID'].values, df_EXP_005SYSTEMATICoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='v',markersize=5,color="darkorange", linewidth=1, alpha=0.8,linestyle='--')
           
axes.plot(df_EXP_01SYSTEMATICoutput.loc[:34,'ScenarioID'].values, df_EXP_01SYSTEMATICoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='*',markersize=5,color="steelblue", linewidth=1, alpha=0.8,linestyle='--',label="10% Alteration")
axes.plot(df_EXP_01SYSTEMATICoutput.loc[35:70,'ScenarioID'].values, df_EXP_01SYSTEMATICoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='*',markersize=5,color="steelblue", linewidth=1,linestyle='--', alpha=0.8)
axes.plot(df_EXP_01SYSTEMATICoutput.loc[71:,'ScenarioID'].values, df_EXP_01SYSTEMATICoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='*',markersize=5,color="steelblue", linewidth=1,linestyle='--', alpha=0.8)

axes.plot(df_EXP_015SYSTEMATICoutput.loc[:34,'ScenarioID'].values, df_EXP_015SYSTEMATICoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=0.8,linestyle='--',label="15% Alteration")
axes.plot(df_EXP_015SYSTEMATICoutput.loc[35:70,'ScenarioID'].values, df_EXP_015SYSTEMATICoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=0.8,linestyle='--')
axes.plot(df_EXP_015SYSTEMATICoutput.loc[71:,'ScenarioID'].values, df_EXP_015SYSTEMATICoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=0.8,linestyle='--')
  
axes.plot(df_EXP_02SYSTEMATICoutput.loc[:34,'ScenarioID'].values, df_EXP_02SYSTEMATICoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='+',markersize=5,color="green", linewidth=1, alpha=0.8,linestyle='--',label="20% Alteration")   
axes.plot(df_EXP_02SYSTEMATICoutput.loc[35:70,'ScenarioID'].values, df_EXP_02SYSTEMATICoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='+',markersize=5,color="green", linewidth=1, alpha=0.8,linestyle='--')   
axes.plot(df_EXP_02SYSTEMATICoutput.loc[71:,'ScenarioID'].values, df_EXP_02SYSTEMATICoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='+',markersize=5,color="green", linewidth=1, alpha=0.8,linestyle='--')   

L=[] # Finding changing Mu points on x-axis
for Mu, df in df_EXP_01SYSTEMATICoutput.groupby('Mu'):  
    L.append(df.shape[0])
plt.axvline(x=L[2]-0.5,linewidth=1, color='dimgrey', alpha=0.5,ls ="--")     
plt.axvline(x=L[2]+L[1]-0.5,linewidth=1, color='dimgrey', alpha=0.5,ls ="--") 

plt.axhline(y = 0,linewidth=1, color='dimgrey', alpha=0.5,ls ="--")
  
plt.legend(fontsize=24)
axes.yaxis.set_major_formatter(FuncFormatter(lambda y, _: '{:.0%}'.format(y))) 
plt.yticks(fontsize=24) 
axes.tick_params(axis='x', which='both', length=0)
plt.xticks([18, 54, 90],fontsize=24)  
axes.set_xticklabels(["6 Months","9 Months", "12 Months"])
plt.xlabel("Expected Replenishment Duration",fontsize=24)
plt.ylabel("Gap in Average Cost",fontsize=24) 
plt.setp(axes.spines.values(), linewidth=0.1) 
fig.set_size_inches(22, 11)
fig.savefig("EXP_Sys_Mu_dif", dpi=300,bbox_inches = 'tight')
# =========================Lognormal_Optimal_vs_NonOptimal_Rand========================================
fig,axes=plt.subplots()
axes.plot(df_LOG_005RANDOMoutput.loc[:34,'ScenarioID'].values, df_LOG_005RANDOMoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='v',markersize=5,color="darkorange", linewidth=1, alpha=0.8,linestyle='--', label="5% Alteration")
axes.plot(df_LOG_005RANDOMoutput.loc[35:70,'ScenarioID'].values, df_LOG_005RANDOMoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='v',markersize=5,color="darkorange", linewidth=1, alpha=0.8,linestyle='--')
axes.plot(df_LOG_005RANDOMoutput.loc[71:,'ScenarioID'].values, df_LOG_005RANDOMoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='v',markersize=5,color="darkorange", linewidth=1, alpha=0.8,linestyle='--')

axes.plot(df_LOG_01RANDOMoutput.loc[:34,'ScenarioID'].values, df_LOG_01RANDOMoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='*',markersize=5,color="steelblue", linewidth=1, alpha=0.8,linestyle='--', label="10% Alteration")             
axes.plot(df_LOG_01RANDOMoutput.loc[35:70,'ScenarioID'].values, df_LOG_01RANDOMoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='*',markersize=5,color="steelblue", linewidth=1, alpha=0.8,linestyle='--')             
axes.plot(df_LOG_01RANDOMoutput.loc[71:,'ScenarioID'].values, df_LOG_01RANDOMoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='*',markersize=5,color="steelblue", linewidth=1, alpha=0.8,linestyle='--')             

axes.plot(df_LOG_015RANDOMoutput.loc[:34,'ScenarioID'].values, df_LOG_015RANDOMoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=0.8,linestyle='--', label="15% Alteration")
axes.plot(df_LOG_015RANDOMoutput.loc[35:70,'ScenarioID'].values, df_LOG_015RANDOMoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=0.8,linestyle='--')
axes.plot(df_LOG_015RANDOMoutput.loc[71:,'ScenarioID'].values, df_LOG_015RANDOMoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=0.8,linestyle='--')

axes.plot(df_LOG_02RANDOMoutput.loc[:34,'ScenarioID'].values, df_LOG_02RANDOMoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='+',markersize=5,color="green", linewidth=1, alpha=0.8,linestyle='--',label="20% Alteration")   
axes.plot(df_LOG_02RANDOMoutput.loc[35:70,'ScenarioID'].values, df_LOG_02RANDOMoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='+',markersize=5,color="green", linewidth=1, alpha=0.8,linestyle='--')   
axes.plot(df_LOG_02RANDOMoutput.loc[71:,'ScenarioID'].values, df_LOG_02RANDOMoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='+',markersize=5,color="green", linewidth=1, alpha=0.8,linestyle='--')   
  
L=[] # Finding changing Mu points on x-axis
for Mu, df in df_LOG_005RANDOMoutput.groupby('Mu'):  
    L.append(df.shape[0])
plt.axvline(x=L[2]-0.5,linewidth=1, color='dimgrey', alpha=0.5,ls ="--")     
plt.axvline(x=L[2]+L[1]-0.5,linewidth=1, color='dimgrey', alpha=0.5,ls ="--")   

plt.axhline(y = 0,linewidth=1, color='dimgrey', alpha=0.5,ls ="--")

plt.legend(fontsize=24)
axes.yaxis.set_major_formatter(FuncFormatter(lambda y, _: '{:.0%}'.format(y))) 
plt.yticks(fontsize=24) 
axes.tick_params(axis='x', which='both', length=0)
plt.xticks([18, 54, 90],fontsize=24) 
axes.set_xticklabels(["6 Months","9 Months", "12 Months"])
plt.xlabel("Expected Replenishment Duration",fontsize=24)
plt.ylabel("Gap in Average Cost",fontsize=24)
plt.setp(axes.spines.values(), linewidth=0.1) 
fig.set_size_inches(22, 11)
fig.savefig("LogNorm_Rand_Mu_dif", dpi=300,bbox_inches = 'tight')  
  
# =========================Lognormal_Optimal_vs_NonOptimal_Sys========================================
fig,axes=plt.subplots()             
axes.plot(df_LOG_005SYSTEMATICoutput.loc[:34,'ScenarioID'].values, df_LOG_005SYSTEMATICoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='v',markersize=5,color="darkorange", linewidth=1, alpha=0.8,linestyle='--', label="5% Alteration")
axes.plot(df_LOG_005SYSTEMATICoutput.loc[35:70,'ScenarioID'].values, df_LOG_005SYSTEMATICoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='v',markersize=5,color="darkorange", linewidth=1, alpha=0.8,linestyle='--')
axes.plot(df_LOG_005SYSTEMATICoutput.loc[71:,'ScenarioID'].values, df_LOG_005SYSTEMATICoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='v',markersize=5,color="darkorange", linewidth=1, alpha=0.8,linestyle='--')

axes.plot(df_LOG_01SYSTEMATICoutput.loc[:34,'ScenarioID'].values, df_LOG_01SYSTEMATICoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='*',markersize=5,color="steelblue", linewidth=1, alpha=0.8,linestyle='--',label="10% Alteration")
axes.plot(df_LOG_01SYSTEMATICoutput.loc[35:70,'ScenarioID'].values, df_LOG_01SYSTEMATICoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='*',markersize=5,color="steelblue", linewidth=1, alpha=0.8,linestyle='--')
axes.plot(df_LOG_01SYSTEMATICoutput.loc[71:,'ScenarioID'].values, df_LOG_01SYSTEMATICoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='*',markersize=5,color="steelblue", linewidth=1, alpha=0.8,linestyle='--')

axes.plot(df_LOG_015SYSTEMATICoutput.loc[:34,'ScenarioID'].values, df_LOG_015SYSTEMATICoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='x',markersize=5,color="mediumpurple", linewidth=1,linestyle='--', alpha=0.8, label="15% Alteration")
axes.plot(df_LOG_015SYSTEMATICoutput.loc[35:70,'ScenarioID'].values, df_LOG_015SYSTEMATICoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='x',markersize=5,color="mediumpurple", linewidth=1,linestyle='--', alpha=0.8)
axes.plot(df_LOG_015SYSTEMATICoutput.loc[71:,'ScenarioID'].values, df_LOG_015SYSTEMATICoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='x',markersize=5,color="mediumpurple", linewidth=1,linestyle='--', alpha=0.8)
    
axes.plot(df_LOG_02SYSTEMATICoutput.loc[:34,'ScenarioID'].values, df_LOG_02SYSTEMATICoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='+',markersize=5,color="green", linewidth=1, alpha=0.8,linestyle='--', label="20% Alteration")   
axes.plot(df_LOG_02SYSTEMATICoutput.loc[35:70,'ScenarioID'].values, df_LOG_02SYSTEMATICoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='+',markersize=5,color="green", linewidth=1, alpha=0.8,linestyle='--')   
axes.plot(df_LOG_02SYSTEMATICoutput.loc[71:,'ScenarioID'].values, df_LOG_02SYSTEMATICoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='+',markersize=5,color="green", linewidth=1, alpha=0.8,linestyle='--')   

L=[] # Finding changing Mu points on x-axis
for Mu, df in df_LOG_02SYSTEMATICoutput.groupby('Mu'):  
    L.append(df.shape[0])
plt.axvline(x=L[2]-0.5,linewidth=1, color='dimgrey', alpha=0.5,ls ="--")     
plt.axvline(x=L[2]+L[1]-0.5,linewidth=1, color='dimgrey', alpha=0.5,ls ="--")   

plt.axhline(y = 0,linewidth=1, color='dimgrey', alpha=0.5,ls ="--")

plt.legend(fontsize=24)
axes.yaxis.set_major_formatter(FuncFormatter(lambda y, _: '{:.0%}'.format(y))) 
plt.yticks(fontsize=24) 
axes.tick_params(axis='x', which='both', length=0)
plt.xticks([18, 54, 90],fontsize=24) 
axes.set_xticklabels(["6 Months","9 Months", "12 Months"])
plt.xlabel("Expected Replenishment Duration",fontsize=24)
plt.ylabel("Gap in Average Cost",fontsize=24)
plt.setp(axes.spines.values(), linewidth=0.1) 
fig.set_size_inches(22, 11)
fig.savefig("LogNorm_Sys_Mu_dif", dpi=300,bbox_inches = 'tight')  
  
# =========================Optimal_vs_NonOptimalUNI_from_Exp_Rand========================================

fig,axes=plt.subplots()
axes.plot(df_UNI_from_Exp_005RANDOMoutput.loc[:34,'ScenarioID'].values, df_UNI_from_Exp_005RANDOMoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='v',markersize=5,color="darkorange", linewidth=1, alpha=0.8,linestyle='--', label="5% Alteration")
axes.plot(df_UNI_from_Exp_005RANDOMoutput.loc[35:70,'ScenarioID'].values, df_UNI_from_Exp_005RANDOMoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='v',markersize=5,color="darkorange", linewidth=1, alpha=0.8,linestyle='--')
axes.plot(df_UNI_from_Exp_005RANDOMoutput.loc[71:,'ScenarioID'].values, df_UNI_from_Exp_005RANDOMoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='v',markersize=5,color="darkorange", linewidth=1, alpha=0.8,linestyle='--')

axes.plot(df_UNI_from_Exp_01RANDOMoutput.loc[:34,'ScenarioID'].values, df_UNI_from_Exp_01RANDOMoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='*',markersize=5,color="steelblue", linewidth=1,linestyle='--', alpha=0.8, label="10% Alteration")             
axes.plot(df_UNI_from_Exp_01RANDOMoutput.loc[35:70,'ScenarioID'].values, df_UNI_from_Exp_01RANDOMoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='*',markersize=5,color="steelblue", linewidth=1,linestyle='--', alpha=0.8)             
axes.plot(df_UNI_from_Exp_01RANDOMoutput.loc[71:,'ScenarioID'].values, df_UNI_from_Exp_01RANDOMoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='*',markersize=5,color="steelblue", linewidth=1,linestyle='--', alpha=0.8)             

axes.plot(df_UNI_from_Exp_015RANDOMoutput.loc[:34,'ScenarioID'].values, df_UNI_from_Exp_015RANDOMoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=0.8,linestyle='--', label="15% Alteration")
axes.plot(df_UNI_from_Exp_015RANDOMoutput.loc[35:70,'ScenarioID'].values, df_UNI_from_Exp_015RANDOMoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=0.8,linestyle='--')
axes.plot(df_UNI_from_Exp_015RANDOMoutput.loc[71:,'ScenarioID'].values, df_UNI_from_Exp_015RANDOMoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=0.8,linestyle='--')

axes.plot(df_UNI_from_Exp_02RANDOMoutput.loc[:34,'ScenarioID'].values, df_UNI_from_Exp_02RANDOMoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='+',markersize=5,color="green", linewidth=1, alpha=0.8,linestyle='--', label="20% Alteration")   
axes.plot(df_UNI_from_Exp_02RANDOMoutput.loc[35:70,'ScenarioID'].values, df_UNI_from_Exp_02RANDOMoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='+',markersize=5,color="green", linewidth=1, alpha=0.8,linestyle='--')   
axes.plot(df_UNI_from_Exp_02RANDOMoutput.loc[71:,'ScenarioID'].values, df_UNI_from_Exp_02RANDOMoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='+',markersize=5,color="green", linewidth=1, alpha=0.8,linestyle='--')   
  

L=[] # Finding changing Mu points on x-axis
for Mu, df in df_UNI_from_Exp_02RANDOMoutput.groupby('Mu'):  
    L.append(df.shape[0])
plt.axvline(x=L[2]-0.5,linewidth=1, color='dimgrey', alpha=0.5,ls ="--")     
plt.axvline(x=L[2]+L[1]-0.5,linewidth=1, color='dimgrey', alpha=0.5,ls ="--")    

plt.axhline(y = 0,linewidth=1, color='dimgrey', alpha=0.5,ls ="--")

plt.legend(fontsize=24)
axes.yaxis.set_major_formatter(FuncFormatter(lambda y, _: '{:.0%}'.format(y))) 
plt.yticks(fontsize=24) 
axes.tick_params(axis='x', which='both', length=0)
plt.xticks([18, 54, 90],fontsize=24)  
axes.set_xticklabels(["6 Months","9 Months", "12 Months"])
plt.xlabel("Expected Replenishment Duration",fontsize=24)
plt.ylabel("Gap in Average Cost",fontsize=24)
plt.setp(axes.spines.values(), linewidth=0.1) 
fig.set_size_inches(22, 11)
fig.savefig("UnifromEXP_Rand_Mu_dif", dpi=300,bbox_inches = 'tight')     
# =========================Optimal_vs_NonOptimalUNI_from_Exp========================================

fig,axes=plt.subplots()
axes.plot(df_UNI_from_Exp_005SYSTEMATICoutput.loc[:34,'ScenarioID'].values, df_UNI_from_Exp_005SYSTEMATICoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='v',markersize=5,color="darkorange", linewidth=1, alpha=0.8,linestyle='--', label="5% Alteration")
axes.plot(df_UNI_from_Exp_005SYSTEMATICoutput.loc[35:70,'ScenarioID'].values, df_UNI_from_Exp_005SYSTEMATICoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='v',markersize=5,color="darkorange", linewidth=1, alpha=0.8,linestyle='--')
axes.plot(df_UNI_from_Exp_005SYSTEMATICoutput.loc[71:,'ScenarioID'].values, df_UNI_from_Exp_005SYSTEMATICoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='v',markersize=5,color="darkorange", linewidth=1, alpha=0.8,linestyle='--')
            
axes.plot(df_UNI_from_Exp_01SYSTEMATICoutput.loc[:34,'ScenarioID'].values, df_UNI_from_Exp_01SYSTEMATICoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='*',markersize=5,color="steelblue", linewidth=1,linestyle='--', alpha=0.8, label="10% Alteration")
axes.plot(df_UNI_from_Exp_01SYSTEMATICoutput.loc[35:70,'ScenarioID'].values, df_UNI_from_Exp_01SYSTEMATICoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='*',markersize=5,color="steelblue", linewidth=1,linestyle='--', alpha=0.8)
axes.plot(df_UNI_from_Exp_01SYSTEMATICoutput.loc[71:,'ScenarioID'].values, df_UNI_from_Exp_01SYSTEMATICoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='*',markersize=5,color="steelblue", linewidth=1,linestyle='--', alpha=0.8)

axes.plot(df_UNI_from_Exp_015SYSTEMATICoutput.loc[:34,'ScenarioID'].values, df_UNI_from_Exp_015SYSTEMATICoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=0.8,linestyle='--', label="15% Alteration")
axes.plot(df_UNI_from_Exp_015SYSTEMATICoutput.loc[35:70,'ScenarioID'].values, df_UNI_from_Exp_015SYSTEMATICoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=0.8,linestyle='--')
axes.plot(df_UNI_from_Exp_015SYSTEMATICoutput.loc[71:,'ScenarioID'].values, df_UNI_from_Exp_015SYSTEMATICoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=0.8,linestyle='--')

axes.plot(df_UNI_from_Exp_02SYSTEMATICoutput.loc[:34,'ScenarioID'].values, df_UNI_from_Exp_02SYSTEMATICoutput.loc[:34,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='+',markersize=5,color="green", linewidth=1, alpha=0.8,linestyle='--', label="20% Alteration")   
axes.plot(df_UNI_from_Exp_02SYSTEMATICoutput.loc[35:70,'ScenarioID'].values, df_UNI_from_Exp_02SYSTEMATICoutput.loc[35:70,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='+',markersize=5,color="green", linewidth=1, alpha=0.8,linestyle='--')   
axes.plot(df_UNI_from_Exp_02SYSTEMATICoutput.loc[71:,'ScenarioID'].values, df_UNI_from_Exp_02SYSTEMATICoutput.loc[71:,[('Percent_Difference_Total_With_Optimal', '')]].values,marker='+',markersize=5,color="green", linewidth=1, alpha=0.8,linestyle='--')   

L=[] # Finding changing Mu points on x-axis
for Mu, df in df_UNI_from_Exp_02SYSTEMATICoutput.groupby('Mu'):  
    L.append(df.shape[0])
plt.axvline(x=L[2]-0.5,linewidth=1, color='dimgrey', alpha=0.5,ls ="--")     
plt.axvline(x=L[2]+L[1]-0.5,linewidth=1, color='dimgrey', alpha=0.5,ls ="--")  

plt.axhline(y = 0,linewidth=1, color='dimgrey', alpha=0.5,ls ="--")
 
plt.legend(fontsize=24)
axes.yaxis.set_major_formatter(FuncFormatter(lambda y, _: '{:.0%}'.format(y))) 
plt.yticks(fontsize=24) 
axes.tick_params(axis='x', which='both', length=0)
plt.xticks([18, 54, 90],fontsize=24) 
axes.set_xticklabels(["6 Months","9 Months", "12 Months"])
plt.xlabel("Expected Replenishment Duration",fontsize=24)
plt.ylabel("Gap in Average Cost",fontsize=24)
plt.setp(axes.spines.values(), linewidth=0.1)  
fig.set_size_inches(22, 11)
fig.savefig("UnifromEXP_Sys_Mu_dif", dpi=300,bbox_inches = 'tight')
# ===================Compare_Distributions====================================  
#    create pandas dataframe for results of each distribution  & Sort them based on Mu & Total Cost of Exponential, and sort other distribution based on it
df_EXP = Grouped_df_output.loc[pd.IndexSlice[:,["EXPONENTIAL"]],:]
df_LOG = Grouped_df_output.loc[pd.IndexSlice[:,["LOGNORMAL"]],:]
df_UNI_from_Exp = Grouped_df_output.loc[pd.IndexSlice[:,["UNIFORMFROMEXPO"]],:]
  
df_EXP = pd.merge(df_Sim, df_EXP, on=['ScenarioID'], how='right')
df_LOG = pd.merge(df_Sim, df_LOG, on=['ScenarioID'], how='right')
df_UNI_from_Exp = pd.merge(df_Sim, df_UNI_from_Exp, on=['ScenarioID'], how='right')

df_EXP = df_EXP.set_index('ScenarioID')
df_EXP = df_EXP.sort_values(['Mu',('TotalCost','mean')],ascending=[False,True])
df_EXP = df_EXP.reset_index()
   
df_LOG = df_LOG.set_index('ScenarioID')
df_LOG = df_LOG.reindex(index=df_EXP['ScenarioID'])
df_LOG = df_LOG.reset_index()

df_UNI_from_Exp = df_UNI_from_Exp.set_index('ScenarioID')
df_UNI_from_Exp = df_UNI_from_Exp.reindex(index=df_EXP['ScenarioID'])
df_UNI_from_Exp = df_UNI_from_Exp.reset_index()

#     ==========================All_Distributions_Total Cost========================================   
fig,axes=plt.subplots()

axes.plot(df_EXP.loc[:34,'ScenarioID'].values, df_EXP.loc[:34,[('TotalCost','mean')]].values, marker='x',markersize=5,color="darkorange", linewidth=1, alpha=1,linestyle='--',label="Exponential")
axes.plot(df_EXP.loc[35:70,'ScenarioID'].values, df_EXP.loc[35:70,[('TotalCost','mean')]].values, marker='x',color="darkorange",markersize=5, linewidth=1, alpha=1,linestyle='--')
axes.plot(df_EXP.loc[71:,'ScenarioID'].values, df_EXP.loc[71:,[('TotalCost','mean')]].values, marker='x',color="darkorange",markersize=5, linewidth=1, alpha=1,linestyle='--')
    
axes.plot(df_LOG.loc[:34,'ScenarioID'].values, df_LOG.loc[:34,[('TotalCost','mean')]].values, marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=1,linestyle='--',label="Lognormal")
axes.plot(df_LOG.loc[35:70,'ScenarioID'].values, df_LOG.loc[35:70,[('TotalCost','mean')]].values, marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=1,linestyle='--')
axes.plot(df_LOG.loc[71:,'ScenarioID'].values, df_LOG.loc[71:,[('TotalCost','mean')]].values, marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=1,linestyle='--')

axes.plot(df_UNI_from_Exp.loc[:34,'ScenarioID'].values, df_UNI_from_Exp.loc[:34,[('TotalCost','mean')]].values, marker='x',markersize=5,color="green", linewidth=1, alpha=1,linestyle='--',label="Uniform")
axes.plot(df_UNI_from_Exp.loc[35:70,'ScenarioID'].values, df_UNI_from_Exp.loc[35:70,[('TotalCost','mean')]].values, marker='x',markersize=5,color="green", linewidth=1, alpha=1,linestyle='--')
axes.plot(df_UNI_from_Exp.loc[71:,'ScenarioID'].values, df_UNI_from_Exp.loc[71:,[('TotalCost','mean')]].values, marker='x',markersize=5,color="green", linewidth=1, alpha=1,linestyle='--')
 
L=[] # Finding changing Mu points on x-axis
for Mu, df in df_EXP.groupby('Mu'):  
    L.append(df.shape[0])
plt.axvline(x=L[2]-0.5,linewidth=1, color='dimgrey', alpha=0.5,ls="--")     
plt.axvline(x=L[2]+L[1]-0.5,linewidth=1, color='dimgrey', alpha=0.5,ls="--") 
   
plt.legend(fontsize=24)
plt.yscale("log")
plt.ylabel("Average Total Cost",fontsize=24) 
plt.xticks([18, 54, 90],fontsize=24) 
plt.yticks(fontsize=24) 
axes.set_xticklabels(["6 Months","9 Months", "12 Months"])
plt.xlabel("Expected Replenishment Duration",fontsize=24)
plt.setp(axes.spines.values(), linewidth=0.1) 
axes.tick_params(axis='x', which='both', length=0)
fig.set_size_inches(22, 11)
fig.savefig("Total_Cost", dpi=300,bbox_inches = 'tight')    
# ==========================All_Distributions_Deprivation Cost========================================    
fig,axes=plt.subplots()

axes.plot(df_EXP.loc[:34,'ScenarioID'].values, df_EXP.loc[:34,[('deprivationCost','mean')]].values, marker='x',markersize=5,color="darkorange", linewidth=1, alpha=1,linestyle='--',label="Exponential")
axes.plot(df_EXP.loc[35:70,'ScenarioID'].values, df_EXP.loc[35:70,[('deprivationCost','mean')]].values, marker='x',color="darkorange",markersize=5, linewidth=1, alpha=1,linestyle='--')
axes.plot(df_EXP.loc[71:,'ScenarioID'].values, df_EXP.loc[71:,[('deprivationCost','mean')]].values, marker='x',color="darkorange",markersize=5, linewidth=1, alpha=1,linestyle='--')
    
axes.plot(df_LOG.loc[:34,'ScenarioID'].values, df_LOG.loc[:34,[('deprivationCost','mean')]].values, marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=1,linestyle='--',label="Lognormal")
axes.plot(df_LOG.loc[35:70,'ScenarioID'].values, df_LOG.loc[35:70,[('deprivationCost','mean')]].values, marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=1,linestyle='--')
axes.plot(df_LOG.loc[71:,'ScenarioID'].values, df_LOG.loc[71:,[('deprivationCost','mean')]].values, marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=1,linestyle='--')

axes.plot(df_UNI_from_Exp.loc[:34,'ScenarioID'].values, df_UNI_from_Exp.loc[:34,[('deprivationCost','mean')]].values, marker='x',markersize=5,color="green", linewidth=1, alpha=1,linestyle='--',label="Uniform")
axes.plot(df_UNI_from_Exp.loc[35:70,'ScenarioID'].values, df_UNI_from_Exp.loc[35:70,[('deprivationCost','mean')]].values, marker='x',markersize=5,color="green", linewidth=1, alpha=1,linestyle='--')
axes.plot(df_UNI_from_Exp.loc[71:,'ScenarioID'].values, df_UNI_from_Exp.loc[71:,[('deprivationCost','mean')]].values, marker='x',markersize=5,color="green", linewidth=1, alpha=1,linestyle='--')

L=[] # Finding changing Mu points on x-axis
for Mu, df in df_EXP.groupby('Mu'):  
    L.append(df.shape[0])
plt.axvline(x=L[2]-0.5,linewidth=1, color='dimgrey', alpha=0.5,ls="--")     
plt.axvline(x=L[2]+L[1]-0.5,linewidth=1, color='dimgrey', alpha=0.5,ls="--") 

plt.legend(fontsize=24)
plt.yscale("log")
plt.ylabel("Average Deprivation Cost",fontsize=24) 
plt.xticks([18, 54, 90],fontsize=24) 
plt.yticks(fontsize=24) 
axes.set_xticklabels(["6 Months","9 Months", "12 Months"])
plt.xlabel("Expected Replenishment Duration",fontsize=24)
plt.setp(axes.spines.values(), linewidth=0.1) 
axes.tick_params(axis='x', which='both', length=0)
fig.set_size_inches(22, 11)
fig.savefig("Deprivation_Cost", dpi=300,bbox_inches = 'tight')
# =========================All_Distributions_holding===============================================
fig,axes=plt.subplots()

axes.plot(df_EXP.loc[:34,'ScenarioID'].values, df_EXP.loc[:34,[('holdingCost','mean')]].values, marker='x',markersize=5,color="darkorange", linewidth=1, alpha=1,linestyle='--',label="Exponential")
axes.plot(df_EXP.loc[35:70,'ScenarioID'].values, df_EXP.loc[35:70,[('holdingCost','mean')]].values, marker='x',color="darkorange",markersize=5, linewidth=1, alpha=1,linestyle='--')
axes.plot(df_EXP.loc[71:,'ScenarioID'].values, df_EXP.loc[71:,[('holdingCost','mean')]].values, marker='x',color="darkorange",markersize=5, linewidth=1, alpha=1,linestyle='--')
    
axes.plot(df_LOG.loc[:34,'ScenarioID'].values, df_LOG.loc[:34,[('holdingCost','mean')]].values, marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=1,linestyle='--',label="Lognormal")
axes.plot(df_LOG.loc[35:70,'ScenarioID'].values, df_LOG.loc[35:70,[('holdingCost','mean')]].values, marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=1,linestyle='--')
axes.plot(df_LOG.loc[71:,'ScenarioID'].values, df_LOG.loc[71:,[('holdingCost','mean')]].values, marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=1,linestyle='--')

axes.plot(df_UNI_from_Exp.loc[:34,'ScenarioID'].values, df_UNI_from_Exp.loc[:34,[('holdingCost','mean')]].values, marker='x',markersize=5,color="green", linewidth=1, alpha=1,linestyle='--',label="Uniform")
axes.plot(df_UNI_from_Exp.loc[35:70,'ScenarioID'].values, df_UNI_from_Exp.loc[35:70,[('holdingCost','mean')]].values, marker='x',markersize=5,color="green", linewidth=1, alpha=1,linestyle='--')
axes.plot(df_UNI_from_Exp.loc[71:,'ScenarioID'].values, df_UNI_from_Exp.loc[71:,[('holdingCost','mean')]].values, marker='x',markersize=5,color="green", linewidth=1, alpha=1,linestyle='--')

L=[] # Finding changing Mu points on x-axis
for Mu, df in df_EXP.groupby('Mu'):  
    L.append(df.shape[0])
plt.axvline(x=L[2]-0.5,linewidth=1, color='dimgrey', alpha=0.5,ls="--")     
plt.axvline(x=L[2]+L[1]-0.5,linewidth=1, color='dimgrey', alpha=0.5,ls="--") 

axes.set_yscale("log")  
axes.minorticks_off()    
f = mticker.ScalarFormatter(useOffset=False, useMathText=True)
g = lambda x,pos : "${}$".format(f._formatSciNotation('%1.10e' % x))
fmt = mticker.FuncFormatter(g)
plt.yticks([0.25e5,0.5e5,1e5,2e5],fontsize=24)    
axes.set_yticklabels([fmt(0.25e5),fmt(0.5e5),fmt(1e5),fmt(2e5)])
#
plt.yticks(fontsize=24)  
plt.legend(fontsize=24)
plt.ylabel("Average Holding Cost",fontsize=24) 
plt.xticks([18, 54, 90],fontsize=24)  
axes.set_xticklabels(["6 Months","9 Months", "12 Months"])
plt.xlabel("Expected Replenishment Duration",fontsize=24)
plt.setp(axes.spines.values(), linewidth=0.1) 
axes.tick_params(axis='x', which='both', length=0)
fig.set_size_inches(22, 11)
fig.savefig("Holding_Cost", dpi=300,bbox_inches = 'tight')   

#    # =========================All_Distributions_referral===============================================
fig,axes=plt.subplots()

axes.plot(df_EXP.loc[:34,'ScenarioID'].values, df_EXP.loc[:34,[('referralCost','mean')]].values, marker='x',markersize=5,color="darkorange", linewidth=1, alpha=1,linestyle='--',label="Exponential")
axes.plot(df_EXP.loc[35:70,'ScenarioID'].values, df_EXP.loc[35:70,[('referralCost','mean')]].values, marker='x',color="darkorange",markersize=5, linewidth=1, alpha=1,linestyle='--')
axes.plot(df_EXP.loc[71:,'ScenarioID'].values, df_EXP.loc[71:,[('referralCost','mean')]].values, marker='x',color="darkorange",markersize=5, linewidth=1, alpha=1,linestyle='--')
    
axes.plot(df_LOG.loc[:34,'ScenarioID'].values, df_LOG.loc[:34,[('referralCost','mean')]].values, marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=1,linestyle='--',label="Lognormal")
axes.plot(df_LOG.loc[35:70,'ScenarioID'].values, df_LOG.loc[35:70,[('referralCost','mean')]].values, marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=1,linestyle='--')
axes.plot(df_LOG.loc[71:,'ScenarioID'].values, df_LOG.loc[71:,[('referralCost','mean')]].values, marker='x',markersize=5,color="mediumpurple", linewidth=1, alpha=1,linestyle='--')

axes.plot(df_UNI_from_Exp.loc[:34,'ScenarioID'].values, df_UNI_from_Exp.loc[:34,[('referralCost','mean')]].values, marker='x',markersize=5,color="green", linewidth=1, alpha=1,linestyle='--',label="Uniform")
axes.plot(df_UNI_from_Exp.loc[35:70,'ScenarioID'].values, df_UNI_from_Exp.loc[35:70,[('referralCost','mean')]].values, marker='x',markersize=5,color="green", linewidth=1, alpha=1,linestyle='--')
axes.plot(df_UNI_from_Exp.loc[71:,'ScenarioID'].values, df_UNI_from_Exp.loc[71:,[('referralCost','mean')]].values, marker='x',markersize=5,color="green", linewidth=1, alpha=1,linestyle='--')

L=[] # Finding changing Mu points on x-axis
for Mu, df in df_EXP.groupby('Mu'):  
    L.append(df.shape[0])
plt.axvline(x=L[2]-0.5,linewidth=1, color='dimgrey', alpha=0.5,ls="--")     
plt.axvline(x=L[2]+L[1]-0.5,linewidth=1, color='dimgrey', alpha=0.5,ls="--") 

   
plt.legend(fontsize=24)
plt.yscale("log")

axes.minorticks_off()    
f = mticker.ScalarFormatter(useOffset=False, useMathText=True)
g = lambda x,pos : "${}$".format(f._formatSciNotation('%1.10e' % x))
fmt = mticker.FuncFormatter(g)
plt.yticks([0.5e5,1e5,2e5,5e5],fontsize=24)    
axes.set_yticklabels([fmt(0.5e5),fmt(1e5),fmt(2e5),fmt(5e5)])
plt.ylabel("Average Referral Cost",fontsize=24) 
plt.xticks([18, 54, 90],fontsize=24) 
axes.set_xticklabels(["6 Months","9 Months", "12 Months"])
plt.xlabel("Expected Replenishment Duration",fontsize=24)
plt.setp(axes.spines.values(), linewidth=0.1) 
axes.tick_params(axis='x', which='both', length=0)
fig.set_size_inches(22, 11)
fig.savefig("Referral_Cost", dpi=300,bbox_inches = 'tight')
# =============================================================================

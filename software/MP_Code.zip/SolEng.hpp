//Last edited 2019/1/1

//#include Declarations
#include <cplex.h>
#include <string>
#include <fstream>
#include <iostream>
#include <sstream>
#include <algorithm>

#include <math.h>
#include <time.h>

#include <stdio.h>
#include <stdlib.h>
#include <cstdlib>

#include <vector>
#include <list>

using namespace std;

template <typename someType>
static void DeleteAndNullify (someType** someTypePtr) {
	if (*someTypePtr != NULL) {
		delete [] *someTypePtr;
		*someTypePtr = NULL;
	}
}

template <typename someType>
static void DeleteAndNullifySingleElement (someType** someTypePtr) {
	if (*someTypePtr != NULL) {
		delete *someTypePtr;
		*someTypePtr = NULL;
	}
}

template <typename someType>
static void DeleteAndNullifyTypeTwo (someType* someTypePtr) {
	if (someTypePtr != NULL) {
		delete [] someTypePtr;
		someTypePtr = NULL;
	}
}

template <typename someType>
static void ZeroOutArray(someType* someArray, int someUpperLimit) {
  for (int k = 0; k < someUpperLimit; k++)
		someArray[k] = 0;
}

class optDiverseSolInfo{
  public:
  int rank;
  int num_x_Cols;
  int num_u_Cols;
  int numCols;
  int nonDivVarCnt;
  double eps;
  double* optSol;
  double* card;
  double* resCard;
  double* cost;
  double optObjVal;
  double Nx;
  double Dx;
  double curLambda;
  double quality;
  double maxCard;
  double maxResCard;
  double smallSmoothVioCnt;
  double largeSmoothVioCnt;
  double rollingDiv;
  int solutionStatus;
  bool fail;
  int loop;
};

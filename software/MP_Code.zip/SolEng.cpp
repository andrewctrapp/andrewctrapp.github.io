//Last edited 2019/1/1
//Code written by Andy Trapp, Ph.D., in collaboration with Dr. Thierry Petit
//Worcester Polytechnic Institute

//This is C++ code to identify diverse optima and near-optima, infused with a single quality notion, for binary integer optimization problems
//It is an adaptation from the earlier Trapp and Konrad (2015) paper on finding diverse optima and near-optima to binary integer programs
//Because it incorporates a single quality notion into the objective function, it is fundamentally different and distinct, and is heavily customized
//That is, rather than maximizing the diversity/loss ratio as in Trapp and Konrad (2015), it instead minimizes the inverse ((quality + loss) / diversity)
//Hence, it helps that all of the chosen quality notions are to be minimized
//The code requires the CPLEX optimizer and callable library to compile and run

#include "SolEng.hpp"

#define SCREENDISPLAY 0
#define WRITELPOUTPUT 0
#define DINKOUTPUT 0

//We are doing experiments to generate 5 sets of quality notions:
//Set #1: Original problem, no quality notion.
//Set #2: Q2 : Maximal cardinality distance among any two agents.
//Set #3: Q3 : Maximal resource distance among two agents.
//Set #4: Q4 : Smooth violations between sequential jobs, gap =15.
//Set #5: Q5 : Smooth violations between sequential jobs, gap =5.

#define NOSMOOTHVIO 0
#define SMALLSMOOTHVIO 5
#define LARGESMOOTHVIO 15

//CHOOSE EXACTLY ONE!
//#define GAP_MINMAXDIFFCARDPAIRS 0 //This is for set #2
#define GAP_MINMAXDIFFWEIGHTPAIRS 0 //This is for set #3
//#define GAP_SMOOTHVIOLATIONS NOSMOOTHVIO //For this option, use actual threshold violation value (e.g., 5, 15)  //This is for sets #4 (SMALLSMOOTHVIO) and #5 (LARGESMOOTHVIO)
//ALSO: If I want to just do objective function and diversity, set coefficient "b" (quality) = 0

//This defines "percent from optimal" within which all solutions subsequent to optima need to subscribe
#define OBJCUTVAL 0
#define OBJCUT OBJCUTVAL
//#define OBJCUT 0

time_t timez;
time_t time_of_output_file;
stringstream myss;
string fileString;
const char* temp_lp_name;
const char* temp_output_file_name;

double RoundToNearestInteger(double num) {
  return (num < 0.0) ? ceil(num - 0.5) : floor(num + 0.5);
}

optDiverseSolInfo IntegerizeWithinEpsilon(optDiverseSolInfo solContainer) {

  //Function prototypes
  double RoundToNearestInteger(double);

  for (int i = 0; i < solContainer.numCols; i++) {
    double nearestIntValue = RoundToNearestInteger(solContainer.optSol[i]);
    if ((fabs(solContainer.optSol[i] - nearestIntValue)) < solContainer.eps)
      solContainer.optSol[i] = nearestIntValue;
  }
  return (solContainer);
}

optDiverseSolInfo EvalQuality(CPXENVptr env, CPXLPptr BIP, optDiverseSolInfo solContainer) {

  //Update value of quality according to current variable assignments
  solContainer.quality = 0;
  for (int h = (CPXgetnumcols(env,BIP) - solContainer.nonDivVarCnt); h < CPXgetnumcols(env,BIP); h++)
    solContainer.quality += solContainer.optSol[h];

  return (solContainer);
}

bool CompareLambdaValues(optDiverseSolInfo A, optDiverseSolInfo B) {
  return (A.curLambda < B.curLambda);
}

int main(int argc, char* argv[]) {

  //The main function contains the main outer code of Algorithm 2, which does three main things:
  //1) It receives the input parameters of the original (external) call;
  //2) It finds an initial optimal solution x* and objective function value z*
  //3) It calls Dinkelbach's algorithm ("Kappa"-1) times to find consecutive diverse and high-quality solutions, completing when done or after a time-limit

  //Function prototypes
  optDiverseSolInfo SolveMIP(CPXENVptr, CPXLPptr, list<optDiverseSolInfo> &, optDiverseSolInfo, bool);
  void CutOffLastSol(CPXENVptr, CPXLPptr, int, vector<optDiverseSolInfo>);
  optDiverseSolInfo DinkFunc(CPXENVptr, CPXLPptr, const char*, int &, double, int, double*, double, double, double, double, double*, list<optDiverseSolInfo> &, optDiverseSolInfo &, vector<optDiverseSolInfo>);
  void ComputeCentroid(vector<optDiverseSolInfo>, double*);
  void OutputToFile(ostream&, char*, int, int, int, double, double, double, int, double, double*, double*, double, vector<optDiverseSolInfo>);
  void OutputForPython(ostream&, char*, int, int, int, int, int, double, double, double, int, double, double*, double*, double*, double*, double, vector<optDiverseSolInfo>);
  void OutputErrorMessage(ostream&, int, double, const char*, int, vector<optDiverseSolInfo>);

  clock_t overallStart = clock();       //Begin recording time

  //Open solutionsOut file
  ofstream solutionsOut("solutionsOut.txt", ios::app);
  
  int Kappa;

  int status;
  double eps = 1E-6;

  int totalDinkLoops = 0;

  CPXENVptr env = NULL;    //Constant pointer to the CPLEX environment
  CPXLPptr BIP = NULL;      //pointer to a problem object named "BIP"

  //open CPLEX environment
  env = CPXopenCPLEX(&status);

  //Create problem instance
  BIP = CPXcreateprob(env, &status, "BIP");

  char* lp_name = NULL;

  Kappa = 51;

//ORIGINAL VALUES:
  double a = 500; //(formerly D) diversity coefficient
  double b = 0; //(formerly Q) quality coefficient
  double c = 1; //(formerly L) objective coefficient

  double timeLimit = 300.0; // 5 minutes

  //*********************************************************************************
  //NOTE: THIS IS A DIRECT CUSTOMIZATION TO THE GENERALIZED ASSIGNMENT PROBLEM (GAP)
  //IT WILL FAIL IF THE OPTIMIZATION PROBLEM IS NOT A GAP
  //*********************************************************************************

  //*************************************************************************************
  //BEGIN: Rather than read file, we will build GAP instance (to control variable order)
  //*************************************************************************************
  
    //Begin by reading in gap data from Beasley's OR library here: http://people.brunel.ac.uk/~mastjjb/jeb/orlib/gapinfo.html
    char* TI_name = NULL;
    TI_name = (char*)"gapa1.dat";
//    TI_name = "gapa2.dat";
//    TI_name = "gapa3.dat";
//    TI_name = "gapa4.dat";
//    TI_name = "gapa5.dat";
//    TI_name = "gapa6.dat";
//    TI_name = "gaptoy.dat";

    //Format is:
    //m n //# of agents, # of jobs
    //objective coefficients for agent 1 to jobs 1, ..., n
    //objective coefficients for agent 2 to jobs 1, ..., n
    //...
    //constraint coefficients for agent 1 to jobs 1, ..., n
    //constraint coefficients for agent 2 to jobs 1, ..., n
    //...
    //rhs values

    //Declare variables to read .dat input files
    string line;
    string token;
    stringstream iss;

    //Declare gap instance problem variables
    int numAgents;
    int numJobs;

    ifstream input_file(TI_name, ios::in);

    if (!input_file) {
      cerr << "File could not be opened.\n";
      exit(1);
    }

    //Read first line of input_file to get m (numAgents) and n (numJobs)
    getline (input_file, line);
    iss << line;

    getline (iss, token, ' '); //Grab the first element, the number of agents
    numAgents = atoi(token.c_str());
    getline (iss, token, ' '); //Grab the second element, the number of jobs
    numJobs = atoi(token.c_str());

    double* cObj = new double[numAgents*numJobs];
    double* aRow = new double[numAgents*numJobs];
    double* bRHS = new double[numAgents];

    //Clear line buffer
    iss.clear(); iss.str("");

    //Read objective function coefficients
    for (int i = 0; i < numAgents; i++) {
      int j = 0;
      while (j < numJobs) {

        //Begin reading objective coefficient data, line by line
        getline (input_file, line);
        iss << line;

        while(getline(iss, token, ' ')) { //Tokenize the line to rip out objective coefficients
          cObj[i*numJobs + j] = atof(token.c_str());
          j++;
        }

        //Clear line buffer
        iss.clear(); iss.str("");
      }
    }

    //Read resource usage coefficients
    for (int i = 0; i < numAgents; i++) {
      int j = 0;
      while (j < numJobs) {

        //Begin reading objective coefficient data, line by line
        getline (input_file, line);
        iss << line;

        while(getline(iss, token, ' ')) { //Tokenize the line to rip out objective coefficients
          aRow[i*numJobs + j] = atof(token.c_str());
          j++;
        }
        //Clear line buffer
        iss.clear(); iss.str("");
      }
    }

    //Read capacity coefficients (rhs values)
    int i = 0;
    while (i < numAgents) {

      //Begin reading objective coefficient data, line by line
      getline (input_file, line);
      iss << line;

      while(getline(iss, token, ' ')) { //Tokenize the line to rip out objective coefficients
        bRHS[i] = atof(token.c_str());
        i++;
      }
      //Clear line buffer
      iss.clear(); iss.str("");
    }

    input_file.close();


    //Now that we have all input data, build the gap optimization model

    //********************************
    //BEGIN: Add binary xij variables
    //********************************
   
      //Create dynamic arrays
      double* objIP = new double[1];
      double* lbIP = new double[1];
      double* ubIP = new double[1];
      char* varName[1];
      char buffer[100];
      
      //These stay constant for all but final variables
      lbIP[0] = 0;
      ubIP[0] = 1;

      //Set bounds, objective coefficients, and names for xij variables
      varName[0] = buffer;
      for (int i = 0; i < numAgents; i++) {
        for (int j = 0; j < numJobs; j++) {
          objIP[0] = cObj[i*numJobs + j];
          sprintf(buffer, "x(%d)(%d)", i, j);
          status = CPXaddcols(env, BIP, 1, 0, objIP, NULL, NULL, NULL, lbIP, ubIP, varName);
        }
      }

      //Delete and nullify dynamic memory
      DeleteAndNullifyTypeTwo(objIP);
      DeleteAndNullifyTypeTwo(lbIP);
      DeleteAndNullifyTypeTwo(ubIP);

    //******************************
    //END: Add binary xij variables
    //******************************

    //**********************************
    //BEGIN: Add assignment constraints
    //**********************************

      //Add constraints for ensuring all jobs are assigned
      int ccnt_Assign = 0;
      int rcnt_Assign = 1;
      int nzcnt_Assign = numAgents;

      char sense_Assign[1];//Creates new character array
      sense_Assign[0] = 'E';

      int rmatbeg_Assign[1];
      rmatbeg_Assign[0] = 0;

      double rhs_Assign[1];
      rhs_Assign[0] = 1;

      int* rmatind_Assign = new int[nzcnt_Assign];
      double* rmatval_Assign = new double[nzcnt_Assign];

      for (int j = 0; j < numJobs; j++) {
        for (int i = 0; i < numAgents; i++) {
          rmatind_Assign[i] = (i*numJobs) + j;
          rmatval_Assign[i] = 1;
        }
        status = CPXaddrows(env, BIP, ccnt_Assign, rcnt_Assign, nzcnt_Assign, rhs_Assign, sense_Assign, rmatbeg_Assign, rmatind_Assign, rmatval_Assign, NULL, NULL);
      }
  
      //Delete and nullify dynamic memory
      DeleteAndNullifyTypeTwo(rmatind_Assign);
      DeleteAndNullifyTypeTwo(rmatval_Assign);

    //**********************************
    //END: Add assignment constraints
    //**********************************

    //**************************************
    //BEGIN: Add resource usage constraints
    //**************************************

      //Add constraints for ensuring all jobs are assigned
      int ccnt_Usage = 0;
      int rcnt_Usage = 1;
      int nzcnt_Usage = numJobs;

      char sense_Usage[1];//Creates new character array
      sense_Usage[0] = 'L';

      int rmatbeg_Usage[1];
      rmatbeg_Usage[0] = 0;

      double rhs_Usage[1];

      int* rmatind_Usage = new int[nzcnt_Usage];
      double* rmatval_Usage = new double[nzcnt_Usage];

      for (int i = 0; i < numAgents; i++) {
        for (int j = 0; j < numJobs; j++) {
          rmatind_Usage[j] = (i*numJobs) + j;
          rmatval_Usage[j] = aRow[(i*numJobs) + j];
        }

        rhs_Usage[0] = bRHS[i];
        status = CPXaddrows(env, BIP, ccnt_Usage, rcnt_Usage, nzcnt_Usage, rhs_Usage, sense_Usage, rmatbeg_Usage, rmatind_Usage, rmatval_Usage, NULL, NULL);
      }

      //Delete and nullify dynamic memory
      DeleteAndNullifyTypeTwo(rmatind_Usage);
      DeleteAndNullifyTypeTwo(rmatval_Usage);

    //************************************
    //END: Add resource usage constraints
    //************************************

    //*********************************
    //BEGIN: Make all variables binary
    //*********************************

      int cnt = numAgents*numJobs;

      int *indices;
      indices = new int[cnt];

      char *xctype;
      xctype = new char[cnt];

      //Tell CPLEX which variables (indices) to change to what type ('B')
      for (int q = 0; q < cnt; q++) {
        *(indices + q) = q;
        *(xctype + q) = 'B';
      }

      //Change appropriate variables from continuous to binary
      status = CPXchgctype (env, BIP, cnt, indices, xctype);

      DeleteAndNullifyTypeTwo(indices);
      DeleteAndNullifyTypeTwo(xctype);

    //*******************************
    //END: Make all variables binary
    //*******************************

  //***********************************************************************************
  //END: Rather than read file, we will build GAP instance (to control variable order)
  //***********************************************************************************

  vector<optDiverseSolInfo> diverseSolVec;
  list<optDiverseSolInfo> knownSolPool;
  int numCols = CPXgetnumcols(env,BIP);
//  cout << "In main, numCols is: " << numCols << endl;

  optDiverseSolInfo oneSol;
  oneSol.optObjVal = 0;
  oneSol.numCols = numCols;
  oneSol.eps = eps;
  oneSol.optSol = new double[numCols];

  int nonDivVarCnt = 0;

  //Retrieve original objective function sense from BIP
  int origObjSen = CPXgetobjsen (env, BIP); //CPX_MAX = -1, CPX_MIN = 1

  //Retrieve original objective function coefficients from BIP (for use with objective deterioriation evaluation)
  double* origObj;
  origObj = new double[numCols];
  status = CPXgetobj(env, BIP, origObj, 0, numCols - 1);

  //Setting CPX_PARAM_EPGAP to 0.0 to find definite optimal solution (default is only 1E-6)
  status = CPXsetdblparam(env, CPX_PARAM_EPGAP, 0.0);
  status = CPXsetintparam(env, CPX_PARAM_CLOCKTYPE, 1);
  status = CPXsetdblparam(env, CPX_PARAM_TILIM, timeLimit);

  //status = CPXsetintparam(env, CPX_PARAM_THREADS, 12);

  #if SCREENDISPLAY
    status = CPXsetintparam(env, CPX_PARAM_MIPINTERVAL, 3600); //Set interval to display to screen
    status = CPXsetintparam(env, CPX_PARAM_MIPDISPLAY, 3);    //Set type of data to display to screen
    status = CPXsetintparam(env, CPX_PARAM_SCRIND, 1);        //Turn on screen display
  #endif

  #if WRITELPOUTPUT
    timez = time(0); // Get current time
    myss.str(std::string());
    myss.clear();
    myss << timez << ".lp";
    fileString = myss.str();
    temp_lp_name = fileString.c_str();
    status = CPXwriteprob(env, BIP, temp_lp_name, NULL);
  #endif

  //Solve BIP to get optimal values
  const char* subprob_name = "origOptProb";
  oneSol = SolveMIP(env, BIP, knownSolPool, oneSol, false);
  double origOptObjVal = oneSol.optObjVal;
  double* centroid = new double[numCols];

  //Check for a time limit code indicating optimization did not find a feasible solution within time limit:
  if (oneSol.solutionStatus == CPXMIP_TIME_LIM_INFEAS) {
    OutputErrorMessage(solutionsOut, 0, timeLimit, subprob_name, Kappa, diverseSolVec);
    OutputToFile(solutionsOut, TI_name, numCols, nonDivVarCnt, Kappa, a, b, c, origObjSen, origOptObjVal, origObj, centroid, overallStart, diverseSolVec);
    solutionsOut.close(); //Close solutionsOut file
    exit(1);
  }

  diverseSolVec.push_back(oneSol);   //Add x^{(0)^*} to X (i.e., diverseSolVec)
  ComputeCentroid(diverseSolVec, centroid);

  #if OBJCUT

    //This constrains all subsequent objective function values to be within a certain % (i.e., OBJCUTVAL) of optimal
    //There are two options:
    //Option 1: If CPX_MAX: -cTx \leq z^* * (1 - (OBJCUTVAL/100))
    //Option 2: If CPX_MIN: cTx \leq z^* * (1 + (OBJCUTVAL/100))

    int ccnt_objrow = 0;
    int rcnt_objrow = 1;

    int nzcnt_objrow = numCols;

    char sense_objrow[1];//Creates new character array
    sense_objrow[0] = 'L';

    int rmatbeg_objrow[1];
    rmatbeg_objrow[0] = 0;

    double rhs_objrow[1];
    if (origObjSen == 1) //Test for CPX_MIN
      rhs_objrow[0] = origOptObjVal * (1.0 + (double) ((double) OBJCUTVAL * 0.01));
    else //Must be CPX_MAX
      rhs_objrow[0] = origOptObjVal * ((double) ((double) OBJCUTVAL * 0.01) - 1.0);


    int* rmatind_objrow = new int[nzcnt_objrow];
    double* rmatval_objrow = new double[nzcnt_objrow];

    for (int h = 0; h < nzcnt_objrow; h++) {
      rmatind_objrow[h] = h;
      if (origObjSen == 1) //Test for CPX_MIN
        rmatval_objrow[h] = origObj[h];
      else //Must be CPX_MAX
        rmatval_objrow[h] = -1*origObj[h];
    }

    //Add row to cut off the previous solution
    status = CPXaddrows(env, BIP, ccnt_objrow, rcnt_objrow, nzcnt_objrow, rhs_objrow, sense_objrow, rmatbeg_objrow, rmatind_objrow, rmatval_objrow, NULL, NULL);

    DeleteAndNullifyTypeTwo(rmatind_objrow);
    DeleteAndNullifyTypeTwo(rmatval_objrow);

  #endif

  #if GAP_MINMAXDIFFWEIGHTPAIRS

    //Add new continuous q variable, to be minimized
    int ccnt_z = 1;
    int nzcnt_z = 0;
    double obj_z[1];
    double lb_z[1];
    double ub_z[1];

    obj_z[0] = 0;
    lb_z[0] = -CPX_INFBOUND;
    ub_z[0] = CPX_INFBOUND;
    char* qvarName[1];
    char qbuffer[100];
    qvarName[0] = qbuffer;
    sprintf(qbuffer, "q");

    status = CPXaddcols(env, BIP, ccnt_z, nzcnt_z, obj_z, NULL, NULL, NULL, lb_z, ub_z, qvarName);
    nonDivVarCnt++; //Increment number of new variables

    //Add m*(m-1) new constraints for the minimize maximum cardinality relationship
    int ccnt = 0;
    int rcnt = 1;
    int nzcnt = (2*numJobs) + 1;

    char sense[1];//Creates new character array
    sense[0] = 'L';

    int rmatbeg[1];
    rmatbeg[0] = 0;

    double rhs[1];
    rhs[0] = 0;

    int* rmatind = new int[nzcnt];
    double* rmatval = new double[nzcnt];

    for (int i = 0; i < numAgents; i++) {
      for (int k = 0; k < numAgents; k++) {
        if (i != k) {
          for (int j = 0; j < numJobs; j++) {
            rmatind[j] = (i*numJobs) + j;
            rmatval[j] = aRow[(i*numJobs) + j]; //Resource usage amounts
            rmatind[numJobs + j] = (k*numJobs) + j;
            rmatval[numJobs + j] = -1*aRow[(k*numJobs) + j]; //Resource usage amounts
          }
          rmatind[nzcnt-1] = CPXgetnumcols(env,BIP) - nonDivVarCnt; //Add the q variable
          rmatval[nzcnt-1] = -1;
          status = CPXaddrows(env, BIP, ccnt, rcnt, nzcnt, rhs, sense, rmatbeg, rmatind, rmatval, NULL, NULL);
        }
      }
    }

    //Delete and nullify dynamic memory
    DeleteAndNullifyTypeTwo(rmatind);
    DeleteAndNullifyTypeTwo(rmatval);

  #endif

  //Now that we are done with creating quality variations, delete and nullify...
  //Delete and nullify dynamic memory
  DeleteAndNullifyTypeTwo(bRHS);

  //************
  //BEGIN: DINK
  //************

  //This loop carries out Algorithm 2 in the paper, eventually calling Dinkelbach algorithm (Kappa-1) times, looking for high-quality yet diverse solutions
  while (diverseSolVec.size() < Kappa) { //Note: diverseSolVec already contains the original optimal solution

    cout << diverseSolVec.size() << endl;

    #if DINKOUTPUT
      cout << endl << "***********************************" << endl;
      cout << "Major it: " << diverseSolVec.size() << endl;
    #endif

    CutOffLastSol(env, BIP, nonDivVarCnt, diverseSolVec); //Cut off the last solution in diverseSolVec by adding a new cut on feasible region S

    //status = CPXwriteprob(env, BIP, "CutOffSol.lp", NULL);

    #if WRITELPOUTPUT
      timez = time(0); // Get current time
      myss.str(std::string());
      myss.clear();
      myss << timez << ".lp";
      fileString = myss.str();
      temp_lp_name = fileString.c_str();
      //status = CPXwriteprob(env, BIP, "AddedSolCut.lp", NULL);
      status = CPXwriteprob(env, BIP, temp_lp_name, NULL);
    #endif

    //**************************************
    //BEGIN: Call to Dinkelbach's algorithm
    //**************************************

      //Requires an initial feasible solution, and a normalization factor F (which we remove for this project -- like setting F=1 for Alg 1 of the paper); we'll compute an evolving numerator N(x) inside the DinkFunc

      //Container for optimal solution and optimal objective function value for each iteration of Dink's algorithm
      optDiverseSolInfo curDinkSolution;

      //Made decision to include TOTAL count of variables: numCols has original, structural variables, while nonDivVarCnt has new variable(s) representing quality

      curDinkSolution.numCols = numCols + nonDivVarCnt;
//      cout << "In main, curDinkSolution.numCols is: " << curDinkSolution.numCols << endl;

      curDinkSolution.nonDivVarCnt = nonDivVarCnt;

      curDinkSolution.eps = eps;
      curDinkSolution.optSol = new double[curDinkSolution.numCols];
      curDinkSolution.fail = false; //In case the Dinkelbach algorithm fails to find a solution

      curDinkSolution = DinkFunc(env, BIP, subprob_name, totalDinkLoops, 0, origObjSen, origObj, origOptObjVal, a, b, c, centroid, knownSolPool, curDinkSolution, diverseSolVec);
      if (curDinkSolution.fail == true) {
        OutputErrorMessage(solutionsOut, 0, timeLimit, subprob_name, Kappa, diverseSolVec);
        OutputToFile(solutionsOut, TI_name, numCols, nonDivVarCnt, Kappa, a, b, c, origObjSen, origOptObjVal, origObj, centroid, overallStart, diverseSolVec);
        solutionsOut.close(); //Close solutionsOut file
        exit(1);
      }

      diverseSolVec.push_back(curDinkSolution);
      ComputeCentroid(diverseSolVec, centroid);

    //************************************
    //END: Call to Dinkelbach's algorithm
    //************************************
  };

  cout << endl << "Total number of Dinkelbach iterations is: " << totalDinkLoops << endl;
  //cout << endl << "knownSolPool size is: " << knownSolPool.size() << endl;

  OutputToFile(solutionsOut, TI_name, numCols, nonDivVarCnt, Kappa, a, b, c, origObjSen, origOptObjVal, origObj, centroid, overallStart, diverseSolVec);
  solutionsOut.close(); //Close solutionsOut file

  //Write special filename
  stringstream filess;

  if (GAP_MINMAXDIFFWEIGHTPAIRS)
    filess << "pyout_Set3_obj_bound_within_percent_of_" << OBJCUT << "_" << TI_name << ".txt";
  else
    filess << "pyout_Set1_obj_bound_within_percent_of_" << OBJCUT << "_" << TI_name << ".txt";
  string fileString;
  fileString = filess.str();
  const char* fileStringOfChars = fileString.c_str();

  //Open solutionsOut file
  ofstream pyOut(fileStringOfChars, ios::trunc);

  OutputForPython(pyOut, TI_name, numAgents, numJobs, numCols, nonDivVarCnt, Kappa, a, b, c, origObjSen, origOptObjVal, origObj, aRow, cObj, centroid, overallStart, diverseSolVec);

  pyOut.close(); //Close pyOut file

  //Delete and nullify dynamic memory
  DeleteAndNullifyTypeTwo(aRow);
  DeleteAndNullifyTypeTwo(cObj);
  DeleteAndNullifyTypeTwo(oneSol.optSol);
  DeleteAndNullifyTypeTwo(origObj);
  //DeleteAndNullifyTypeTwo(negObjSol.optSol);

  status = CPXcloseCPLEX(&env);

  return 0;
}

optDiverseSolInfo DinkFunc(CPXENVptr env, CPXLPptr BIP, const char* subprob_name, int &totalDinkLoops, double initLambdaValue, int origObjSen, double* origObj, double origOptObjVal, double a, double b, double c, double* centroid, list<optDiverseSolInfo> &knownSolPool, optDiverseSolInfo &curDinkSolution, vector<optDiverseSolInfo> diverseSolVec) {

  //This function executes Dinkelbach's algorithm Algorithm 1 of Trapp and Konrad (2015)

  //Function prototypes
  double ComputeDinkDiv(double*, double*, vector<optDiverseSolInfo>);
  double ComputeDinkObjLoss(int, double, double*, optDiverseSolInfo);
  optDiverseSolInfo SolveMIP(CPXENVptr, CPXLPptr, list<optDiverseSolInfo> &, optDiverseSolInfo, bool);
  optDiverseSolInfo EvalQuality(CPXENVptr, CPXLPptr, optDiverseSolInfo);
  CPXLPptr UpdateDinkObjective(CPXENVptr, CPXLPptr, int, int, int*, double*, double, double, double, double, double*, double*, int, vector<optDiverseSolInfo>);

  int* dinkObjIndices = new int[curDinkSolution.numCols];
  double* dinkObjValues  = new double[curDinkSolution.numCols];

  //Setting CPX_PARAM_NUMERICALEMPHASIS to 1 attempts to correct for possible numerical instability...
  int status = CPXsetintparam(env, CPX_PARAM_NUMERICALEMPHASIS, 1);

  double FofLambda = 0;

  curDinkSolution.loop = 0;

  subprob_name = "dinkFuncProb";

  double lambda;

  #if DINKOUTPUT
    cout << "Coefficient a: " << a << ", coefficient b: " << b << ", coefficient c: " << c << endl;
  #endif

  //Dinkelbach's algorithm
  do {

    if (curDinkSolution.loop == 0)
      lambda = initLambdaValue;
    else {
      //Update quality evaluation
      curDinkSolution = EvalQuality(env, BIP, curDinkSolution);

      //Now compute lambda value for present iteration of Dinkelbach algorithm
      lambda = ((b/a)*curDinkSolution.quality + (c/a)*ComputeDinkObjLoss(origObjSen, origOptObjVal, origObj, curDinkSolution)) / ComputeDinkDiv(curDinkSolution.optSol, centroid, diverseSolVec);
    }

    #if DINKOUTPUT
      cout << "Minor it: " << curDinkSolution.loop << ", ";
      cout << "lambda: " << lambda << ", ";
    #endif

    BIP = UpdateDinkObjective(env, BIP, curDinkSolution.numCols, curDinkSolution.nonDivVarCnt, dinkObjIndices, dinkObjValues, a, b, c, lambda, origObj, centroid, origObjSen, diverseSolVec); //Change objective to [(b/a)*quality + (c/a)*objloss] - \lambda*div

    #if WRITELPOUTPUT
      timez = time(0); // Get current time
      myss.str(std::string());
      myss.clear();
      myss << timez << ".lp";
      fileString = myss.str();
      temp_lp_name = fileString.c_str();
      status = CPXwriteprob(env, BIP, temp_lp_name, NULL);
    #endif

    //Change the objective sense to MINIMIZATION! This is NOW A MINIMIZATION problem -- comes from minimizing the fractional objective of [(b/a)*quality + (c/a)*objloss] / diversity
    CPXchgobjsen(env, BIP, CPX_MIN);

    curDinkSolution = SolveMIP(env, BIP, knownSolPool, curDinkSolution, true); //Solves linearized objective over original feasible region + forbidden solution(s)

    //Check for a time limit code indicating optimization did not find a feasible solution within time limit:
    if (curDinkSolution.solutionStatus == CPXMIP_TIME_LIM_INFEAS)
      curDinkSolution.fail = true;
    if (curDinkSolution.fail == true)
      break;

    //Update quality evaluation
    curDinkSolution = EvalQuality(env, BIP, curDinkSolution);

    FofLambda = ((b/a)*curDinkSolution.quality + (c/a)*ComputeDinkObjLoss(origObjSen, origOptObjVal, origObj, curDinkSolution)) - lambda*ComputeDinkDiv(curDinkSolution.optSol, centroid, diverseSolVec);
    
    #if DINKOUTPUT
      cout << "F(lambda): " << FofLambda << endl;
    #endif

    curDinkSolution.loop++;
    totalDinkLoops++;

  } while(fabs(FofLambda) >= curDinkSolution.eps);

  curDinkSolution.optObjVal = lambda;

  DeleteAndNullifyTypeTwo(dinkObjIndices);
  DeleteAndNullifyTypeTwo(dinkObjValues);

  return(curDinkSolution);
}

double ComputeDinkDiv(double* baseSol, double* centroid, vector<optDiverseSolInfo> diverseSolVec) {

  //This is the numerator in Step 4 of Algorithm 1 in paper "Finding Diverse Optima and Near-Optima to Binary Integer Programs"

  int numCols = diverseSolVec[0].numCols; //This was the original variable count (numAgents*numJobs), not including q, the extra quality variable
//  cout << "In ComputeDinkDiv, numCols is: " << numCols << endl;


  double Nx = 0;

  for (int h = 0; h < numCols; h++)
    Nx += centroid[h] + (1 - (2*centroid[h])) * baseSol[h];

  return (Nx + 1); //In our last meetings in July 2017, Thierry and I agreed to make this epsilon the same, which for constraint programming works best when eps = 1
}

double ComputeDinkObjLoss(int origObjSen, double origOptObjVal, double* origObj, optDiverseSolInfo someSol) {

  int numCols = someSol.numCols - someSol.nonDivVarCnt; //This is only for the structural binary variables

  double Dx = origOptObjVal;

  //1) Compute inner product of original objective function coefficients with current solution "someSol", and subtract from Dx
  for (int h = 0; h < numCols; h++)
    Dx -= origObj[h] * someSol.optSol[h];

  if (origObjSen == CPX_MIN) //Account for potential minimization problem
    Dx *= -1;

  return Dx;
}

optDiverseSolInfo SolveMIP(CPXENVptr env, CPXLPptr BIP, list<optDiverseSolInfo> &knownSolPool, optDiverseSolInfo solContainer, bool fromNumOrDenomOrDink) {

  //This function solves a given MIP and returns an instance of class optDiverseSolInfo containing the optimal solution info

  //Function prototypes
  optDiverseSolInfo IntegerizeWithinEpsilon(optDiverseSolInfo);
  bool CheckIfNovel(optDiverseSolInfo, list<optDiverseSolInfo> &);


  //Optimize the problem!
  int status = CPXmipopt(env, BIP);

  solContainer.solutionStatus = CPXgetstat(env, BIP);

  if ((solContainer.solutionStatus == CPX_STAT_OPTIMAL) || (solContainer.solutionStatus == CPXMIP_OPTIMAL) || (solContainer.solutionStatus == CPXMIP_OPTIMAL_TOL) || (solContainer.solutionStatus == CPXMIP_TIME_LIM_FEAS)) {
    status = CPXgetmipobjval(env, BIP, &solContainer.optObjVal);

    status = CPXgetmipx(env, BIP, solContainer.optSol, 0, CPXgetnumcols(env,BIP) - 1);

  }

  solContainer = IntegerizeWithinEpsilon(solContainer);


  if (fromNumOrDenomOrDink == true) {
    if(CheckIfNovel(solContainer, knownSolPool))
      knownSolPool.push_back(solContainer);
  }

  return (solContainer);
}

bool CheckIfNovel(optDiverseSolInfo solContainer, list<optDiverseSolInfo> &knownSolPool) {

  //This function verifies that an optimal solution is non-redundant with respect to the contents of knownSolPool prior to saving it off

  bool novel = true;
  bool match;

  list<optDiverseSolInfo>::iterator itPool;

  if (knownSolPool.empty() != true) {
    for (itPool = knownSolPool.begin(); itPool != knownSolPool.end(); ++itPool) {
      match = true;
      for (int h = 0; h < solContainer.numCols - solContainer.nonDivVarCnt; h++) {
        if (solContainer.optSol[h] != (*itPool).optSol[h]) {
          match = false;
          break;
        }
      }
      if (match == true) {
        novel = false;
        break;
      }
    }
  }

  return(novel);
}

void CutOffLastSol(CPXENVptr env, CPXLPptr BIP, int nonDivVarCnt, vector<optDiverseSolInfo> diverseSolVec) {
  //This function removes the previous solution from further consideration by cutting it off from the feasible region

  int status;
  double eps = diverseSolVec[0].eps;

  int ccnt = 0;
  int rcnt = 1;

  //This is because we don't want the last variable q (for "quality") to be involved in the cutting off; only structural, binary variable part of solution should be "cut off"
  int nzcnt = (CPXgetnumcols(env,BIP) - nonDivVarCnt);

  char sense[1];//Creates new character array
  sense[0] = 'G';

  int rmatbeg[1];
  rmatbeg[0] = 0;

  double rhs[1];
  rhs[0] = 1;

  int* rmatind = new int[nzcnt];
  double* rmatval = new double[nzcnt];

  for (int h = 0; h < nzcnt; h++) {
    rmatind[h] = h;
    if (diverseSolVec[diverseSolVec.size() - 1].optSol[h] < eps)
      rmatval[h] = 1;
    else {
      rmatval[h] = -1;
      rhs[0]--;
    }
  }

  //Add row to cut off the previous solution
  status = CPXaddrows(env, BIP, ccnt, rcnt, nzcnt, rhs, sense, rmatbeg, rmatind, rmatval, NULL, NULL);

  DeleteAndNullifyTypeTwo(rmatind);
  DeleteAndNullifyTypeTwo(rmatval);
}

CPXLPptr UpdateDinkObjective(CPXENVptr env, CPXLPptr BIP, int dinkObjCnt, int nonDivVarCnt, int* dinkObjIndices, double* dinkObjValues, double a, double b, double c, double lambda, double* origObj, double* centroid, int origObjSen, vector<optDiverseSolInfo> diverseSolVec) {

  //This function implements the objective in Step 5 of Algorithm 1 in paper "Finding Diverse Optima and Near-Optima to Binary Integer Programs"
  //It changes the objective to [(b/a)*quality + (c/a)*objloss] - \lambda*div

  int status = 0;

  vector<optDiverseSolInfo>::iterator vecIt;

  for (int h = 0; h < dinkObjCnt - nonDivVarCnt; h++) {
    dinkObjIndices[h] = h;

    dinkObjValues[h] = -1*lambda*(1 - 2*centroid[h]);

    if (origObjSen == CPX_MIN) //Complementary from earlier DHQS code, because the present code is MINIMIZING the ratio
      dinkObjValues[h] += -1*(-1*(c/a)*origObj[h]);
    else
      dinkObjValues[h] += (-1*(c/a)*origObj[h]);
  }

  //For last variable(s) representing quality
  for (int h = (dinkObjCnt - nonDivVarCnt); h < dinkObjCnt; h++) {
    dinkObjIndices[h] = h;
    dinkObjValues[h] = b/a;
  }

  //Finally, update objective function
  status = CPXchgobj(env, BIP, dinkObjCnt, dinkObjIndices, dinkObjValues);

  return BIP;
}

void ComputeCentroid(vector<optDiverseSolInfo> diverseSolVec, double* centroid) {

  vector<optDiverseSolInfo>::iterator itDSV;

  for (int h = 0; h < diverseSolVec.front().numCols; h++) {
    centroid[h] = 0;
    for (itDSV = diverseSolVec.begin(); itDSV != diverseSolVec.end(); ++itDSV)
      centroid[h] += (*itDSV).optSol[h];
    centroid[h] = (centroid[h] / ((double) diverseSolVec.size()));
  }
}

void OutputErrorMessage(ostream& solutionsOut, int code, double timeLimit, const char* subprob_name, int Kappa, vector<optDiverseSolInfo> diverseSolVec) {

  //This function does error-handling

  if (code == 0) {
    cout << endl << "****************************************************************";
    cout << endl << "Optimization could not identify an optimal solution to subproblem " << subprob_name << " within the allotted time limit of " << timeLimit << " seconds." << endl;
    cout << "****************************************************************" << endl;
    solutionsOut << endl << "****************************************************************";
    solutionsOut << endl << "Optimization could not identify an optimal solution to subproblem " << subprob_name << " within the allotted time limit of " << timeLimit << " seconds." << endl;
  }
  else if (code == 1) {
    cout << endl << "****************************************************************";
    cout << endl << "There are less than " << Kappa << " feasible solutions in the feasible region." << endl;
    cout << "The algorithm has identified all " << diverseSolVec.size() << " feasible solutions." << endl;
    cout << "****************************************************************" << endl;
    solutionsOut << endl << "****************************************************************";
    solutionsOut << endl << "There are less than " << Kappa << " feasible solutions in the feasible region." << endl;
    solutionsOut << "The algorithm has identified all " << diverseSolVec.size() << " feasible solutions." << endl;
  }
}

void OutputToFile(ostream& solutionsOut, char* TI_name, int numCols, int nonDivVarCnt, int Kappa, double a, double b, double c, int origObjSen, double origOptObjVal, double* origObj, double* centroid, double overallStart, vector<optDiverseSolInfo> diverseSolVec) {

  cout << "numCols is: " << numCols << endl;
  cout << "nonDivVarCnt is: " << nonDivVarCnt << endl;

  //This function handles the final output to file

  double ComputeDinkObjLoss(int, double, double*, optDiverseSolInfo);

  clock_t overallFinish = clock();      //Stop recording time
  double runTimeOverall = (double)(overallFinish - overallStart)/CLOCKS_PER_SEC;

  //Write out solutions in diverseSolVec to a file
  vector<optDiverseSolInfo>::iterator vecIt;
  vector<optDiverseSolInfo>::iterator vecIt2;

  time_t now = time(0);
  tm* localtm = localtime(&now);
  solutionsOut << "Local date and time is: " << asctime(localtm) << endl;
  solutionsOut << "Finding " << Kappa << " diverse and high-quality solutions to " <<  TI_name << endl;
  if (origObjSen == CPX_MIN)
    solutionsOut << "Original objective function direction is MINIMIZATION" << endl;
  else
    solutionsOut << "Original objective function direction is MAXIMIZATION" << endl;
  solutionsOut << "Diversity metric is to maximize distance from centroid" << endl;
  solutionsOut << "a is: " << a << ", b is: " << b << ", c is: " << c << endl;
  solutionsOut << "Overall run time (seconds) was: " << runTimeOverall << endl << endl;

  double DWDiversity = 0;
  double lossInQualityofSolution;
  solutionsOut << "Iterations\tOptObjVal\tGapOffOptimal\tDiversityMeasure\tNumCols\tCumulDWDivMetric\tSolution\t\t";
  solutionsOut << "Problem:\t" << TI_name << "\t\tObj Dir:\t" << origObjSen << "\t\tOverall Runtime (s):\t" << runTimeOverall << "\t\tSolutions Found\t" << diverseSolVec.size() << endl;
  int vecItem = 1;
  for (vecIt = diverseSolVec.begin(); vecIt < diverseSolVec.end(); ++vecIt) {
//if (origObjSen == CPX_MAX)
      lossInQualityofSolution = ComputeDinkObjLoss(origObjSen, origOptObjVal, origObj, (*vecIt));
    if (vecIt == diverseSolVec.begin())
      solutionsOut << "N/A\t" << origOptObjVal << "\t";
    else
      if (origObjSen == CPX_MAX)
        solutionsOut << (*vecIt).loop << "\t" << (origOptObjVal - lossInQualityofSolution + (*vecIt).eps) << "\t"; //Quick way to obtain c^Tx for the current vecIt member of diverseSolVec
      else if (origObjSen == CPX_MIN)
        solutionsOut << (*vecIt).loop << "\t" << (origOptObjVal + lossInQualityofSolution - (*vecIt).eps) << "\t"; //Quick way to obtain c^Tx for the current vecIt member of diverseSolVec
    //Now compute relative diversity to previous members in diverseSolVec
    double curDiversity = 0;

    if (centroid != NULL) {
      for (vecIt2 = diverseSolVec.begin(); vecIt2 < vecIt; ++vecIt2) {
        for (int h = 0; h < numCols; h++) { //New code for DHQSDiv, to accommodate extra "q" variable
          curDiversity += centroid[h] + (1 - (2*centroid[h])) * (*vecIt).optSol[h];

          //Also compute DW Diversity metric
          if (fabs(((*vecIt).optSol[h]) - ((*vecIt2).optSol[h])) > (*vecIt).eps)
            DWDiversity++;
        }
      }
    }
    else {
      curDiversity = 0;
      DWDiversity = 0;
    }

    if (vecIt == diverseSolVec.begin())
      solutionsOut << "N/A" << "\t" << "N/A" << "\t" << numCols << "\t" << "N/A" << "\t";
    else
      solutionsOut << fabs((lossInQualityofSolution*(origObjSen)) / (fabs(origOptObjVal) + (*vecIt).eps)) << "\t" << curDiversity << "\t" << numCols << "\t" << (double) (2*DWDiversity) / (vecItem*(vecItem-1)*(numCols)) << "\t"; //Now outputting current DWDiversity metric; first metric is the optimality gap

    for (int h = 0; h < (numCols + nonDivVarCnt); h++) {
      if ((vecIt == diverseSolVec.begin()) && (h >= numCols))
        solutionsOut << "N/A\t";
      else
        solutionsOut << (*vecIt).optSol[h] << "\t";
    }
    solutionsOut << endl;
    vecItem++;
  }

  DWDiversity = (2*DWDiversity) / (diverseSolVec.size()*(diverseSolVec.size()-1)*(numCols));
  solutionsOut << endl << "Final DW diversity metric: " << DWDiversity;
  solutionsOut << endl << "**************************" << endl;
}

void OutputForPython(ostream& pyOut, char* TI_name, int numAgents, int numJobs, int numCols, int nonDivVarCnt, int Kappa, double a, double b, double c, int origObjSen, double origOptObjVal, double* origObj, double* aRow, double* cObj, double* centroid, double overallStart, vector<optDiverseSolInfo> diverseSolVec) {

  //This function handles the final output to python for Thierry's script

  double ComputeDinkObjLoss(int, double, double*, optDiverseSolInfo);
  vector<optDiverseSolInfo> ComputeFinalObjFunc(int, double*, vector<optDiverseSolInfo>);
  vector<optDiverseSolInfo> ComputeMaxCardDistances(int, int, double*, vector<optDiverseSolInfo>);
  vector<optDiverseSolInfo> ComputeSmoothViolations(int, int, double*, vector<optDiverseSolInfo>);
  vector<optDiverseSolInfo> ComputeDiversity(int, vector<optDiverseSolInfo>);

  clock_t overallFinish = clock();      //Stop recording time
  double runTimeOverall = (double)(overallFinish - overallStart)/CLOCKS_PER_SEC;

  time_t now = time(0);
  tm* localtm = localtime(&now);
  pyOut << "Local date and time is: " << asctime(localtm) << endl;
  pyOut << "Finding " << Kappa << " diverse and high-quality solutions to " <<  TI_name << endl;
  if (origObjSen == CPX_MIN)
    pyOut << "Original objective function direction is MINIMIZATION" << endl;
  else
    pyOut << "Original objective function direction is MAXIMIZATION" << endl;
  pyOut << "Diversity metric is to maximize distance from centroid" << endl;
  pyOut << "a is: " << a << ", b is: " << b << ", c is: " << c << endl;
  pyOut << "Overall run time (seconds) was: " << runTimeOverall << endl << endl;
  #if OBJCUT
    pyOut << "All solutions constrained to be within: " << OBJCUTVAL << "% of original optimal objective function value" << endl;
  #endif

  //Call 5 functions to compute the various metrics, for each solution, that are stored in the "quality" array
  //1) Compute original objective, based on optSol values;
  //2) Compute, over all agent pairs, the maximum cardinality distance;
  //3) Compute, over all agent pairs, the maximum WEIGHTED cardinality distance (can be done with (2) above);
  //4) Compute, over all adjacent variables, the smooth violations with respect to Theta = 5
  //5) Compute, over all adjacent variables, the smooth violations with respect to Theta = 15
  diverseSolVec = ComputeFinalObjFunc(numCols, origObj, diverseSolVec);
  diverseSolVec = ComputeMaxCardDistances(numAgents, numJobs, aRow, diverseSolVec);
  diverseSolVec = ComputeSmoothViolations(numAgents, numJobs, cObj, diverseSolVec);
  diverseSolVec = ComputeDiversity(numCols, diverseSolVec);

  vector<optDiverseSolInfo>::iterator vecIt;
  int counter;
  
  pyOut << "o = [";
  counter = 0;
  for (vecIt = diverseSolVec.begin(); vecIt < diverseSolVec.end(); ++vecIt) {
    if (counter < (diverseSolVec.size() - 1))
      pyOut << (*vecIt).optObjVal << ",";
    else
      pyOut << (*vecIt).optObjVal;
    counter++;
  }
  pyOut << "]";

  pyOut << endl << "mc = [";
  counter = 0;
  for (vecIt = diverseSolVec.begin(); vecIt < diverseSolVec.end(); ++vecIt) {
    if (counter < (diverseSolVec.size() - 1))
      pyOut << (*vecIt).maxCard << ",";
    else
      pyOut << (*vecIt).maxCard;
    counter++;
  }
  pyOut << "]";

  pyOut << endl << "mr = [";
  counter = 0;
  for (vecIt = diverseSolVec.begin(); vecIt < diverseSolVec.end(); ++vecIt) {
    if (counter < (diverseSolVec.size() - 1))
      pyOut << (*vecIt).maxResCard << ",";
    else
      pyOut << (*vecIt).maxResCard;
    counter++;
  }
  pyOut << "]";

  pyOut << endl << "s_15 = [";
  counter = 0;
  for (vecIt = diverseSolVec.begin(); vecIt < diverseSolVec.end(); ++vecIt) {
    if (counter < (diverseSolVec.size() - 1))
      pyOut << (*vecIt).largeSmoothVioCnt << ",";
    else
      pyOut << (*vecIt).largeSmoothVioCnt;
    counter++;
  }
  pyOut << "]";

  pyOut << endl << "s_5 = [";
  counter = 0;
  for (vecIt = diverseSolVec.begin(); vecIt < diverseSolVec.end(); ++vecIt) {
    if (counter < (diverseSolVec.size() - 1))
      pyOut << (*vecIt).smallSmoothVioCnt << ",";
    else
      pyOut << (*vecIt).smallSmoothVioCnt;
    counter++;
  }
  pyOut << "]";

  pyOut << endl << "div = [";
  counter = 0;
  for (vecIt = diverseSolVec.begin(); vecIt < diverseSolVec.end(); ++vecIt) {
    if (counter < (diverseSolVec.size() - 1))
      pyOut << (*vecIt).rollingDiv << ",";
    else
      pyOut << (*vecIt).rollingDiv;
    counter++;
  }
  pyOut << "]";

}

vector<optDiverseSolInfo> ComputeFinalObjFunc(int numBinStructVar, double* origObj, vector<optDiverseSolInfo> diverseSolVec) {

  vector<optDiverseSolInfo>::iterator itDSV;

  for (itDSV = diverseSolVec.begin(); itDSV != diverseSolVec.end(); ++itDSV) {
    double optObjVal = 0;
    for (int h = 0; h < numBinStructVar; h++)
      optObjVal += (*itDSV).optSol[h]*origObj[h];
    (*itDSV).optObjVal = optObjVal;
  }

  return diverseSolVec;
}

vector<optDiverseSolInfo> ComputeMaxCardDistances(int numAgents, int numJobs, double* aRow, vector<optDiverseSolInfo> diverseSolVec) {

  vector<optDiverseSolInfo>::iterator itDSV;

  for (itDSV = diverseSolVec.begin(); itDSV != diverseSolVec.end(); ++itDSV) {
    (*itDSV).card = new double[numAgents];
    (*itDSV).resCard = new double[numAgents];
  }

  //Compute card, and resCard, for each agent of each solution in diverseSolVec
  for (itDSV = diverseSolVec.begin(); itDSV != diverseSolVec.end(); ++itDSV) {
    for (int i = 0; i < numAgents; i++) {
      (*itDSV).card[i] = 0;
      (*itDSV).resCard[i] = 0;
      for (int j = 0; j < numJobs; j++) {
        (*itDSV).card[i] += (*itDSV).optSol[(i*numJobs) + j];
        (*itDSV).resCard[i] += aRow[(i*numJobs) + j]*((*itDSV).optSol[(i*numJobs) + j]);
      }
    }
  }

  //Now, iterate over all pairs of agents, and compute maxCard and maxResCard by comparing
  for (itDSV = diverseSolVec.begin(); itDSV != diverseSolVec.end(); ++itDSV) {
    (*itDSV).maxCard = 0;
    (*itDSV).maxResCard = 0;
    for (int i = 0; i < (numAgents - 1); i++) {
      for (int k = i + 1; k < numAgents; k++) {
        if ((*itDSV).maxCard < fabs((*itDSV).card[i] - (*itDSV).card[k]))
          (*itDSV).maxCard = fabs((*itDSV).card[i] - (*itDSV).card[k]);
        if ((*itDSV).maxResCard < fabs((*itDSV).resCard[i] - (*itDSV).resCard[k]))
          (*itDSV).maxResCard = fabs((*itDSV).resCard[i] - (*itDSV).resCard[k]);
      }
    }
  }

  //Delete dynamic memory
  for (itDSV = diverseSolVec.begin(); itDSV != diverseSolVec.end(); ++itDSV) {
    DeleteAndNullifyTypeTwo((*itDSV).card);
    DeleteAndNullifyTypeTwo((*itDSV).resCard);
  }

  return diverseSolVec;
}

vector<optDiverseSolInfo> ComputeSmoothViolations (int numAgents, int numJobs, double* cObj, vector<optDiverseSolInfo> diverseSolVec) {

  vector<optDiverseSolInfo>::iterator itDSV;

  for (itDSV = diverseSolVec.begin(); itDSV != diverseSolVec.end(); ++itDSV)
    (*itDSV).cost = new double[numJobs];

  //Compute cost for each job of each solution in diverseSolVec
  for (itDSV = diverseSolVec.begin(); itDSV != diverseSolVec.end(); ++itDSV) {
    (*itDSV).smallSmoothVioCnt = 0;
    (*itDSV).largeSmoothVioCnt = 0;
    for (int j = 0; j < numJobs; j++) {
      (*itDSV).cost[j] = 0;
      for (int i = 0; i < numAgents; i++)
        (*itDSV).cost[j] += cObj[(i*numJobs) + j]*((*itDSV).optSol[(i*numJobs) + j]);
      if (j > 0) {
        if (fabs((*itDSV).cost[j] - (*itDSV).cost[j-1]) > SMALLSMOOTHVIO)
          (*itDSV).smallSmoothVioCnt++;
        if (fabs((*itDSV).cost[j] - (*itDSV).cost[j-1]) > LARGESMOOTHVIO)
          (*itDSV).largeSmoothVioCnt++;
      }
    }
  }

  //Delete dynamic memory
  for (itDSV = diverseSolVec.begin(); itDSV != diverseSolVec.end(); ++itDSV)
    DeleteAndNullifyTypeTwo((*itDSV).cost);

  return diverseSolVec;
}

vector<optDiverseSolInfo> ComputeDiversity(int numCols, vector<optDiverseSolInfo> diverseSolVec) {

  vector<optDiverseSolInfo>::iterator vecIt;
  vector<optDiverseSolInfo>::iterator vecIt2;

  double* tempCentroid = new double[numCols];

  //Start at beginning of vector
  vecIt = diverseSolVec.begin();

  //Set initial distance from centroid to zero
  (*vecIt).rollingDiv = 0;
  //Step forward one element from the first
  std::advance(vecIt, 1);
  double elementCounter = 1.0;

  //Now loop through, and compute centroid
  for (; vecIt < diverseSolVec.end(); ++vecIt) {
    for (int h = 0; h < numCols; h++) {
      tempCentroid[h] = 0;
      for (vecIt2 = diverseSolVec.begin(); vecIt2 < vecIt; ++vecIt2)
        tempCentroid[h] += (*vecIt2).optSol[h];
      tempCentroid[h] = (tempCentroid[h] / elementCounter);
    }
    //Now compute the distance from (*vecIt).optSol to the tempCentroid
    (*vecIt).rollingDiv = 0;
    for (int h = 0; h < numCols; h++)
      (*vecIt).rollingDiv += tempCentroid[h] + (1 - (2*tempCentroid[h])) * (*vecIt).optSol[h];
    elementCounter = elementCounter + 1.0;
  }

  //Delete and nullify dynamic memory
  DeleteAndNullifyTypeTwo(tempCentroid);

  return diverseSolVec;
}
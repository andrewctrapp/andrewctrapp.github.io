// T.Petit 2016
package constraints;

public interface DistanceI {
	public int cost(int x, int y);
	public String getName();
}

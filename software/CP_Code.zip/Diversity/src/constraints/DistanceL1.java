// T.Petit 2016
package constraints;

// L1 norm distance

public class DistanceL1 implements DistanceI {

	@Override
	public int cost(int x, int y) {
		return Math.abs(x-y); 
	}

	@Override
	public String getName() {
		return "L1 Manhattan"; 
	}

}

// T.Petit 2016
package constraints;

// Propagators factory

import org.chocosolver.solver.constraints.Constraint;
import org.chocosolver.solver.constraints.extension.Tuples;
import org.chocosolver.solver.variables.IntVar;

import constraints.propagators.PropDivXYZbis;
import constraints.propagators.PropDiverseSum;
import constraints.propagators.PropForbidTuples;
import constraints.propagators.PropObjLoss;

public class PropConstraintFactory {

	public static Constraint Diversity(IntVar[] vars, IntVar diver, int[][] sols, int initDiverLB, DistanceI dist) {
		return new Constraint("Diversity_"+dist.getName(), new PropDiverseSum(vars, diver, sols, initDiverLB, dist));
	}
	public static Constraint Forbid(IntVar[] vars, Tuples t) {
		return new Constraint("Forbid", new PropForbidTuples(vars, t));
	}
	public static Constraint new_eucl_div(IntVar DIVIDEND, IntVar DIVISOR, IntVar RESULT) {
        return new Constraint("DivisionEucl", new PropDivXYZbis(DIVIDEND, DIVISOR, RESULT));
    }
	public static Constraint ObjLossCt(IntVar obj, IntVar objLoss, int bestObj) {
		return new Constraint("ObjLossCt", new PropObjLoss(obj, objLoss, bestObj)); 
	}
	
	
}

// T.Petit 2014
package constraints.propagators;

import org.chocosolver.solver.ICause;
import org.chocosolver.solver.constraints.Propagator;
import org.chocosolver.solver.exception.ContradictionException;
import org.chocosolver.solver.variables.IntVar;
import org.chocosolver.util.ESat;
import org.chocosolver.util.tools.ArrayUtils;

import constraints.DistanceI;

// Diversity constraint based on equality

public class PropDiverseSum extends Propagator<IntVar>{
	private static final long serialVersionUID = 1L;
	protected IntVar[]   vars;      // diversity variables
	protected int        n;         // vars.length
	protected int[][]    solsByVar; // previous assignments (indexes correspond to vars)
	protected IntVar     obj;       // distance variable
	protected int        lb;        // previous diversity score
	protected DistanceI  dist;      // distance measure
	ICause aCause;

	public PropDiverseSum(IntVar[] vars, IntVar obj, int[][] sols, int lb, DistanceI dist) {
		super(ArrayUtils.append(vars, new IntVar[]{obj}));
		this.vars = vars;
		this.n = vars.length;
		this.obj = obj;
		this.lb = lb;	
		this.dist = dist; 
		this.solsByVar = new int[n][sols.length];
		for(int i=0; i<n; i++) {
			for(int j=0; j<sols.length; j++) {
				solsByVar[i][j] = sols[j][i]; 
			}
		}
	}
	
	@Override
	public void propagate(int evtmask) throws ContradictionException {
		filter();
	}

	protected int minMax(boolean mini) {
		int minVal = Integer.MAX_VALUE;
		int maxVal = Integer.MIN_VALUE;
		for(int i=0; i<n; i++) {
			minVal = Math.min(minVal,vars[i].getLB());
			maxVal = Math.max(maxVal,vars[i].getUB());
		}
		if(mini){
			return minVal;
		}
		return maxVal;
	}
	
	public void filter() throws ContradictionException { 
		int minVal = minMax(true);
		int maxVal = minMax(false);
		int m = maxVal-minVal+1; 
		int[][] sumDistValue = new int[n][m];
		int[] minSumDist = new int[n];
		int[] maxSumDist = new int[n];
		for(int i=0; i<n; i++) {  // distances are positive or null 
			minSumDist[i] = 0;  
			maxSumDist[i] = 0;  
		}
		int minSum = 0;
		int maxSum = 0;
		for(int i=0; i<n; i++) {
			int pos = 0;
			for(int j=minVal; j<=maxVal; j++) {
				if(vars[i].contains(j)) {
					for(int k=0; k<solsByVar[i].length; k++) {
						sumDistValue[i][pos] += dist.cost(j, solsByVar[i][k]); 
					}
					maxSumDist[i] = Math.max(maxSumDist[i], sumDistValue[i][pos]);
					minSumDist[i] = Math.min(minSumDist[i], sumDistValue[i][pos]);
				} // else sumDistValue[i][pos]==0
				pos++; // in any case
			}
			maxSum += maxSumDist[i]; 
			minSum += minSumDist[i];
		}
		minSum += lb; // cumulates with previous solutions 
		maxSum += lb; // cumulates with previous solutions (this is lb: not an error)
		obj.updateUpperBound(maxSum, aCause);  // required to prove optimality correctly
		obj.updateLowerBound(minSum, aCause);
		for(int i=0; i<n; i++) {
			int pos = 0;
			for(int j=minVal; j<=maxVal; j++) {
				if(vars[i].contains(j)) {
					if(maxSum-maxSumDist[i]+sumDistValue[i][pos]<obj.getLB() || minSum-minSumDist[i]+sumDistValue[i][pos]>obj.getUB()) {
						vars[i].removeValue(j, aCause);
					}
				}
				pos++;
			}
		}
	}
	
	@Override
	public ESat isEntailed() {
		return null;
	}
}

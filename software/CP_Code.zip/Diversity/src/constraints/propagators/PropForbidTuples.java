// T.Petit 2014
package constraints.propagators;

import org.chocosolver.solver.ICause;
import org.chocosolver.solver.constraints.Propagator;
import org.chocosolver.solver.constraints.extension.Tuples;
import org.chocosolver.solver.exception.ContradictionException;
import org.chocosolver.solver.variables.IntVar;
import org.chocosolver.util.ESat;

// Scaling checker for forbidden tuples 

public class PropForbidTuples extends Propagator<IntVar> {
	private static final long serialVersionUID = 1L;
	protected IntVar[] diversityVars;
	int[][] tuples;
	int n; 
	int size; 
	ICause aCause; 
	
	public PropForbidTuples(IntVar[]diversityVars, Tuples t) {
		super(diversityVars); 
		this.diversityVars = diversityVars;
		this.n = diversityVars.length;
		this.size = t.nbTuples();
		this.tuples = new int[size][n];
		for(int i=0; i<size; i++) {
			tuples[i] = t.get(i);
		}
	}
	
	@Override
	public void propagate(int evtmask) throws ContradictionException {
		if(tuples.length==0) {
			return; 
		}
		for(int i=0; i<size; i++) {
			boolean fail = true; 
			for(int j=0; j<n; j++) {
				if(!diversityVars[j].isInstantiated()) {
					return;
				} else {
					if(diversityVars[j].getValue()!=tuples[i][j]) {
						fail = false;
						j = n;
					}
				}
			}
			if(fail) {
				diversityVars[0].updateUpperBound((diversityVars[0].getLB()-1), aCause); 
			}
		}
	}
	@Override
	public ESat isEntailed() {
		if(tuples.length==0) {
			return null; 
		}
		for(int i=0; i<size; i++) {
			boolean fail = true; 
			for(int j=0; j<n; j++) {
				if(!diversityVars[j].isInstantiated()) {
					return ESat.UNDEFINED;
				} else {
					if(diversityVars[j].getValue()!=tuples[i][j]) {
						fail = false;
					}
				}
			}
			if(fail) {
				return ESat.FALSE; 
			}
		}
		return ESat.TRUE;
	}
}

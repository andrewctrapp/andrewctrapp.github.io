// T.Petit 2014
package constraints.propagators;

import org.chocosolver.solver.ICause;
import org.chocosolver.solver.constraints.Propagator;
import org.chocosolver.solver.constraints.PropagatorPriority;
import org.chocosolver.solver.exception.ContradictionException;
import org.chocosolver.solver.variables.IntVar;
import org.chocosolver.solver.variables.events.IntEventType;
import org.chocosolver.util.ESat;

// This propagator is useful to avoid an extra variable using a distance constraint
// objLoss == 0 if obj<=bestObj, objLoss == (obj-bestObj) otherwise

public class PropObjLoss extends Propagator<IntVar>{
	private static final long serialVersionUID = 1L;
	protected IntVar obj;
	protected IntVar objLoss;
	protected int bestObj;
	ICause aCause;

	public PropObjLoss(IntVar obj, IntVar objLoss, int bestObj) {
		super(new IntVar[]{obj,objLoss},PropagatorPriority.LINEAR, false);
		this.obj = obj;
		this.objLoss = objLoss;
		this.bestObj = bestObj;
	}
	@Override
	public int getPropagationConditions(int vIdx) {
		return IntEventType.BOUND.getMask() + IntEventType.INSTANTIATE.getMask();
	}
	@Override
	public void propagate(int evtmask) throws ContradictionException {
		filter(); 
	}
	@Override
	public ESat isEntailed() {
		return null;
	}
	// Filtering procedure
	public void filter() throws ContradictionException {
		int lbObj = obj.getLB();     
		int ubObj = obj.getUB();
		objLoss.updateLowerBound(Math.max(0, lbObj-bestObj), aCause);
		objLoss.updateUpperBound(Math.max(0, ubObj-bestObj), aCause);
		obj.updateLowerBound(objLoss.getLB()+bestObj, aCause);
		obj.updateUpperBound(objLoss.getUB()+bestObj, aCause);
	}
}

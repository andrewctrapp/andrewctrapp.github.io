// T.Petit 2016
package constraints;

// Hamming distance

public class DistanceHam implements DistanceI {

	@Override
	public int cost(int x, int y) {
		return Math.min(Math.abs(x-y),1);
	}
	
	@Override
	public String getName() {
		return "Hamming";
	}

}

// T.Petit 2016
package constraints;

// Factory for quality notions added to a problem

import java.util.ArrayList;

import org.chocosolver.solver.Solver;
import org.chocosolver.solver.constraints.Constraint;
import org.chocosolver.solver.constraints.IntConstraintFactory;
import org.chocosolver.solver.constraints.LogicalConstraintFactory;
import org.chocosolver.solver.variables.BoolVar;
import org.chocosolver.solver.variables.IntVar;
import org.chocosolver.solver.variables.VariableFactory;
import org.chocosolver.util.tools.ArrayUtils;

public class QualityNotionFactory {
	
	public final static String MAXDISTANCE="MaxDistance";
	public final static String MAXCONSDISTANCE = "MaxConsDistance";
	public static final String SMOOTH = "Smooth"; 
	public static final String AMONG = "Among";
	public static final String MAXDISTANCE_AND_SMOOTH = "MaxDistanceAndSmooth";
	
	// Maximum distance constraint decomposition
	// qobj is the maximum distance between any two variables
	
	public static ArrayList<Object> maxDistance(IntVar[] vars) {
		int n = vars.length;
		Solver solver = vars[0].getSolver();
		int minv = vars[0].getLB();
		int maxv = vars[0].getUB();
		for(int i=1; i<n; i++) {
			minv = Math.min(minv, vars[i].getLB());
			maxv = Math.max(maxv, vars[i].getUB());
		}
		IntVar qobj = VariableFactory.bounded("qualityObj", 0, maxv-minv, solver); 
		IntVar[][] loc = new IntVar[n-1][];
		Constraint [][] tmp = new Constraint[n-1][];
		for(int i=0;i<n-1;i++) {
			tmp[i] = new Constraint[n-i-1];
			loc[i] = VariableFactory.boundedArray("loc:"+i, n-i+1, qobj.getLB(), qobj.getUB(), solver);
			for(int j=i+1;j<n;j++) {
				tmp[i][j-i-1] = IntConstraintFactory.distance(vars[i], vars[j], "=", loc[i][j-i-1]);
			}
		}
		IntVar[] alloc = ArrayUtils.flatten(loc); 
		Constraint[] res = ArrayUtils.flatten(tmp);
		Constraint ctobj = IntConstraintFactory.maximum(qobj, alloc);
		res = ArrayUtils.append(res,new Constraint[]{ctobj});
		ArrayList<Object> l = new ArrayList<Object>();
		l.add(qobj);  // quality obj variable
		l.add(res);   // constraints
		l.add(alloc); // aaditional integer variables
		return l;
	}

	public static int maxDistanceCHK(int[] tuple) {
		Solver s = new Solver();
		IntVar[] vars = new IntVar[tuple.length];
		for(int i=0; i<vars.length; i++) {
			vars[i] = VariableFactory.fixed(tuple[i], s);
		}
		ArrayList<Object> l = maxDistance(vars); 
		IntVar qobj = (IntVar)l.get(0);
		s.post((Constraint[])l.get(1));
		s.findSolution();
		if(s.getMeasures().getSolutionCount()>0) {
			return qobj.getValue();
		} else {
			return -1; 
		}
	}
	
	public static ArrayList<Object> maxDistanceDouble(IntVar[] var1, IntVar[] var2) {
		ArrayList<Object> l1 = maxDistance(var1);
		ArrayList<Object> l2 = maxDistance(var2);
		IntVar newobj = VariableFactory.bounded("cumulQualityObj", 0, ((IntVar)l1.get(0)).getUB()+((IntVar)l2.get(0)).getUB(), ((IntVar)l1.get(0)).getSolver());  
		IntVar[] newalloc = ArrayUtils.append((IntVar[])l1.get(2),(IntVar[])l2.get(2));
		Constraint ctobj = IntConstraintFactory.sum(new IntVar[]{((IntVar)l1.get(0)),((IntVar)l2.get(0))}, newobj);
		Constraint[] newres = ArrayUtils.append((Constraint[])l1.get(1),(Constraint[])l2.get(1), new Constraint[]{ctobj});
		ArrayList<Object> l = new ArrayList<Object>();
		l.add(newobj);  // quality obj variable
		l.add(newres);   // constraints
		l.add(newalloc); // aaditional integer variables
		return l;
	}
	
	// Maximum distance constraint on consecutive variables decomposition
	// qobj is the maximum distance between any two consecutive variables

	public static ArrayList<Object> maxConsDistance(IntVar[] vars) {
		int n = vars.length;
		Solver solver = vars[0].getSolver();		
		int minvi = vars[0].getLB();
		int maxvi = vars[0].getUB();
		int maxdist = 0; 
		for(int i=1; i<n; i++) {
			maxdist = Math.max(Math.max(Math.abs(minvi-vars[i].getUB()), Math.abs(maxvi-vars[i].getLB())),maxdist);
			minvi = vars[i].getLB();
			maxvi = vars[i].getUB();
		}
		IntVar qobj = VariableFactory.bounded("qualityObj", 0, maxdist, solver); 
		IntVar[] distances = VariableFactory.boundedArray("distances", n-1, 0, maxdist, solver);
		Constraint[] ct_distances = new Constraint[n-1]; 
		for(int i=0; i<n-1; i++){
			ct_distances[i] = IntConstraintFactory.distance(vars[i], vars[i+1], "=", distances[i]);
		}
		Constraint ct_qobj = IntConstraintFactory.maximum(qobj, distances);
		Constraint[] res = ArrayUtils.append(ct_distances, new Constraint[]{ct_qobj});
		ArrayList<Object> l = new ArrayList<Object>();
		l.add(qobj);  // quality obj variable
		l.add(res);   // constraints
		l.add(distances); // aaditional integer variables
		return l;
	}

	public static int maxConsDistanceCHK(int[] tuple) {
		Solver s = new Solver();
		IntVar[] vars = new IntVar[tuple.length];
		for(int i=0; i<vars.length; i++) {
			vars[i] = VariableFactory.fixed(tuple[i], s);
		}
		ArrayList<Object> l = maxConsDistance(vars); 
		IntVar qobj = (IntVar)l.get(0);
		s.post((Constraint[])l.get(1));
		s.findSolution();
		if(s.getMeasures().getSolutionCount()>0) {
			return qobj.getValue();
		} else {
			return -1; 
		}
	}
	
	// Smooth

	public static ArrayList<Object> smooth(IntVar[] vars, int s) {
		int n = vars.length;
		Solver solver = vars[0].getSolver();		
		int minvi = vars[0].getLB();
		int maxvi = vars[0].getUB();
		int maxdist = 0; 
		for(int i=1; i<n; i++) {
			maxdist = Math.max(Math.max(Math.abs(minvi-vars[i].getUB()), Math.abs(maxvi-vars[i].getLB())),maxdist);
			minvi = vars[i].getLB();
			maxvi = vars[i].getUB();
		}
		IntVar[] distances = VariableFactory.boundedArray("distances", n-1, 0, maxdist, solver);
		BoolVar[] reify = VariableFactory.boolArray("distances", n-1, solver);
		Constraint[] ct_distances = new Constraint[n-1]; 
		for(int i=0; i<n-1; i++){
			ct_distances[i] = IntConstraintFactory.distance(vars[i], vars[i+1], "=", distances[i]);
		}
		Constraint[] ct_reify = new Constraint[n-1];
		for(int i=0; i<n-1; i++){
			ct_reify[i] = LogicalConstraintFactory.reification_reifiable(reify[i], IntConstraintFactory.arithm(distances[i],">",s));
		}
		IntVar qobj = VariableFactory.bounded("qobj", 0, n-1, solver);
		Constraint ct_qobj = IntConstraintFactory.sum(reify, qobj);
		Constraint[] res = ArrayUtils.append(ct_distances, ct_reify, new Constraint[]{ct_qobj});
		ArrayList<Object> l = new ArrayList<Object>();
		l.add(qobj);      // quality obj variable
		l.add(res);       // constraints
		l.add(distances); // aaditional integer variables
		l.add(reify);     // additional binary variables
		return l;
	}
	
	public static ArrayList<Object> smoothDouble(IntVar[] vars, int s1, int s2) { // doit on ajouter des poids ? 
		ArrayList<Object> l1 = smooth(vars,s1);
		ArrayList<Object> l2 = smooth(vars,s2);
		IntVar newobj = VariableFactory.bounded("cumulQualityObjSmooth", 0, ((IntVar)l1.get(0)).getUB()+((IntVar)l2.get(0)).getUB(), ((IntVar)l1.get(0)).getSolver());  
		IntVar[] newalloc = ArrayUtils.append((IntVar[])l1.get(2),(IntVar[])l2.get(2));
		BoolVar[] newbinalloc = ArrayUtils.append((BoolVar[])l1.get(3),(BoolVar[])l2.get(3));
		Constraint ctobj = IntConstraintFactory.sum(new IntVar[]{((IntVar)l1.get(0)),((IntVar)l2.get(0))}, newobj);
		Constraint[] newres = ArrayUtils.append((Constraint[])l1.get(1),(Constraint[])l2.get(1), new Constraint[]{ctobj});
		ArrayList<Object> l = new ArrayList<Object>();
		l.add(newobj);  // quality obj variable
		l.add(newres);   // constraints
		l.add(newalloc); // aaditional integer variables
		l.add(newbinalloc); // aaditional binary variables
		return l;
	}
	
	public static ArrayList<Object> all(IntVar[] cardvars, IntVar[] resvars, IntVar[] smoothvars, int s1, int s2) {
		ArrayList<Object> distl = maxDistanceDouble(cardvars,resvars);
		ArrayList<Object> smoothl = smoothDouble(smoothvars, s1, s2);
		IntVar newobj = VariableFactory.bounded("cumulQualityAll", 0, ((IntVar)distl.get(0)).getUB()+((IntVar)smoothl.get(0)).getUB(), ((IntVar)distl.get(0)).getSolver());  
		IntVar[] newalloc = ArrayUtils.append((IntVar[])distl.get(2),(IntVar[])smoothl.get(2));
		BoolVar[] newbinalloc = (BoolVar[])smoothl.get(3);
		Constraint ctobj = IntConstraintFactory.sum(new IntVar[]{((IntVar)distl.get(0)),((IntVar)smoothl.get(0))}, newobj);
		Constraint[] newres = ArrayUtils.append((Constraint[])distl.get(1),(Constraint[])smoothl.get(1), new Constraint[]{ctobj});
		ArrayList<Object> l = new ArrayList<Object>();
		l.add(newobj);  // quality obj variable
		l.add(newres);   // constraints
		l.add(newalloc); // aaditional integer variables
		l.add(newbinalloc); // aaditional binary variables
		return l;
	}

	public static int smoothCHK(int[] tuple, int s) {
		Solver solver = new Solver();
		IntVar[] vars = new IntVar[tuple.length];
		for(int i=0; i<vars.length; i++) {
			vars[i] = VariableFactory.fixed(tuple[i], solver);
		}
		ArrayList<Object> l = smooth(vars,s); 
		IntVar qobj = (IntVar)l.get(0);
		solver.post((Constraint[])l.get(1));
		solver.findSolution();
		if(solver.getMeasures().getSolutionCount()>0) {
			return qobj.getValue();
		} else {
			return -1; 
		}
	}
	
	// Among
	
	public static ArrayList<Object> among(IntVar[] vars, int[] values) {
		ArrayList<Object> l = new ArrayList<Object>();
		int n = vars.length;
		Solver solver = vars[0].getSolver();	
		IntVar qobj = VariableFactory.bounded("qobj", 0, n, solver);
		Constraint[] res = new Constraint[1];
		res[0] = IntConstraintFactory.among(qobj, vars, values);
		l.add(qobj); 
		l.add(res);
		return l; 
	}
	
	public static int amongCHK(int[] tuple, int[] values) {
		Solver s = new Solver();
		IntVar[] vars = new IntVar[tuple.length];
		for(int i=0; i<vars.length; i++) {
			vars[i] = VariableFactory.fixed(tuple[i], s);
		}
		ArrayList<Object> l = among(vars, values); 
		IntVar qobj = (IntVar)l.get(0);
		s.post((Constraint[])l.get(1));
		s.findSolution();
		if(s.getMeasures().getSolutionCount()>0) {
			return qobj.getValue();
		} else {
			return -1; 
		}
	}

	// Unary test
	
	public static void main(String[] args) {
		int[] values = {1,2,3};
		int[] tuple = {1,6,7,8,8,2,3,3,4,1,-1,7,9};
		int s = 4;
		System.out.println("MaxDistance:\t\t" + maxDistanceCHK(tuple));
		System.out.println("MaxConsDistance:\t" + maxConsDistanceCHK(tuple));
		System.out.println("Smooth with gap " + s + ":\t" + smoothCHK(tuple,s));
		System.out.println("Among: {1,2,3}:\t\t" + amongCHK(tuple,values));
	}
}

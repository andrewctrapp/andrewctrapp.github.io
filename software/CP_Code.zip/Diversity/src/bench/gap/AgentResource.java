// T.Petit 2016
package bench.gap;

import java.util.ArrayList;

import org.chocosolver.solver.Solver;
import org.chocosolver.solver.constraints.Constraint;
import org.chocosolver.solver.variables.IntVar;

import constraints.QualityNotionFactory;

public class AgentResource extends GAPQuality {

	public AgentResource(int[][] jobcosts, int[][] jobres, int[] agentcapas) {
		super(jobcosts, jobres, agentcapas);
	}

	public AgentResource(int[][] jobcosts, int[][] jobres, int[] agentcapas,int objub) {
		super(jobcosts, jobres, agentcapas,objub);
	}
	
	public AgentResource(int[][] jobcosts, int[][] jobres, int[] agentcapas,int objub, int objlb) {
		super(jobcosts, jobres, agentcapas,objub,objlb);
	}
	
	@Override
	public Solver duplicate() {
		Solver solver = super.duplicate();
		qualityVars = resagents;
		ArrayList<Object> l = QualityNotionFactory.maxDistance(qualityVars); 
		qualityObj = (IntVar) l.get(0); 
		qualityCt = (Constraint[])l.get(1);
		additionalIntVars = (IntVar[]) l.get(2);
		return solver;
	}
	
	@Override
	public String getQualityType() { // This method MUST be defined to let the onlinescheme know that there is a quality notion result to store
		return QualityNotionFactory.MAXDISTANCE;
	}

}

// T.Petit 2016
package bench.gap;

// Main bench on GAP
// The results will be written in files within the 'res' folder included in this project

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.regex.Pattern;

import constraints.DistanceHam;
import constraints.DistanceI;
import constraints.QualityNotionFactory;
import model.AbstractModel;
import onlinescheme.AbstractOnline;
import onlinescheme.Results;
import onlinescheme.WRatio;

public class BenchPaper {

	protected int timelimit;
	protected int smoothgap1;
	protected int smoothgap2;
	
	public BenchPaper(int timelimit, int smoothgap1, int smoothgap2) {
		this.timelimit = timelimit;
		this.smoothgap1 = smoothgap1;
		this.smoothgap2 = smoothgap2;
	}
	
	// ---------------------------------------
	// Evaluate the maximum possible diversity
	// ---------------------------------------

	public static int refinedMaxDiver(String file) {
		GAPInstance gi = GAP.parseInstance(file);
		return (gi.jobcosts.length/gi.agentcapas.length); 
	}

	
	// ---------------------------------------------
	// Extract all quality values from solver traces
	// ---------------------------------------------

	@SuppressWarnings("unchecked")
	public static int[] extractVarValues(String allVarValues, String name) {
		@SuppressWarnings("rawtypes")
		ArrayList l = new ArrayList();
		Pattern p = Pattern.compile("\n");
		String[] items = p.split(allVarValues);
		for(int i=0; i<items.length; i++) {
			if(items[i].contains(name)) {
				Pattern p2 = Pattern.compile(" ");
				String[] items2 = p2.split(items[i]);
				l.add(items2[2]);        // value is at index 2; cardinalityagent:0 = 19
			}
		}
		int size = l.size();
		int [] res = new int[size];
		for(int i=0; i<res.length; i++) {
			res[i] = Integer.parseInt((String)l.get(i));
		}
		return res; 
	}

	public static String allQuality(ArrayList<String> allVars) {
		String s = ""; 
		int size = allVars.size();
		int[] values; 
		// Agent cardinality values
		//s += "\n max distance on agent cardinality =\t\t\t[";
		s += "\n maxCard_ =\t[";
		for(int i = 0; i<size-1; i++) {
			values = extractVarValues(allVars.get(i),"cardinalityagents");
			s += QualityNotionFactory.maxDistanceCHK(values) + ",";
		}
		values = extractVarValues(allVars.get(size-1),"cardinalityagents");
		s += QualityNotionFactory.maxDistanceCHK(values);
		s += "]";
		// Agent resource values
		// s += "\n max distance on agent resource =\t\t\t[";
		s += "\n maxRes_ =\t[";
		for(int i = 0; i<size-1; i++) {
			values = extractVarValues(allVars.get(i),"resagents");
			s += QualityNotionFactory.maxDistanceCHK(values) + ",";
		}
		values = extractVarValues(allVars.get(size-1),"resagents");
		s += QualityNotionFactory.maxDistanceCHK(values);
		s += "]";
		return s;
	}

	public static String smoothQuality(ArrayList<String> allVars, int gap) {
		String s =""; 
		int size = allVars.size();
		int[] values; 
		//s+= "\n smooth on job costs, gap "+ gap + " =\t\t\t\t[";
		s+= "\n smooth"+gap+"_ =\t[";
		for(int i = 0; i<size-1; i++) {
			values = extractVarValues(allVars.get(i),"costperjob");
			s += QualityNotionFactory.smoothCHK(values,gap) + ",";
		}
		values = extractVarValues(allVars.get(size-1),"costperjob");
		s += QualityNotionFactory.smoothCHK(values,gap);
		s += "]";
		return s; 
	}
	
	// -----------
	// Bench types
	// If no ub: set objub = -1
	// If no lb: set objlb = 0
	// Warning ub before lb in parameters
	// -----------
	
	// No quality notion
	public AbstractOnline noquality(String file, int nbsolutions, long timelimit, int maxLossObj, int minRequiredDiver, int wobj, int wdiv) {
		GAPInstance gi = GAP.parseInstance(file);
		AbstractModel m = new GAP(gi.jobcosts,gi.jobres,gi.agentcapas);
		DistanceI dist = new DistanceHam();
		AbstractOnline p = new WRatio(m,maxLossObj,minRequiredDiver,nbsolutions,dist,wobj,wdiv);
		p.onlineGeneration(timelimit, refinedMaxDiver(file));
		return p; 
	}

	// Minimize maximum pairwise distance among agent job assignment cardinalities
	public String min_max_agent_cardinality(String file, int nbsolutions, long timelimit, int maxLossObj, 
			int minRequiredDiver, int wobj, int wdiv, int wqua,int objub,int objlb) {
		boolean maximize = false;  // the quality notion should be minimized
		GAPInstance gi = GAP.parseInstance(file);
		AbstractModel m = new AgentCardinality(gi.jobcosts,gi.jobres,gi.agentcapas,objub,objlb);
		DistanceI dist = new DistanceHam();
		AbstractOnline p = new WRatio(m,maxLossObj,minRequiredDiver,nbsolutions,dist,wobj,wdiv,wqua,maximize);
		p.onlineGeneration(timelimit, refinedMaxDiver(file));
		String result = p.res.toString(true);
		result += p.res.python();
		result += allQuality(p.res.getAllVars());
		result += smoothQuality(p.res.getAllVars(),smoothgap1);
		result += smoothQuality(p.res.getAllVars(),smoothgap2);
		return result;
	}
	
	// Minimize maximum pairwise distance among agent resource consumptions
	public String min_max_agent_resource(String file, int nbsolutions, long timelimit, int maxLossObj, 
			int minRequiredDiver, int wobj, int wdiv, int wqua,int objub,int objlb) {
		boolean maximize = false;  // the quality notion should be minimized
		GAPInstance gi = GAP.parseInstance(file);
		AbstractModel m = new AgentResource(gi.jobcosts,gi.jobres,gi.agentcapas,objub,objlb);
		DistanceI dist = new DistanceHam();
		AbstractOnline p = new WRatio(m,maxLossObj,minRequiredDiver,nbsolutions,dist,wobj,wdiv,wqua,maximize);
		p.onlineGeneration(timelimit, refinedMaxDiver(file));
		String result = p.res.toString(false);
		result += p.res.python();
		result += allQuality(p.res.getAllVars());
		result += smoothQuality(p.res.getAllVars(),smoothgap1);
		result += smoothQuality(p.res.getAllVars(),smoothgap2);
		return result;
	}

	// Minimize a var agent cardinality max distance + agent resource max distance
	public String min_max_agent_cardinality_resource(String file, int nbsolutions, long timelimit, int maxLossObj, 
			int minRequiredDiver, int wobj, int wdiv, int wqua,int objub, int objlb) {
		boolean maximize = false;  // the quality notion should be minimized
		GAPInstance gi = GAP.parseInstance(file);
		AbstractModel m = new AgentCardinalityResource(gi.jobcosts,gi.jobres,gi.agentcapas,objub,objlb);
		DistanceI dist = new DistanceHam();
		AbstractOnline p = new WRatio(m,maxLossObj,minRequiredDiver,nbsolutions,dist,wobj,wdiv,wqua,maximize);
		p.onlineGeneration(timelimit, refinedMaxDiver(file));
		String result = p.res.toString(true);
		result += p.res.python();
		result += allQuality(p.res.getAllVars());
		result += smoothQuality(p.res.getAllVars(),smoothgap1);
		result += smoothQuality(p.res.getAllVars(),smoothgap2);
		return result;
	}
	
	// Minimize smooth violations of consecutive job cost variables, give a certain gap
	public String min_smooth_cost(String file, int nbsolutions, long timelimit, int maxLossObj, 
			int minRequiredDiver, int wobj, int wdiv, int wqua, int gap, int objub,int objlb) {
		boolean maximize = false;  // the quality notion should be minimized
		GAPInstance gi = GAP.parseInstance(file);
		AbstractModel m = new AgentJobSmoothCost(gi.jobcosts,gi.jobres,gi.agentcapas,gap,objub,objlb);
		DistanceI dist = new DistanceHam();
		AbstractOnline p = new WRatio(m,maxLossObj,minRequiredDiver,nbsolutions,dist,wobj,wdiv,wqua,maximize);
		p.onlineGeneration(timelimit, refinedMaxDiver(file));
		String result = p.res.toString(true);
		result += p.res.python();
		result += allQuality(p.res.getAllVars());
		result += smoothQuality(p.res.getAllVars(),smoothgap1);
		result += smoothQuality(p.res.getAllVars(),smoothgap2);
		return result;
	}
	
	// Minimize sum of smooth violations with two gaps
	public String min_smooth_cost_double(String file, int nbsolutions, long timelimit, int maxLossObj, 
			int minRequiredDiver, int wobj, int wdiv, int wqua, int gap1, int gap2, int objub,int objlb) {
		boolean maximize = false;  // the quality notion should be minimized
		GAPInstance gi = GAP.parseInstance(file);
		AbstractModel m = new AgentJobSmoothCostDoubleGap(gi.jobcosts,gi.jobres,gi.agentcapas,gap1,gap2,objub,objlb);
		DistanceI dist = new DistanceHam();
		AbstractOnline p = new WRatio(m,maxLossObj,minRequiredDiver,nbsolutions,dist,wobj,wdiv,wqua,maximize);
		p.onlineGeneration(timelimit, refinedMaxDiver(file));
		String result = p.res.toString(true);
		result += p.res.python();
		result += allQuality(p.res.getAllVars());
		result += smoothQuality(p.res.getAllVars(),smoothgap1);
		result += smoothQuality(p.res.getAllVars(),smoothgap2);
		return result;
	}
	
	// Minimize sum of all 4 quality variables
	public String min_all(String file, int nbsolutions, long timelimit, int maxLossObj, 
			int minRequiredDiver, int wobj, int wdiv, int wqua, int gap1, int gap2, int objub,int objlb) {
		boolean maximize = false;  // the quality notion should be minimized
		GAPInstance gi = GAP.parseInstance(file);
		AbstractModel m = new AgentMaxDistanceAndSmooth(gi.jobcosts,gi.jobres,gi.agentcapas,gap1,gap2,objub,objlb);
		DistanceI dist = new DistanceHam();
		AbstractOnline p = new WRatio(m,maxLossObj,minRequiredDiver,nbsolutions,dist,wobj,wdiv,wqua,maximize);
		p.onlineGeneration(timelimit, refinedMaxDiver(file));
		String result = p.res.toString(true);
		result += p.res.python();
		result += allQuality(p.res.getAllVars());
		result += smoothQuality(p.res.getAllVars(),smoothgap1);
		result += smoothQuality(p.res.getAllVars(),smoothgap2);
		return result;
	}
	

	// --------------------
	// Print result in file
	// --------------------

	public static void printint(String res, String filename) {
		try {
			PrintWriter writer = new PrintWriter(filename);
			writer.println(res);
			writer.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	// -----
	// Tests
	// -----
	
	public Results bench_1_noquality(boolean printit, String file, int nbsolutions) {
		int maxLossObj  		= 1000;
		int minRequiredDiver  	= 1;
		int wobj				= 1;
		int wdiv				= 500;
		AbstractOnline p = noquality(file,nbsolutions,timelimit,maxLossObj,minRequiredDiver,wobj,wdiv);
		String result = p.res.toString(true);
		result += p.res.python();
		result += allQuality(p.res.getAllVars());
		result += smoothQuality(p.res.getAllVars(),smoothgap1);
		result += smoothQuality(p.res.getAllVars(),smoothgap2);
		if(printit) {
			Pattern pat = Pattern.compile("/");
			String[] items = pat.split(file);
			printint(result,"res/bench_1_noquality_"+items[items.length-1]+".txt");
		} else {
			System.out.println(result);
		}
		return p.res;
	}

	public void bench_1_min_max_agent_cardinality(boolean printit, String file, int nbsolutions,int bestobj) {
		int maxLossObj  		= 1000;
		int minRequiredDiver  	= 1;
		int wobj				= 1;
		int wdiv				= 500;
		int wqua				= 50;
		String res = min_max_agent_cardinality(file,nbsolutions,timelimit,maxLossObj,minRequiredDiver,wobj,wdiv,wqua,bestobj,0);
		if(printit) {
			Pattern p = Pattern.compile("/");
			String[] items = p.split(file);
			printint(res,"res/bench_1_min_max_agent_cardinality_"+items[items.length-1]+".txt");
		} else {
			System.out.println(res);
		}
	}
	
	public void bench_1_min_max_agent_resource(boolean printit, String file, int nbsolutions,int bestobj) {
		int maxLossObj  		= 1000;
		int minRequiredDiver  	= 1;
		int wobj				= 1;
		int wdiv				= 500;
		int wqua				= 50;
		String res = min_max_agent_resource(file,nbsolutions,timelimit,maxLossObj,minRequiredDiver,wobj,wdiv,wqua,bestobj,0);
		if(printit) {
			Pattern p = Pattern.compile("/");
			String[] items = p.split(file);
			printint(res,"res/bench_1_min_max_agent_resource_"+items[items.length-1]+".txt");
		} else {
			System.out.println(res);
		}
	}

	public void bench_1_min_max_agent_cardinality_resource(boolean printit, String file, int nbsolutions, int bestobj) {
		int maxLossObj  		= 1000;
		int minRequiredDiver  	= 1;
		int wobj				= 1;
		int wdiv				= 500;
		int wqua				= 50;
		String res = min_max_agent_cardinality_resource(file,nbsolutions,timelimit,maxLossObj,minRequiredDiver,wobj,wdiv,wqua,bestobj,0);
		if(printit) {
			Pattern p = Pattern.compile("/");
			String[] items = p.split(file);
			printint(res,"res/bench_1_min_max_agent_cardinality_resource_"+items[items.length-1]+".txt");
		} else {
			System.out.println(res);
		}
	}
	
	public void bench_1_min_smooth_cost1(boolean printit, String file, int nbsolutions, int bestobj) {
		int maxLossObj  		= 1000;
		int minRequiredDiver  	= 1;
		int wobj				= 1;
		int wdiv				= 500;
		int wqua				= 50;
		String res = min_smooth_cost(file,nbsolutions,timelimit,maxLossObj,minRequiredDiver,wobj,wdiv,wqua,smoothgap1,bestobj,0);
		if(printit) {
			Pattern p = Pattern.compile("/");
			String[] items = p.split(file);
			printint(res,"res/bench_1_min_smooth_cost_"+smoothgap1+"_"+items[items.length-1]+".txt");
		} else {
			System.out.println(res);
		}
	}

	public void bench_1_min_smooth_cost2(boolean printit, String file, int nbsolutions, int bestobj) {
		int maxLossObj  		= 1000;
		int minRequiredDiver  	= 1;
		int wobj				= 1;
		int wdiv				= 500;
		int wqua				= 50;
		String res = min_smooth_cost(file,nbsolutions,timelimit,maxLossObj,minRequiredDiver,wobj,wdiv,wqua,smoothgap2,bestobj,0);
		if(printit) {
			Pattern p = Pattern.compile("/");
			String[] items = p.split(file);
			printint(res,"res/bench_1_min_smooth_cost_"+smoothgap2+"_"+items[items.length-1]+".txt");
		} else {
			System.out.println(res);
		}
	}
	
	public void bench_1_min_smooth_cost1_and_2(boolean printit, String file, int nbsolutions,int bestobj) {
		int maxLossObj  		= 1000;
		int minRequiredDiver  	= 1;
		int wobj				= 1;
		int wdiv				= 500;
		int wqua				= 50;
		String res = min_smooth_cost_double(file,nbsolutions,timelimit,maxLossObj,minRequiredDiver,wobj,wdiv,wqua,smoothgap1,smoothgap2,bestobj,0);
		if(printit) {
			Pattern p = Pattern.compile("/");
			String[] items = p.split(file);
			printint(res,"res/bench_1_min_smooth_cost_"+smoothgap1+"_and_"+smoothgap2+"_"+items[items.length-1]+".txt");
		} else {
			System.out.println(res);
		}
	}
	
	public void bench_1_all(boolean printit, String file, int nbsolutions,int bestobj) {
		int maxLossObj  		= 1000;
		int minRequiredDiver  	= 1;
		int wobj				= 1;
		int wdiv				= 500;
		int wqua				= 50;
		String res = min_all(file,nbsolutions,timelimit,maxLossObj,minRequiredDiver,wobj,wdiv,wqua,smoothgap1,smoothgap2,bestobj,0);
		if(printit) {
			Pattern p = Pattern.compile("/");
			String[] items = p.split(file);
			printint(res,"res/bench_1_"+"all"+"_"+items[items.length-1]+".txt");
		} else {
			System.out.println(res);
		}
	}
	
	// ---------
	// Main test
	// ---------
	
	@SuppressWarnings("rawtypes")
	public static void test(int timelimit, int nbsolutions, int bestobj) { 
		
		int gap1 = 5;
		int gap2 = 15;
		int percent = 3; // maximal percentage above bestobj
		boolean printinfile = true;
		// String[] file = {"gap/gap_a/a05100"}; 
		String[] file = {"gap/gap_a/a20100"}; 
		BenchPaper myinst = new BenchPaper(timelimit,gap1,gap2);
		
		for(int i=0; i<file.length; i++) {
			System.out.println("\n----\n"+file[i]);
			if(bestobj==-1) {
				// Solve with noquality
				Results r = myinst.bench_1_noquality(printinfile, file[i],nbsolutions);
				ArrayList objv = r.objValues;
				int min = (int)objv.get(0);
				for (Object j : objv){
					int intj = (int)j;
					min = min < intj ? min : intj;
				} 
				bestobj = min*(100+percent)/100;
			} else {
				bestobj = bestobj*(100+percent)/100; 
			}
			System.out.println("new limit ="+bestobj);
			// solve other benches
			// REMOVE THE COMMENT SYMBOL FOR THE BENCH YOU WISH TO RUN
			myinst.bench_1_min_max_agent_cardinality(printinfile,file[i],nbsolutions,bestobj);
			//myinst.bench_1_min_max_agent_resource(printinfile,file[i],nbsolutions,bestobj);
			//myinst.bench_1_min_smooth_cost1(printinfile,file[i],nbsolutions,bestobj); 
			//myinst.bench_1_min_smooth_cost2(printinfile,file[i],nbsolutions,bestobj); 
			//myinst.bench_1_min_max_agent_cardinality_resource(printinfile,file[i],nbsolutions,bestobj);
			//myinst.bench_1_min_smooth_cost1_and_2(printinfile,file[i],nbsolutions,bestobj); 
			//myinst.bench_1_all(printinfile,file[i],nbsolutions,bestobj);
		}
	}

	public static void main(String[] args) {

			int timelimit = 1000; // in miliseconds -- refer to the paper to reproduce the tests with appropriate (higher) time limits
					                         // 4*300000; // 300000; 
			int nbsolutions = 12; // 51;
			test(timelimit,nbsolutions,-1); // Run with -1 when we do not know the optimal value without side constraints
			                                               // To use known values and avoid a useless run, just set the value instead of -1 (as in the examples below)
														   // test(timelimit,nbsolutions,1698); 
														   // test(timelimit,nbsolutions,1158); 
			
	}
	
}
	


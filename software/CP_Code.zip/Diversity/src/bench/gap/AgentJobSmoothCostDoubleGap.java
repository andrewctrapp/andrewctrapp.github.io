// T.Petit 2016
package bench.gap;

import java.util.ArrayList;

import org.chocosolver.solver.Solver;
import org.chocosolver.solver.constraints.Constraint;
import org.chocosolver.solver.variables.BoolVar;
import org.chocosolver.solver.variables.IntVar;

import constraints.QualityNotionFactory;

public class AgentJobSmoothCostDoubleGap extends GAPQuality {

	protected int gap1;
	protected int gap2; 
	public AgentJobSmoothCostDoubleGap(int[][] jobcosts, int[][] jobres, int[] agentcapas, int gap1, int gap2) {
		super(jobcosts, jobres, agentcapas);
		this.gap1 = gap1;
		this.gap2 = gap2; 
	}
	
	public AgentJobSmoothCostDoubleGap(int[][] jobcosts, int[][] jobres, int[] agentcapas, int gap1, int gap2, int objub) {
		super(jobcosts, jobres, agentcapas,objub);
		this.gap1 = gap1;
		this.gap2 = gap2; 
	}
	
	public AgentJobSmoothCostDoubleGap(int[][] jobcosts, int[][] jobres, int[] agentcapas, int gap1, int gap2, int objub, int objlb) {
		super(jobcosts, jobres, agentcapas,objub,objlb);
		this.gap1 = gap1;
		this.gap2 = gap2;  
	}

	@Override
	public Solver duplicate() {
		Solver solver = super.duplicate();
		qualityVars = costperjob;
		ArrayList<Object> l = QualityNotionFactory.smoothDouble(qualityVars,gap1,gap2); 
		qualityObj = (IntVar) l.get(0); 
		qualityCt = (Constraint[])l.get(1);
		additionalIntVars = (IntVar[]) l.get(2);
		additionalBoolVars = (BoolVar[]) l.get(3);
		return solver;
	}
	
	@Override
	public String getQualityType() { // This method MUST be defined to let the onlinescheme know that there is a quality notion result to store
		return QualityNotionFactory.SMOOTH;
	}

}

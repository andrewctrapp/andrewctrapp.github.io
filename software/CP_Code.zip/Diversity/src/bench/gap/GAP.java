// T.Petit 2016
package bench.gap;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;

import org.chocosolver.solver.ResolutionPolicy;
import org.chocosolver.solver.Solver;
import org.chocosolver.solver.constraints.Constraint;
import org.chocosolver.solver.constraints.IntConstraintFactory;
import org.chocosolver.solver.search.strategy.IntStrategyFactory;
import org.chocosolver.solver.search.strategy.strategy.AbstractStrategy;
import org.chocosolver.solver.variables.BoolVar;
import org.chocosolver.solver.variables.IntVar;
import org.chocosolver.solver.variables.Variable;
import org.chocosolver.solver.variables.VariableFactory;
import org.chocosolver.util.tools.ArrayUtils;

import model.AbstractModel;
import model.ModelI;

// Constraint model for GAP

public class GAP extends AbstractModel implements ModelI {

	final static Boolean DEBUG = false; 
	final static Boolean DISPLAY = true; 

	// ------
	// Parser
	// ------
	
	@SuppressWarnings("resource")
	public static GAPInstance parseInstance(String url) {
		GAPInstance g = new GAPInstance();
		File file = new File(url);
		try {
			BufferedReader buf = new BufferedReader(new FileReader(file));
			String line = buf.readLine();
			if(DEBUG) System.out.println(line);
			g.nbagents = Integer.parseInt(line.split(" ")[1]);
			g.nbjobs = Integer.parseInt(line.split(" ")[2]);
			if(DEBUG) System.out.println(""+g.nbagents+","+g.nbjobs);
			g.jobcosts = new int[g.nbjobs][g.nbagents]; 
			g.jobres = new int[g.nbjobs][g.nbagents]; 
			g.agentcapas = new int[g.nbagents];
			int a = 0;
			int j = 0;
			// costs
			while(a<g.nbagents) {
				while(j<g.nbjobs) {
					line = buf.readLine();
					String[] values = line.split(" ");
					for(int i=1; i<values.length;i++) {
						g.jobcosts[j][a] = Integer.parseInt(values[i]);
						if(DEBUG) System.out.println("("+a+","+j+") = "+g.jobcosts[j][a]);
						j++;
					}
				}
				a++;
				j=0;
			}
			// resources
			a = 0;
			while(a<g.nbagents) {
				while(j<g.nbjobs) {
					line = buf.readLine();
					String[] values = line.split(" ");
					for(int i=1; i<values.length;i++) {
						g.jobres[j][a] = Integer.parseInt(values[i]);
						if(DEBUG) System.out.println("("+a+","+j+") = "+g.jobres[j][a]);
						j++;
					}
				}
				a++;
				j=0;
				if(DEBUG) System.out.println(a);
			}
			// capas
			a = 0;
			while(a<g.nbagents) {
				line = buf.readLine();
				String[] values = line.split(" ");
				for(int i=1; i<values.length;i++) {
					g.agentcapas[a]=Integer.parseInt(values[i]);
					if(DEBUG) System.out.println(g.agentcapas[a]);
					a++;
				}
			}
		} catch (Exception e) {
			System.out.println("Error with file "+url);
		}
		return g;
	}

	// ----------------
	// Constraint model
	// ----------------
	
	// Variables
	IntVar[][] x;                             // Boolean matrix nbjobs x nbagents
	IntVar[][] allres; 						  // Resources nbjobs x nbagents
	IntVar obj;								  // Sum of costs of all jobs
	IntVar resobj;						      // Sum of resources consumed for all jobs
	IntVar[] costperjob;					  // Cost per job
	IntVar[] resperjob;      			      // Resource per job
	IntVar[] resagents; 					  // Sum of consumed resource per agent
	IntVar[] cardagents;					  // Number of jobs realized by each agent
	
	// Data, strategy
	AbstractStrategy<Variable> strat;
	int[][] jobcosts, jobres; 
	int[] agentcapas;
	int nbjobs;
	int nbagents; 
	int maxcost; 
	int objub; 
	int objlb;
	
	// Maximum value in an integer matrix
	public static int maxvalue(int[][] matrix) {
		int res = 0;
		for(int i=0;i<matrix.length;i++) {
			for(int j=0; j<matrix[i].length; j++){
				res = Math.max(res, matrix[i][j]); 
			}
		}
		return res;
	}
	
	// Column j of an integer matrix
	public static int[] column(int[][] matrix, int j) {
		int[] res = new int[matrix.length];
		for(int i=0; i<matrix.length; i++){
			res[i] = matrix[i][j];
		}
		return res;
	}

	// Sum of all capacities
	public static int sumcapas(int[] agentcapas) {
		int res = 0;
		for(int i=0; i<agentcapas.length; i++) {
			res += agentcapas[i];
		}
		return res; 
	}
	
	public GAP(int[][] jobcosts, int[][] jobres, int[] agentcapas, int objub, int objlb) {
		this.jobcosts=jobcosts;
		this.jobres=jobres;
		this.agentcapas=agentcapas;
		nbjobs = jobcosts.length;
		nbagents = agentcapas.length;
		maxcost = maxvalue(jobcosts);
		this.objub = objub;
		this.objlb = objlb; 
	}
	
	public GAP(int[][] jobcosts, int[][] jobres, int[] agentcapas, int objub) {
		this(jobcosts,jobres,agentcapas,objub,0);
	}
	
	public GAP(int[][] jobcosts, int[][] jobres, int[] agentcapas){
		this(jobcosts, jobres, agentcapas,-1);
	}
	
	// end new
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public Solver duplicate() {
		
		// New solver instance at each call
		
		Solver s = new Solver();
		
		// Variables
		
		x = VariableFactory.enumeratedMatrix("x", nbjobs, nbagents, 0, 1, s);  // matrix njpbbs x nagents of boolean variables
		if (objub == -1) {
			objub = maxcost*nbjobs;
		}
		obj = VariableFactory.bounded("obj", objlb,objub, s);             // total cost: one job will be selected per row
		resagents = new IntVar[nbagents]; 									   // sum of resource consumed by each agent
		cardagents = new IntVar[nbagents]; 
		for(int j=0; j<nbagents; j++) {	
			resagents[j] = VariableFactory.bounded("resagents:"+j, 0, agentcapas[j], s);
			cardagents[j] = VariableFactory.bounded("cardinalityagents:"+j, 0, nbjobs, s);
		}
		costperjob = new IntVar[nbjobs];		    // cost per job
		allres = new IntVar[nbjobs][nbagents]; 		// matrix njobs x nagents of integer resources 
		resperjob = new IntVar[nbjobs];			    // resource per job
		for(int i=0; i<nbjobs; i++) {
			ArrayList l = new ArrayList(); 
			for(int k=0; k<jobcosts[i].length; k++) {
				if(!l.contains(jobcosts[i][k])) {
					l.add(jobcosts[i][k]);
				}
			}
			Object[] domain = l.toArray();
			int[] idomain = new int[domain.length];
			for(int k=0; k<idomain.length; k++) {
				idomain[k] = (Integer) domain[k];
			}
			Arrays.sort(idomain);
			costperjob[i] = VariableFactory.enumerated("costperjob:"+i, idomain, s);  // each job is executed exactly once
			for(int j=0; j< nbagents; j++) {
				allres[i][j] = VariableFactory.enumerated("allres:"+i+","+j, new int[]{0,jobres[i][j]}, s);
			}
			l = new ArrayList(); 
			for(int k=0; k<jobres[i].length; k++) {
				if(!l.contains(jobres[i][k])) {
					l.add(jobres[i][k]);
				}
			}
			domain = l.toArray();
			idomain = new int[domain.length];
			for(int k=0; k<idomain.length; k++) {
				idomain[k] = (Integer) domain[k];
			}
			Arrays.sort(idomain);
			resperjob[i] = VariableFactory.enumerated("sumres:"+i, idomain, s);  // each job is executed exactly once
		} 
		resobj = VariableFactory.bounded("resobj", 0, sumcapas(agentcapas), s);
		
		// Constraints
		
		for(int i=0; i<nbjobs; i++) {
			s.post(IntConstraintFactory.sum(x[i], VariableFactory.fixed(1, s)));
			s.post(IntConstraintFactory.scalar(x[i], jobcosts[i], costperjob[i]));
			s.post(IntConstraintFactory.sum(allres[i], resperjob[i]));
			for(int j=0; j<nbagents; j++) {
				s.post(IntConstraintFactory.times(x[i][j], jobres[i][j], allres[i][j]));
			}
		}
		s.post(IntConstraintFactory.sum(costperjob, obj));
		s.post(IntConstraintFactory.sum(resperjob, resobj));
		s.post(IntConstraintFactory.scalar(ArrayUtils.flatten(x), ArrayUtils.flatten(jobcosts), obj));
		for(int j=0; j<nbagents; j++) {
			s.post(IntConstraintFactory.scalar(ArrayUtils.getColumn(x,j), column(jobres, j), resagents[j]));
			s.post(IntConstraintFactory.sum(ArrayUtils.getColumn(x,j), cardagents[j]));
		}

		strat = IntStrategyFactory.sequencer(
				IntStrategyFactory.domOverWDeg(costperjob,1),
				IntStrategyFactory.domOverWDeg(ArrayUtils.flatten(x),1),
				IntStrategyFactory.lexico_Neq_LB(resagents),
				IntStrategyFactory.lexico_Neq_LB(cardagents),
				IntStrategyFactory.domOverWDeg(resperjob,1),
				IntStrategyFactory.domOverWDeg(ArrayUtils.flatten(allres),1),
				IntStrategyFactory.lexico_Neq_LB(new IntVar[] {obj}),
				IntStrategyFactory.lexico_UB(new IntVar[] {resobj})
				);
		s.set(strat); 
		return s;
		
	} 

	@Override
	public IntVar[] getDiversityVars() {
		return ArrayUtils.flatten(allres); 
	}

	@Override
	public IntVar getObj() {
		return obj;
	}

	@Override
	public AbstractStrategy<Variable> getStrategy() {
		return strat; 
	}

	@Override
	public IntVar[] getQualityVars() {
		return null;
	}
	
	@Override
	public IntVar getQualityObj() {
		return null;
	}

	@Override
	public Constraint[] getQualityCt() {
		return null;
	}

	@Override
	public IntVar[] getAdditionalIntVars() {
		return null;
	}

	@Override
	public BoolVar[] getAdditionalBoolVars() {
		return null;
	}

	// -----
	// Debug
	// -----
	
	public String display(Solver s) {
		String res = "";
		if(s.getMeasures().getSolutionCount()>0) {
			res += s.getMeasures();
			if(DISPLAY) {
				System.out.println(s);
				for(int i=0; i<nbjobs; i++) {
					res += "\n";
					for(int j=0; j<nbagents; j++) {
						if(x[i][j].getValue()==0) {
							res += (".\t");
						} else {
							res +=  (jobcosts[i][j]+"\t");
						}
					}
				}
				res += ("\n\n");
				for(int i=0; i<nbjobs; i++) {
					res += "\n";
					for(int j=0; j<nbagents; j++) {
						if(x[i][j].getValue()==0) {
							res +=  (".\t");
						} else {
							res += (jobres[i][j]+"\t");
						}
					}
				}
				res += ("\n\n");
				for(int i=0; i<nbagents; i++) {
					res += (resagents[i].getValue()+"\t");
				}
				res += "\n";
			}
		} else {
			res += "No solution.";
		}
		return res; 
	}
	
	
	// Just for testing
	public static void test() {
		GAPInstance gi = parseInstance("gap/gap_a/a10100");
		GAP g = new GAP(gi.jobcosts,gi.jobres,gi.agentcapas);
		Solver s = g.duplicate();
		s.set(g.getStrategy());
		s.findOptimalSolution(ResolutionPolicy.MINIMIZE, true, g.getObj());
		System.out.println(g.display(s));
	}
	
	/*
	// Just for testing
	public static void example() {
		GAPInstance gi = parseInstance("gap/gap_a/thierry");
		GAP g = new GAP(gi.jobcosts,gi.jobres,gi.agentcapas);
		Solver s = g.duplicate();
		s.set(g.getStrategy());
		s.findSolution();
		System.out.println(g.display(s));
		while(s.nextSolution()) {
			System.out.println(g.display(s));
		}
	}
	
	// Just for testing
	public static void main(String[] args) {
		example();
	}
*/
	
	
}

// T.Petit 2016
package bench.gap;

import java.util.ArrayList;

import org.chocosolver.solver.Solver;
import org.chocosolver.solver.constraints.Constraint;
import org.chocosolver.solver.variables.BoolVar;
import org.chocosolver.solver.variables.IntVar;

import constraints.QualityNotionFactory;

public class AgentJobSmoothCost extends GAPQuality {

	protected int gap; 
	public AgentJobSmoothCost(int[][] jobcosts, int[][] jobres, int[] agentcapas, int gap) {
		super(jobcosts, jobres, agentcapas);
		this.gap = gap; 
	}
	
	public AgentJobSmoothCost(int[][] jobcosts, int[][] jobres, int[] agentcapas, int gap, int objub) {
		super(jobcosts, jobres, agentcapas,objub);
		this.gap = gap; 
	}
	
	public AgentJobSmoothCost(int[][] jobcosts, int[][] jobres, int[] agentcapas, int gap, int objub, int objlb) {
		super(jobcosts, jobres, agentcapas,objub,objlb);
		this.gap = gap; 
	}

	@Override
	public Solver duplicate() {
		Solver solver = super.duplicate();
		qualityVars = costperjob;
		ArrayList<Object> l = QualityNotionFactory.smooth(qualityVars,gap); 
		qualityObj = (IntVar) l.get(0); 
		qualityCt = (Constraint[])l.get(1);
		additionalIntVars = (IntVar[]) l.get(2);
		additionalBoolVars = (BoolVar[]) l.get(3);
		return solver;
	}
	
	@Override
	public String getQualityType() { // This method MUST be defined to let the onlinescheme know that there is a quality notion result to store
		return QualityNotionFactory.SMOOTH;
	}

}

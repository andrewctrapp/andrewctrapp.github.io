// T.Petit 2016
package bench.gap;

import java.util.ArrayList;

import org.chocosolver.solver.Solver;
import org.chocosolver.solver.constraints.Constraint;
import org.chocosolver.solver.variables.IntVar;
import org.chocosolver.util.tools.ArrayUtils;

import constraints.QualityNotionFactory;

public class AgentCardinalityResource extends GAPQuality {

	public AgentCardinalityResource(int[][] jobcosts, int[][] jobres, int[] agentcapas, int objub, int objlb) {
		super(jobcosts, jobres, agentcapas, objub,objlb);
	}
	
	@Override
	public Solver duplicate() {
		Solver solver = super.duplicate();
		qualityVars = ArrayUtils.append(cardagents,resagents);
		ArrayList<Object> l = QualityNotionFactory.maxDistanceDouble(cardagents,resagents); 
		qualityObj = (IntVar) l.get(0); 
		qualityCt = (Constraint[])l.get(1);
		additionalIntVars = (IntVar[]) l.get(2);
		return solver;
	}
	
	@Override
	public String getQualityType() { // This method MUST be defined to let the onlinescheme know that there is a quality notion result to store
		return QualityNotionFactory.MAXDISTANCE;
	}

}

// T.Petit 2016
package bench.gap;

public class GAPInstance {
	public int nbjobs;                 // Number of jobs
	public int nbagents;               // Number of agents
	public int[][] jobcosts;           // Matrix of integer costs njobs x nagents
	public int[][] jobres;             // Matrix of integer resources njobs x nagents
	public int[] agentcapas;		   // Agent capacities
}

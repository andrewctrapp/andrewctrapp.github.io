// T.Petit 2016
package bench.gap;

import java.util.ArrayList;

import org.chocosolver.solver.Solver;
import org.chocosolver.solver.constraints.Constraint;
import org.chocosolver.solver.variables.BoolVar;
import org.chocosolver.solver.variables.IntVar;
import org.chocosolver.util.tools.ArrayUtils;

import constraints.QualityNotionFactory;

public class AgentMaxDistanceAndSmooth extends GAPQuality {

	protected int gap1;
	protected int gap2; 
	public AgentMaxDistanceAndSmooth(int[][] jobcosts, int[][] jobres, int[] agentcapas, int gap1, int gap2) {
		super(jobcosts, jobres, agentcapas);
		this.gap1 = gap1;
		this.gap2 = gap2; 
	}
	
	public AgentMaxDistanceAndSmooth(int[][] jobcosts, int[][] jobres, int[] agentcapas, int gap1, int gap2, int objub) {
		super(jobcosts, jobres, agentcapas,objub);
		this.gap1 = gap1;
		this.gap2 = gap2; 
	}
	
	public AgentMaxDistanceAndSmooth(int[][] jobcosts, int[][] jobres, int[] agentcapas, int gap1, int gap2, int objub, int objlb) {
		super(jobcosts, jobres, agentcapas,objub,objlb);
		this.gap1 = gap1;
		this.gap2 = gap2;  
	}
	
	@Override
	public Solver duplicate() {
		Solver solver = super.duplicate();
		qualityVars = ArrayUtils.append(cardagents,resagents,costperjob);
		ArrayList<Object> l = QualityNotionFactory.all(cardagents,resagents,costperjob,gap1,gap2); 
		qualityObj = (IntVar) l.get(0); 
		qualityCt = (Constraint[])l.get(1);
		additionalIntVars = (IntVar[]) l.get(2);
		additionalBoolVars = (BoolVar[]) l.get(3);
		return solver;
	}
	
	@Override
	public String getQualityType() { // This method MUST be defined to let the onlinescheme know that there is a quality notion result to store
		return QualityNotionFactory.MAXDISTANCE_AND_SMOOTH;
	}
	
}

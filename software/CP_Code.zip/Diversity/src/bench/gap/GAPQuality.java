// T.Petit 2016
package bench.gap;

import org.chocosolver.solver.constraints.Constraint;
import org.chocosolver.solver.variables.BoolVar;
import org.chocosolver.solver.variables.IntVar;

public abstract class GAPQuality extends GAP {

	protected IntVar[] qualityVars; 
	protected IntVar qualityObj;
	protected Constraint[] qualityCt;
	protected IntVar[] additionalIntVars;
	protected BoolVar[] additionalBoolVars;
	
	public GAPQuality(int[][] jobcosts, int[][] jobres, int[] agentcapas) {
		super(jobcosts, jobres, agentcapas);
	}
	
	public GAPQuality(int[][] jobcosts, int[][] jobres, int[] agentcapas, int objub) {
		super(jobcosts, jobres, agentcapas,objub);
	}
	
	public GAPQuality(int[][] jobcosts, int[][] jobres, int[] agentcapas, int objub, int objlb) {
		super(jobcosts, jobres, agentcapas,objub,objlb);
	}
	
	@Override
	public IntVar[] getQualityVars() {
		return qualityVars; 
	}
	
	@Override
	public IntVar getQualityObj() {
		return qualityObj;
	}
	
	@Override
	public Constraint[] getQualityCt() {
		return qualityCt;
	}

	@Override
	public IntVar[] getAdditionalIntVars() {
		return additionalIntVars;
	}
	
	@Override
	public BoolVar[] getAdditionalBoolVars(){
		return additionalBoolVars;
	}
	
}

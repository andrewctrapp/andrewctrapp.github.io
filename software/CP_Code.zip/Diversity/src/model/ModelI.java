// T.Petit 2016
package model;

import org.chocosolver.solver.Solver;
import org.chocosolver.solver.constraints.Constraint;
import org.chocosolver.solver.search.strategy.strategy.AbstractStrategy;
import org.chocosolver.solver.variables.BoolVar;
import org.chocosolver.solver.variables.IntVar;
import org.chocosolver.solver.variables.Variable;

// -------------------------------------------------------------------
// Modeling the initial problem without using duplicate() Choco method
// An instance of this class should be provided to the main procedure
// --------------------------------------------------------------------

public interface ModelI {
	// Problem model: duplicate() method MUST return a NEW instance of Sovler with the following objects created:
	// - Diversity variables
	// - Diversity objective
	// - Each constraint (that must be added to the solver)
	public abstract Solver duplicate();
	// set of variables that should be used for diversity: MUST correspond to the last generated instance
	public abstract IntVar[] getDiversityVars();
	// objective variable considered to be MINIMIZED (use the opposite of original obj for maximization)
	public abstract IntVar getObj();
	// re-generate the search strategy of the original problem
	// MUST create a new instance of a class implementing AbstractStrategy
	public abstract AbstractStrategy<Variable> getStrategy();
	// integer quality variables
	public abstract IntVar[] getQualityVars();
	// variable for the quality notion
	public abstract IntVar getQualityObj();
	// constraints for the quality notion
	public abstract Constraint[] getQualityCt();
	// additional integer variables for the quality notion
	public abstract IntVar[] getAdditionalIntVars(); 
	// additional boolean variables for the quality notion
	public abstract BoolVar[] getAdditionalBoolVars();

}


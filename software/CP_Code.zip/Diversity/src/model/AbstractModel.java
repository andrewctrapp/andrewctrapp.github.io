// T.Petit 2016
package model;

import org.chocosolver.solver.Solver;
import org.chocosolver.solver.variables.IntVar;

// -----------------------------------------------------------------------------------------------------
// Abstract class for model that automatically modified the problem according to generic quality notions
// This is the class used by the online generation scheme. Quality notions may have an additional Object 
// parameter and/or be defined on problem variables that are not the variables used for diversity
// tpetit@wpi.edu
// ------------------------------------------------------------------------------------------------------

public abstract class AbstractModel implements ModelI {

	// -----------------------------------------------------------------
	// Return the objective to consider for quality in the online scheme
	// By default, a simple sum is made with the original objective
	// -----------------------------------------------------------------
	
	public IntVar concreteObj(Solver s) {   
		return this.getObj();
	}

	// -----------------------------------------------------------------------------
	// Return the vars to be considered for quality. By default, diversity variables
	// -----------------------------------------------------------------------------
	
	public IntVar[] getQualityVars() {
		return this.getDiversityVars();
	}
	
	// -------------------------------------------------------------
	// Quality type. None by default, QualityNotionFactory otherwise
	// -------------------------------------------------------------
	
	public String getQualityType() {
		return "None"; 
	}
	
}

// T.Petit 2016
package onlinescheme;

import org.chocosolver.solver.Solver;
import org.chocosolver.solver.constraints.IntConstraintFactory;
import org.chocosolver.solver.search.strategy.IntStrategyFactory;
import org.chocosolver.solver.search.strategy.strategy.AbstractStrategy;
import org.chocosolver.solver.search.strategy.strategy.StrategiesSequencer;
import org.chocosolver.solver.variables.IntVar;
import org.chocosolver.solver.variables.VariableFactory;

import constraints.DistanceI;
import constraints.PropConstraintFactory;
import model.AbstractModel;

@SuppressWarnings("rawtypes")
public class WRatio extends AbstractOnline {

	protected int wobj, wdiv, wqua; // weights on objective loss, diversity, quality
	protected IntVar dividerVar, NumeratorVar; // new solver variables
	boolean maximized; // true if the quality notion should be maximized, false otherwise
	
	public WRatio(AbstractModel model,          // original constraint network
				  int maxLossObj,               // maximum allowed objective loss 
				  int minRequiredDiver,         // minimum required diversity assumed >=1
				  int nbsolutions,              // number of desired solutions
				  DistanceI dist,               // distance type
				  int wol, int wdi, int wqu,    // weights for objective loss, diversity and quality
				  boolean maximized){           // true if the quality notion should be maximized, false otherwise
		this.init(model, maxLossObj, minRequiredDiver, nbsolutions, dist);
		wobj = wol;
		wdiv = wdi;
		wqua = wqu;
		this.maximized = maximized; 
	}
	
	public WRatio(AbstractModel model,      
			  int maxLossObj,               
			  int minRequiredDiver,         
			  int nbsolutions,              
			  DistanceI dist,               
			  int wol, int wdi){            
	this(model, maxLossObj, minRequiredDiver, nbsolutions, dist, wol, wdi, 0, false);
	}
	
	// ----------------------------------------------------------
	// Sets and return the strategy when a quality notion is used
	// Handles the cases with additional int/boolean variables
	// ----------------------------------------------------------
	
	protected AbstractStrategy stratQuality() {
		Solver s = robj.getSolver(); // robj must have been created before call
		AbstractStrategy strat = null;
		if(additionalIntVars==null && additionalBoolVars == null) {
			strat = new StrategiesSequencer(
					strategy,
					IntStrategyFactory.domOverWDeg(new IntVar[]{robj,diver,qualityObj,dividerVar,NumeratorVar}, 1)
					);
		} else {
			if(additionalIntVars==null) {
				strat = new StrategiesSequencer(
						strategy,
						IntStrategyFactory.domOverWDeg(additionalBoolVars,1),
						IntStrategyFactory.domOverWDeg(new IntVar[]{robj,diver,qualityObj,dividerVar,NumeratorVar}, 1)
						);
			}
			if(additionalBoolVars==null) {
				strat = new StrategiesSequencer(
						strategy,
						IntStrategyFactory.domOverWDeg(additionalIntVars,1),
						IntStrategyFactory.domOverWDeg(new IntVar[]{robj,diver,qualityObj,dividerVar,NumeratorVar}, 1)
						);
			}
			if(additionalIntVars!=null && additionalBoolVars!=null) {
				strat = new StrategiesSequencer(
						strategy,
						IntStrategyFactory.domOverWDeg(additionalBoolVars,1),
						IntStrategyFactory.domOverWDeg(additionalIntVars,1),
						IntStrategyFactory.domOverWDeg(new IntVar[]{robj,diver,qualityObj,dividerVar,NumeratorVar}, 1)
						);
			}
		}
		s.set(strat);
		return strat; 
	}
	
	// ------------------------------------------------------------------------------
	// Main procedure: state variables, set constraints and strategy, return strategy
	// ------------------------------------------------------------------------------
	
	@Override
	public AbstractStrategy newObjAndStrategy(Solver s, int next, long lbDiversity) {
		if(wqua == 0) { 
			NumeratorVar = VariableFactory.bounded("wdivVar", wdiv*diver.getLB(), wdiv*diver.getUB(), s); 
			dividerVar = VariableFactory.bounded("wobjVar", wobj*objLoss.getLB()+1, wobj*objLoss.getUB()+1, s); 
			s.post(IntConstraintFactory.scalar(new IntVar[]{diver}, new int[]{wdiv}, NumeratorVar));
			s.post(IntConstraintFactory.scalar(new IntVar[]{objLoss,VariableFactory.fixed(1, s)}, new int[]{wobj,1}, dividerVar));
			robj = VariableFactory.bounded("robj", NumeratorVar.getLB()/Math.max(dividerVar.getUB(), 1), NumeratorVar.getUB()/Math.max(dividerVar.getLB(), 1), s);
			s.post(PropConstraintFactory.new_eucl_div(NumeratorVar, dividerVar, robj));
			AbstractStrategy strat = new StrategiesSequencer(
					strategy,
					IntStrategyFactory.domOverWDeg(new IntVar[]{robj,diver,dividerVar,NumeratorVar}, 1)
					);
			s.set(strat);
			return strat;
		} else {
			if(maximized) {
				NumeratorVar = VariableFactory.bounded("wdivVar", wdiv*diver.getLB()+wqua*qualityObj.getLB(), wdiv*diver.getUB()+wqua*qualityObj.getUB(), s); 
				dividerVar = VariableFactory.bounded("wobjVar", wobj*objLoss.getLB()+1, wobj*objLoss.getUB()+1, s);
				s.post(IntConstraintFactory.scalar(new IntVar[]{diver,qualityObj}, new int[]{wdiv,wqua}, NumeratorVar));
				s.post(IntConstraintFactory.scalar(new IntVar[]{objLoss,VariableFactory.fixed(1, s)}, new int[]{wobj,1}, dividerVar));
			} else {
				NumeratorVar = VariableFactory.bounded("wdivVar", wdiv*diver.getLB(), wdiv*diver.getUB(), s); 
				dividerVar = VariableFactory.bounded("wobjVar", wobj*objLoss.getLB()+wqua*qualityObj.getLB()+1, wobj*objLoss.getUB()+wqua*qualityObj.getUB()+1, s);
				s.post(IntConstraintFactory.scalar(new IntVar[]{diver}, new int[]{wdiv}, NumeratorVar));
				s.post(IntConstraintFactory.scalar(new IntVar[]{objLoss,qualityObj,VariableFactory.fixed(1, s)}, new int[]{wobj,wqua,1}, dividerVar));
			}
			robj = VariableFactory.bounded("robj", NumeratorVar.getLB()/Math.max(dividerVar.getUB(), 1), NumeratorVar.getUB()/Math.max(dividerVar.getLB(), 1), s);
			s.post(PropConstraintFactory.new_eucl_div(NumeratorVar, dividerVar, robj));
			return stratQuality();
		}
	}

}

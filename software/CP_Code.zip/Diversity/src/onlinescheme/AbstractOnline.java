// T.Petit 2016
package onlinescheme;

import java.util.ArrayList;

import org.chocosolver.solver.ResolutionPolicy;
import org.chocosolver.solver.Solver;
import org.chocosolver.solver.constraints.Constraint;
import org.chocosolver.solver.constraints.IntConstraintFactory;
import org.chocosolver.solver.constraints.extension.Tuples;
import org.chocosolver.solver.search.loop.monitors.SearchMonitorFactory;
import org.chocosolver.solver.search.strategy.IntStrategyFactory;
import org.chocosolver.solver.search.strategy.strategy.AbstractStrategy;
import org.chocosolver.solver.search.strategy.strategy.StrategiesSequencer;
import org.chocosolver.solver.variables.BoolVar;
import org.chocosolver.solver.variables.IntVar;
import org.chocosolver.solver.variables.Variable;
import org.chocosolver.solver.variables.VariableFactory;

import constraints.PropConstraintFactory;
import constraints.DistanceI;
import model.AbstractModel;

// -----------------------------------------------------------
// Main online scheme
// Generates k solutions with a tradeoff quality/diversity
// This abstract class should be overrided to state a tradeoff
// tpetit@wpi.edu
// -----------------------------------------------------------

@SuppressWarnings("rawtypes")
public abstract class AbstractOnline {
	
	public final static String NARY_TABLE_FILTER = "GAC2001";  
	public final static boolean DEBUG = false; 
	
	// --------------------------------------------------------------------------------------------------
	// Abstract method to implement in order to state the type of compromise: ratio, weighted sum, etc. 
	// This method also updates the search strategy by forcing the assignment of any new created variable 
	// (ratio, sum, etc.)
	// --------------------------------------------------------------------------------------------------
	
	public abstract AbstractStrategy newObjAndStrategy(Solver s, int next, long lbDiversity);
	
	// ----
	// Data
	// ----
	
	protected int k;						// Number of required solutions
	protected DistanceI dist;				// Distance function used
	protected int maxLoss; 					// Initial upper bound of quality loss variable (maximum absolute loss between any pair of solutions)
	protected int minRequiredDiver; 		// Initial lower bound of diversity variable (minimum absolute diversity between any pair of solutions)
	protected int[][] diversitySol; 		// Diversity vars in solutions; [k][pbn] with pbn = number of diversity vars of the Model (in the same order)
	protected int[] objSol;					// Objective vars in  solutions; [k][1] 
	public Results res; 					// Output
	
	// ---------
	// CP Solver
	// ---------
	
	protected AbstractModel model;			// Initial model
	protected int pbn; 					    // Number of variables considered for diversity
	protected IntVar[] diversityVars; 		// Current variables considered for diversity
	protected IntVar obj; 					// Current objective variable
	protected IntVar diver;					// Current diversity variable
	protected IntVar objLoss;			    // Current quality variable
	protected IntVar robj;					// Current ratio variable
	protected AbstractStrategy<Variable> strategy; 	// Search strategy of the initial model
	
	// ----------------------------------
	// Quality notions (not mandatory)
	// In this generic class, quality
	// notions without external parameter
	// ----------------------------------
	
	protected Constraint[] qualityCt;       // Current constraint(s) considered for quality
	protected IntVar[] qualityVars;   		// Current variables considered for quality  
	protected IntVar[] additionalIntVars;   // Possible new vars in decomposition
	protected BoolVar[] additionalBoolVars;
	protected IntVar qualityObj;
	protected String qualityType;
	
	protected void updateQuality(Solver s) {
		qualityVars = model.getQualityVars();
		qualityObj = model.getQualityObj();
		qualityCt = model.getQualityCt();
		additionalIntVars = model.getAdditionalIntVars();
		additionalBoolVars = model.getAdditionalBoolVars();
	}
	
	// -------
	// Factory
	// -------
	
	public void init(AbstractModel model, int maxLossObj, int minRequiredDiver, int nbsolutions, DistanceI dist) {
		this.model 				= model;
		this.maxLoss 		    = maxLossObj; 
		this.minRequiredDiver 	= minRequiredDiver; 
		this.k 					= nbsolutions; 
		this.dist               = dist;
		this.res                = new Results();
		this.qualityType		= "None";
	}
	
	// -----------------
	// Reinit the solver
	// -----------------
	
	public Solver init() {
		Solver s                = model.duplicate();
		this.obj                = model.concreteObj(s);
		this.diversityVars 		= model.getDiversityVars(); 
		this.strategy 			= model.getStrategy();
		this.pbn 				= diversityVars.length; 
		return s; 
	}
	
	// -----------------------------------------------------
	// First solution and creation of this.diversitySol
	// The first solution is computed WITHOUT quality notion
	// This is the reference in terms of objective value
	// -----------------------------------------------------
	
	protected void firstSolution(long timeLimit) { 
		Solver s = init();
		this.diversitySol = new int[k][pbn];
		this.objSol = new int[k];
		SearchMonitorFactory.limitTime(s, timeLimit);
		s.set(strategy);
		s.findOptimalSolution(ResolutionPolicy.MINIMIZE, obj);  
		if(s.getMeasures().getSolutionCount()>0) {
			for(int i=0; i<diversityVars.length; i++) {
				diversitySol[0][i] = diversityVars[i].getValue();
			}
			objSol[0] = obj.getValue();
		} else {
			throw new Error("DefaultMaxProblem: firstSolution(long timeLimit): Unable to find the first solution.");
		}
		System.out.println("Solution 0 found.");
		storeSolution(s,0);
	}
	
	// -----------------------------------------------------------
	// Main procedure: online generation of the k-1 next solutions
	// -----------------------------------------------------------
	

	@SuppressWarnings("unchecked")
	public void onlineGeneration(long timeLimit, int maxDiver) {
		firstSolution(timeLimit);
		long lbDiversity = 0;  
		int next = 1;
		while(next<k) {
			Solver s = init();  	// Model clone 
			qualityType = model.getQualityType();  
			if(qualityType!="None") {
				updateQuality(s);
				s.post(qualityCt);
			}
			int realMaxDiver = maxDiver*next;
			postDiversityConstraint(realMaxDiver, s, lbDiversity, next);  	// Diversity variable and constraint
			postObjLossConstraint(s); 									// Quality variable and constraint
			forbidPreviousSolutions(s,next);  							// Avoids repeating solutions independently from the distance constraint
			strategy = newObjAndStrategy(s,next,lbDiversity); 	        // New objective and updated strategy -- declare robj variable
			s.set(new StrategiesSequencer(strategy,
					IntStrategyFactory.lexico_Neq_LB(new IntVar[] {objLoss})));
			SearchMonitorFactory.limitTime(s, timeLimit);
			s.findOptimalSolution(ResolutionPolicy.MAXIMIZE, robj);
			if(s.getMeasures().getSolutionCount()==0) {
				next = k;
				if(DEBUG) { 
					System.out.println(s.getMeasures());
					System.out.println(s);
				}
			} else {
				System.out.println("Solution "+next+" found.");
				if(DEBUG) { 
					System.out.println(s.getMeasures());
				}
				for(int i=0; i<diversityVars.length; i++) {
					diversitySol[next][i] = diversityVars[i].getValue();
				}
				lbDiversity += diver.getValue();
				storeSolution(s, next);
				next++;
			}
			
		}
		
	}
	
	public void postDiversityConstraint(int maxDiver, Solver s, long lbDiversity, int next){
		int lb = (int) Math.max(minRequiredDiver - (lbDiversity - (next-1)*minRequiredDiver),0); // lbDiversity-(next-1)*minRequiredDiver >= 0 by construction
		int ub = maxDiver - minRequiredDiver + lb; 
		diver = VariableFactory.bounded("s_diver", lb, ub, s);
		//System.out.println(diver);
		int[][] previousSol = new int[next][pbn];
		for(int i=0; i<next; i++) {
			for(int j=0; j<pbn; j++) {
				previousSol[i][j] = diversitySol[i][j];
			}
		}
		s.post(PropConstraintFactory.Diversity(diversityVars, diver, previousSol, 0, dist));  // prev = 0 because diver has yet the correct domain
	}
	
	public void postObjLossConstraint(Solver s) {
		objLoss = VariableFactory.bounded("s_objloss", 0, maxLoss, s);
		s.post(PropConstraintFactory.ObjLossCt(obj, objLoss, objSol[0])); 
	}
	
	public void forbidPreviousSolutions(Solver s, int next){
		Tuples t = new Tuples(false); 
		for(int i=0; i<next; i++) {
			int[] forbid = new int[diversityVars.length]; 
			for(int j=0; j<diversitySol[i].length; j++) {
				forbid[j] = diversitySol[i][j];	
			}
			t.add(forbid);
		}
		//s.post(IntConstraintFactory.table(diversityVars, t, NARY_TABLE_FILTER)); // Still bugged in choco
		s.post(PropConstraintFactory.Forbid(diversityVars, t));
	}

	// -------------------------------------
	// Objective values, solutions, measures
	// -------------------------------------
	
	@SuppressWarnings("unchecked")
	public void storeSolution(Solver s, int next) {
		if(s.getMeasures().getSolutionCount()>0) {
			res.hassolution.add(Boolean.TRUE);
			if(s.hasReachedLimit()) {
					res.optimal.add(Boolean.FALSE);
			} else {
					res.optimal.add(Boolean.TRUE);
			}
		}
		res.solverTrace.add(s.toString());
		int nbvars = s.getNbVars();
		String tmp = "";
		for(int i =0; i<nbvars; i++) {
			tmp += "\n" + s.getVar(i); 
		} 
		res.allVars.add(tmp);
		res.measuresTrace.add(s.getMeasures().toString());
		res.backtracks.add(s.getMeasures().getBackTrackCount());
		res.timeValues.add(s.getMeasures().getTimeCount());
		res.nodes.add(s.getMeasures().getNodeCount());
		res.objValues.add(obj.getValue());
		if(qualityType!="None") {
			res.qualityObjValue.add(qualityObj.getValue());
			ArrayList l = new ArrayList();
			for(int i=0; i<qualityVars.length; i++) {
				l.add(qualityVars[i].getValue());
			}
			res.qualityVarsValues.add(l);
		}
		String st ="";
		for(int i=0;i<diversitySol[next].length; i++) {
			st += diversitySol[next][i];
			if(next==0 || (next>0 && diversitySol[next][i]==diversitySol[next-1][i])) {
				st += " ";
			} else {
				st += "*";
			}
		}
		for(int j=next-1;j>=0;j--) {
			int cpt = 0;
			for(int i=0;i<diversitySol[next].length; i++) {
				if(diversitySol[next][i]!=diversitySol[j][i]) {
					cpt++;
				}
			}
			st += "\n" + cpt +" differences with solution " + j; 
		}
		if(next>0) {
			st += "\nrobj value = " + robj.getValue();
			st += "\ndiversity objective value = "+ diver.getValue();
			// Quality notion
			if(qualityType!="None") {
				st += "\n quality notion: "+qualityType;
				st += "\n quality notion obj value = " + qualityObj.getValue();
			}
			// End quality notion
		}
		res.diversityVarsValues.add(st);
		if(next==0) {
			res.diverValues.add(0);
		} else {
			res.diverValues.add(diver.getValue());
		}
	}
	
}

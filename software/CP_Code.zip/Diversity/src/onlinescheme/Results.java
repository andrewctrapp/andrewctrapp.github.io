// T.Petit 2016
package onlinescheme;

import java.util.ArrayList;
// import java.util.StringTokenizer;

@SuppressWarnings("rawtypes")
public class Results {

	public ArrayList<Boolean> hassolution;
	public ArrayList<Boolean> optimal;
	public ArrayList<String> solverTrace; 
	public ArrayList<String> allVars; 
	public ArrayList<String> measuresTrace; 
	public ArrayList objValues; 
	public ArrayList diverValues;
	public ArrayList diversityVarsValues; 
	public ArrayList timeValues; 
	public ArrayList backtracks;
	public ArrayList nodes;
	public ArrayList qualityObjValue;
	public ArrayList qualityVarsValues;

	public Results() {
		hassolution = new ArrayList<Boolean>();
		optimal = new ArrayList<Boolean>();
		solverTrace = new ArrayList<String>();
		allVars = new ArrayList<String>();
		measuresTrace = new ArrayList<String>();
		objValues = new ArrayList();
		diverValues = new ArrayList();
		diversityVarsValues = new ArrayList();
		timeValues = new ArrayList();
		backtracks = new ArrayList();
		nodes = new ArrayList();
		qualityObjValue = new ArrayList();
		qualityVarsValues = new ArrayList();
	}

	public String toString(boolean concise) {
		int n = objValues.size();
		String s = "Initial solution:\n";
		for(int i=0; i<n; i++) {
			s += "---\nSolution\t"+i+"\n---";
			s += "\nSolution?\t";
			if(hassolution.get(i)==Boolean.TRUE) {
				s += "yes";
				if(optimal.get(i)==Boolean.TRUE) {
					s += " (optimal)"; 
				}
			} else {
				s+= "no";
			}
			if(i>=1) {
				s += "\nDiversity\t"+ diverValues.get(i);
			}
			s += "\nObjective\t" + objValues.get(i);
			s += "\nBacktracks\t" + backtracks.get(i);
			s += "\nNodes\t" + nodes.get(i);
			s += "\nTime\t" + timeValues.get(i);
			s += "\nDiversity vars: " + diversityVarsValues.get(i);
			if(i>0 && qualityObjValue.size()>i-1) {
				s += "\nQuality obj value: " + qualityObjValue.get(i-1); 
				s += "\nQuality vars values: " + qualityVarsValues.get(i-1);
			}
			if(!concise) {
				s += "\n\n"+solverTrace.get(i);
			}
			s += "\n\n"+measuresTrace.get(i);
			s += "\n\n";

		}
		return s;
	}

	// ------------
	// Python stats
	// ------------
	
	public String python() {
		int n = objValues.size();
		// nodes per second 
		String s = "nodes per second = [";
		for(int i=0; i<n-1; i++) {
			float tim = (float)timeValues.get(i);
			float div = ((long)nodes.get(i))/Math.max(tim,1);
			int div2 = (int) div; 
			s += div2 + ",";
		}
		float tim = (float)timeValues.get(n-1);
		float div = ((long)nodes.get(n-1))/Math.max(tim,1);
		int div2 = (int) div;
		s += div2;
		s += "]\n";
		// objective value
		s += "obj = [";
		for(int i=0; i<n-1; i++) {
			s += objValues.get(i) + ",";
		}
		s += objValues.get(n-1);
		s += "]\n";
		// diversity values
		s += "diversity = [";
		for(int i=0; i<n-1; i++) {
			s += diverValues.get(i) + ",";
		}
		s += diverValues.get(n-1);
		s += "]\n";
		// cumulated diversity
		s += "cumulated_diversity = [";
		int sum = 0;
		for(int i=0; i<n-1; i++) {
			sum += (int)diverValues.get(i);
			s += sum + ",";
		}
		sum += (int)diverValues.get(n-1);
		s += sum + "]\n";
		// optimal 
		s += "optimal = [";
		for(int i=0; i<n-1; i++) {
			s += optimal.get(i) + ",";
		}
		s += optimal.get(n-1);
		s += "]\n";
		// quality values
		if(qualityObjValue.size()>0) {
			s += "quality = [-,";
			for(int i=0; i<n-2; i++) {
				s += qualityObjValue.get(i) + ",";
			}
			s += qualityObjValue.get(n-2);
			s += "]\n";
		}
		//System.out.println(s);
		return s;
	}
	
	public ArrayList<String> getAllVars() {
		return allVars;
	}
	
	// Temp
	
	/*
	public static ArrayList<String> findNotMatching(String sourceStr, String anotherStr){
	    StringTokenizer at = new StringTokenizer(sourceStr, " ");
	    StringTokenizer bt = null;
	    int i = 0, token_count = 0;
	    String token = null;
	    boolean flag = false;
	    ArrayList<String> missingWords = new ArrayList<String>();
	    while (at.hasMoreTokens()) {
	        token = at.nextToken();
	        bt = new StringTokenizer(anotherStr, " ");
	        token_count = bt.countTokens();
	        while (i < token_count) {
	            String s = bt.nextToken();
	            if (token.equals(s)) {
	                flag = true;
	                break;
	            } else {
	                flag = false;
	            }
	            i++;
	        }
	        i = 0;
	        if (flag == false)
	            missingWords.add(token);
	    }
	    return missingWords;
	}*/
	
}
